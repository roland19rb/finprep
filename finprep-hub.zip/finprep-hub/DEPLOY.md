# Hosting FinPrep Hub

The whole site deploys from GitHub. Nothing has to be uploaded anywhere else: the course knowledge
(the chunked lectures, cases and exercise files) is part of the repository in `data/docs/`.

```mermaid
flowchart LR
  subgraph GitHub["GitHub (private repository)"]
    R["finprep-hub<br/>code + data/docs"]
  end
  subgraph Vercel["Vercel (free Hobby plan)"]
    S["Website<br/>public/"]
    F["Functions<br/>api/*.js"]
  end
  A["Anthropic API<br/>(your key)"]
  St["Students<br/>browser or phone"]
  R -- "every push deploys" --> Vercel
  St -- "URL + access code" --> S
  S --> F
  F -- "questions, checks" --> A
  F -- "a student adds a document:<br/>commit data/docs/added-….json" --> R
```

| You need | Cost |
|---|---|
| A GitHub account | free (private repositories included) |
| A Vercel account (sign in with GitHub) | free Hobby plan |
| An Anthropic API key with credit | pay per use — see [Costs](#costs) |

Time: about 20 minutes.

---

## 1. Put the repository on GitHub

Put the `finprep-hub` folder in a place that no cloud service syncs (not OneDrive, Dropbox or an
iCloud-synced Desktop), for example `~/Projects/finprep-hub`. Git and syncing folders get in each
other's way.

**With GitHub Desktop** (no command line):

1. Install GitHub Desktop from <https://desktop.github.com> and sign in.
2. **File → Add Local Repository…** → choose the `finprep-hub` folder.
3. It says the folder is not a Git repository yet → click **create a repository**. Leave
   **Initialize this repository with a README** unticked, Git Ignore and License on **None**
   (the folder has its own `.gitignore`) → **Create Repository**.
4. Click **Publish repository**. Keep **Keep this code private** ticked → **Publish Repository**.

**Or in Terminal** (with the GitHub CLI `gh` installed and logged in):

```bash
cd ~/Projects/finprep-hub
git init -b main
git add .
git commit -m "FinPrep Hub"
gh repo create finprep-hub --private --source . --push
```

The repository holds about 160 files (6 MB). The web uploader on github.com accepts at most 100
files at a time, so use one of the two ways above.

## 2. Create the Anthropic API key

1. Open the Claude Console: <https://console.anthropic.com> and sign in.
2. **Billing**: add credit.
3. **Limits**: set a monthly spend limit you are comfortable with. This is the real protection
   for your budget.
4. **API Keys → Create Key** → name it `finprep-hub` → copy the key (it starts with `sk-ant-`).
   It is shown only once.

## 3. Deploy on Vercel

1. Go to <https://vercel.com/signup> → **Continue with GitHub** → choose the **Hobby** plan.
2. On the dashboard: **Add New… → Project**.
3. Under **Import Git Repository**, find `finprep-hub` → **Import**.
   If it is not listed: **Adjust GitHub App Permissions** → allow access to `finprep-hub` → back to the list.
4. On **Configure Project** leave everything as it is (Framework Preset **Other**; `vercel.json`
   in the repository sets the output folder and the functions).
5. Open **Environment Variables** and add:

   | Key | Value |
   |---|---|
   | `ANTHROPIC_API_KEY` | the key from step 2 |
   | `ACCESS_CODE` | a code for the class, e.g. `finprep-2026` |

6. **Deploy**. After about a minute the project page shows the site address under **Domains**,
   e.g. `https://finprep-hub.vercel.app`. This is the address for the class. (Vercel also shows
   longer addresses of single deployments; those can ask visitors for a Vercel login.)
7. Open it, type the access code, ask a question. Open **Documents** and one lecture to check
   that it shows its slides.

## 4. Let students add documents for everyone

Without this step, students can still add documents **only for themselves** (kept in their
browser). To let documents become part of the shared hub, the site needs permission to save
files into the repository:

1. On GitHub: profile picture → **Settings → Developer settings → Personal access tokens →
   Fine-grained tokens → Generate new token**.
2. Token name `finprep-hub uploads`, expiration e.g. 1 year.
3. **Repository access → Only select repositories →** `finprep-hub`.
4. **Permissions → Repository permissions → Contents → Read and write.**
   (Also **Pull requests → Read and write** if you want to approve each document, see step 6.)
5. **Generate token** → copy it (starts with `github_pat_`).
6. On Vercel: your project → **Settings → Environment Variables** → add `GITHUB_TOKEN` with the token.
   Optional: `PUBLISH_MODE` = `pull-request` if every added document should wait for your approval.
7. **Deployments** → the newest deployment → **⋯ → Redeploy** (new settings apply after a redeploy).

What happens from then on when a student clicks **Add to the hub**:

```mermaid
sequenceDiagram
  participant B as Student's browser
  participant F as Vercel function
  participant C as Claude
  participant G as GitHub
  participant V as Vercel
  B->>B: Read the file into pages of text
  B->>F: pages
  F->>F: Clean, check duplicates
  F->>C: Does it fit the course? Personal data?
  C-->>F: publish / decline + reason
  F->>F: Cut into chunks
  F->>G: Commit data/docs/added-<title>.json
  G->>V: Push → new deployment (about 1 minute)
  V-->>B: The document is part of the hub for everyone
```

## 5. Share it

Send the class the address from **Domains** and the access code. A shorter address is possible under
**Vercel → Project → Settings → Domains** (a free `*.vercel.app` name or your own domain).

## 6. Running the hub

| Task | How |
|---|---|
| See what was added | GitHub → `data/docs/` → files starting with `added-`, or the commit list ("Add knowledge: …") |
| Remove a document | GitHub → open `data/docs/<file>.json` → **⋯ → Delete file** → commit. Vercel redeploys by itself. |
| Approve each document first | Set `PUBLISH_MODE=pull-request` and redeploy. Each upload opens a pull request; **Merge** publishes it. Vercel builds a preview site for each pull request, where the document can be tried before merging. |
| Switch sharing off | `PUBLISH_MODE=off` and redeploy. |
| Change the access code | Change `ACCESS_CODE`, redeploy. Students are asked for the new code. |
| Use a cheaper or stronger model | `ANSWER_MODEL` (default `claude-sonnet-5-5`), `HELPER_MODEL` (default `claude-haiku-5-5`), redeploy. |
| Read the "Helpful / Not right" clicks | Vercel → Project → **Logs** (each click is one line starting with `{"type":"feedback"`). |
| Add new lectures in bulk | See [docs/CHUNKING.md](docs/CHUNKING.md#rebuilding-the-course-materials). Single files can simply be added through the site. |

## Settings

| Variable | Needed | Default | What it does |
|---|---|---|---|
| `ANTHROPIC_API_KEY` | yes | – | Key for Claude. Stays on the server; never sent to browsers. |
| `ACCESS_CODE` | recommended | none | Code students enter once. Without it, anyone with the address can use the hub and your credit. |
| `GITHUB_TOKEN` | for shared adding | – | Fine-grained token with Contents: Read and write on this repository. |
| `PUBLISH_MODE` | no | `direct` | `direct`, `pull-request` or `off`. |
| `GITHUB_REPO` | no | detected on Vercel and Render | `owner/name` of the repository. Set it if adding fails with "repository not found". |
| `GITHUB_BRANCH` | no | the deployed branch | Branch documents are committed to. |
| `ANSWER_MODEL` | no | `claude-sonnet-5-5` | Model that answers questions. |
| `HELPER_MODEL` | no | `claude-haiku-5-5` | Model that reviews added documents. |
| `ALLOW_GENERAL_KNOWLEDGE` | no | `true` | When the materials do not cover a question, a short general explanation is added and marked "General knowledge". `false` = only say it is not covered. |
| `HUB_NAME`, `COURSE_NAME` | no | `FinPrep Hub`, `Finance Prep` | Names shown on the site and used in the instructions to Claude. |
| `MAX_TOOL_ROUNDS` | no | `3` | How often the agent may search again before answering. |
| `TIME_BUDGET_MS` | no | `32000` | After this time the agent stops searching and writes, so the answer finishes within Vercel's 60-second limit. |
| `QUESTIONS_PER_10_MIN` | no | `40` | Per browser, per server instance. A safety net, not a quota. |
| `UPLOADS_PER_HOUR` | no | `12` | Same, for adding documents. |
| `MAX_UPLOAD_CHARS` | no | `400000` | Largest document text accepted (about 200 pages). |

## Costs

- **GitHub**: free.
- **Vercel Hobby**: free. The Hobby plan is meant for personal, non-commercial projects; if the hub
  is run officially by an institution, check Vercel's terms or use the Pro plan.
- **Anthropic**: you pay per token; current prices are on <https://www.anthropic.com/pricing>.
  One answer typically uses 8,000–15,000 input tokens (the question, the found passages, a
  second search) and 500–1,500 output tokens. Parts of the input are cached and billed at a
  fraction of the price when questions follow each other within five minutes. Reviewing an added
  document is one short call to the smaller helper model. `ANSWER_MODEL=claude-haiku-5-5`
  lowers the cost per answer considerably, with simpler answers.

## Limits to know

| Limit | Effect in the hub |
|---|---|
| Vercel functions run at most 60 s (set in `vercel.json`) | The agent stops searching after `TIME_BUDGET_MS` and writes the answer. Very long answers in "Explained" can still be cut; "Short" is always fast. |
| Vercel accepts requests up to 4.5 MB | Uploads are limited to `MAX_UPLOAD_CHARS` of text; larger files are split by the student. |
| 100 deployments per day on Hobby | Each document added to the hub is one deployment. |
| Scanned PDFs (pictures of pages) | Have no text layer; the hub says so and asks for a text version. |

## Troubleshooting

| What you see | Cause and fix |
|---|---|
| Yellow bar "Answers are switched off" | `ANTHROPIC_API_KEY` is missing. Add it on Vercel, then redeploy. |
| "The Anthropic API key on the server is not valid" | The key was mistyped or revoked. Create a new key, replace it, redeploy. |
| "The hub has reached its Anthropic usage limit" | Credit used up or spend limit reached: Claude Console → Billing / Limits. |
| "The configured Claude model was not found" | The key cannot use that model. Set `ANSWER_MODEL` / `HELPER_MODEL` to a model listed in your Console, redeploy. |
| "Adding to the hub needs a GitHub token" | Step 4 is missing, or the redeploy after adding `GITHUB_TOKEN` was skipped. |
| "The GitHub token is not allowed to write…" | The token lacks **Contents: Read and write** or does not include this repository. |
| "The repository or branch was not found" | Set `GITHUB_REPO=owner/finprep-hub` and `GITHUB_BRANCH=main`, redeploy. |
| A student added a document but others do not see it | Look at Vercel → Deployments: the new deployment takes about a minute. With `PUBLISH_MODE=pull-request` it waits for your merge. |
| "The answer stopped before it was finished" | The 60-second limit was reached. Ask again or choose **Short**; lower `MAX_TOOL_ROUNDS` to `2` if it happens often. |
| Students on campus get "a lot of requests" | Raise `QUESTIONS_PER_10_MIN`. |

## Other ways to host

The same code runs as a plain Node server (`server.js`) on any host with Node 20 or newer:

```bash
npm start        # reads .env if present, listens on $PORT (default 3000)
```

On **Render** (<https://render.com>): **New → Web Service** → connect the GitHub repository →
Runtime **Node**, Build command `npm install` (there is nothing to install; it finishes at once),
Start command `node server.js` → add the same environment variables → **Create Web Service**. Render redeploys on every push, so documents added through
the site appear after the redeploy just like on Vercel. (Render's free plan sleeps after
15 minutes without visitors; the first request then takes about a minute.)

## Trying it on your Mac first (optional)

```bash
# Node 20+ from https://nodejs.org
cd ~/Projects/finprep-hub
cp .env.example .env          # put your ANTHROPIC_API_KEY into .env
node server.js                # open http://localhost:3000
```

Without a key, the stand-in API shows the whole flow with canned answers:

```bash
node test/mock-anthropic.mjs 8787 &
ANTHROPIC_API_KEY=test ANTHROPIC_BASE_URL=http://localhost:8787 LOCAL_PUBLISH=true node server.js
```

## The course materials

The lecture slides, scripts, cases and exercise files belong to their authors and publishers.
Keep the repository private and the access code within the class. The two Darden case studies
(Euroland Foods, Murray Ohio) say they may not be stored in a retrieval system without the
publisher's permission; if that permission is missing, delete `data/docs/fm-case-euroland-foods.json`
and `data/docs/fm-case-murray-ohio.json` on GitHub.
