#!/usr/bin/env node
// Plain Node server for running the hub on your own computer or on any Node host
// (Render, Railway, a university server, Docker). Vercel does not use this file: there,
// public/ is served as static files and api/*.js run as functions.
//
//   cp .env.example .env    # add ANTHROPIC_API_KEY
//   node server.js          # http://localhost:3000

import http from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { readFileSync, existsSync } from 'node:fs';
import { join, extname, normalize, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { Readable } from 'node:stream';

const root = dirname(fileURLToPath(import.meta.url));
process.chdir(root);

// .env support without dependencies (KEY=value lines; existing environment wins)
const envFile = join(root, '.env');
if (existsSync(envFile)) {
  for (const line of readFileSync(envFile, 'utf8').split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (!m || line.trim().startsWith('#')) continue;
    const v = m[2].trim().replace(/^(['"])(.*)\1$/, '$2');
    if (process.env[m[1]] === undefined) process.env[m[1]] = v;
  }
}

const routes = await import('./lib/routes.js');
const ROUTES = {
  'GET /api/config': routes.handleConfig,
  'GET /api/catalog': routes.handleCatalog,
  'GET /api/doc': routes.handleDoc,
  'POST /api/ask': routes.handleAsk,
  'POST /api/ingest': routes.handleIngest,
  'POST /api/feedback': routes.handleFeedback,
};

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml',
  '.png': 'image/png', '.ico': 'image/x-icon', '.woff2': 'font/woff2', '.woff': 'font/woff', '.ttf': 'font/ttf',
  '.bcmap': 'application/octet-stream', '.txt': 'text/plain; charset=utf-8', '.webmanifest': 'application/manifest+json',
};

// the same response headers as vercel.json, so local runs behave like production
const vercel = JSON.parse(readFileSync(join(root, 'vercel.json'), 'utf8'));
function headersFor(path) {
  const out = {};
  for (const rule of vercel.headers || []) {
    const re = new RegExp('^' + rule.source.replace(/\(([^)]*)\)/g, (m, g) => (g === '.*' ? '(.*)' : `(${g})`)) + '$');
    if (re.test(path)) for (const h of rule.headers) out[h.key.toLowerCase()] = h.value;
  }
  return out;
}

async function serveStatic(req, res, pathname) {
  let rel = decodeURIComponent(pathname);
  if (rel.endsWith('/')) rel += 'index.html';
  const file = normalize(join(root, 'public', rel));
  if (!file.startsWith(join(root, 'public'))) { res.writeHead(403).end('Forbidden'); return; }
  try {
    const s = await stat(file);
    if (!s.isFile()) throw new Error('not a file');
    const body = await readFile(file);
    res.writeHead(200, { 'content-type': MIME[extname(file)] || 'application/octet-stream', 'content-length': body.length, ...headersFor(pathname) });
    res.end(req.method === 'HEAD' ? undefined : body);
  } catch {
    res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8', ...headersFor(pathname) }).end('Not found');
  }
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const handler = ROUTES[`${req.method} ${url.pathname}`];
  if (!handler) {
    if (url.pathname.startsWith('/api/')) {
      res.writeHead(404, { 'content-type': 'application/json' }).end('{"error":"Not found"}');
      return;
    }
    if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405).end(); return; }
    await serveStatic(req, res, url.pathname);
    return;
  }
  const abort = new AbortController();
  res.on('close', () => { if (!res.writableFinished) abort.abort(); });
  const init = { method: req.method, headers: req.headers, signal: abort.signal };
  if (req.method !== 'GET' && req.method !== 'HEAD') { init.body = Readable.toWeb(req); init.duplex = 'half'; }
  let response;
  try {
    response = await handler(new Request(url, init));
  } catch (e) {
    console.error(e);
    res.writeHead(500, { 'content-type': 'application/json' }).end('{"error":"Server error"}');
    return;
  }
  const headers = { ...headersFor(url.pathname) };
  response.headers.forEach((v, k) => { headers[k] = v; });
  res.writeHead(response.status, headers);
  if (!response.body) { res.end(); return; }
  const reader = response.body.getReader();
  abort.signal.addEventListener('abort', () => reader.cancel().catch(() => {}));
  try {
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      res.write(value);
    }
  } catch { /* client went away */ }
  res.end();
});

const port = Number(process.env.PORT) || 3000;
server.listen(port, () => {
  const key = process.env.ANTHROPIC_API_KEY ? 'set' : 'MISSING (answers will not work)';
  console.log(`FinPrep Hub on http://localhost:${port}  ·  Anthropic key: ${key}`);
});
