// Ask: the start page and the course-wide conversation.

import { state, save } from './state.js';
import { html, raw, ic, icon, el, esc, autosize, fmtNum, MODULE_ICON, unitWord } from './ui.js';
import { TurnView, newTurn, modeSwitch, bindModeSwitch, historyFrom, MODES } from './answer.js';

/** Ask box used on the start page, in the conversation and next to a document. */
export function askBox({ placeholder, withScope = true, onSubmit, autofocus = false, rows = 1 }) {
  const modules = state.catalog?.modules || [];
  const node = el(html`<form class="askbox" autocomplete="off">
      <label class="sr" for="q-${Math.random().toString(36).slice(2, 6)}">Your question</label>
      <textarea rows="${rows}" placeholder="${placeholder}" maxlength="2000"></textarea>
      <div class="askbar">
        <span class="lbl">Answer as</span>
        ${modeSwitch(state.mode)}
        ${withScope ? html`<select class="select" aria-label="Search in">
          <option value="">All materials</option>
          ${modules.filter((m) => state.catalog.docs.some((d) => d.module === m.id)).map((m) => html`<option value="${m.id}" ${m.id === state.module ? raw('selected') : ''}>${m.title}</option>`)}
        </select>` : ''}
        <span class="spacer"></span>
        <button class="send" type="submit" aria-label="Ask">${ic('send', 20, 2.2)}</button>
      </div></form>`);
  const ta = node.querySelector('textarea');
  autosize(ta);
  ta.addEventListener('input', () => node.classList.toggle('has-text', !!ta.value.trim()));
  bindModeSwitch(node.querySelector('[data-seg]'), (m) => save.mode(m));
  node.querySelector('select')?.addEventListener('change', (e) => { state.module = e.target.value; });
  const submit = () => {
    const q = ta.value.trim();
    if (!q || node.classList.contains('busy')) return;
    ta.value = '';
    ta.style.height = 'auto';
    node.classList.remove('has-text');
    onSubmit(q, state.mode);
  };
  node.addEventListener('submit', (e) => { e.preventDefault(); submit(); });
  ta.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); submit(); }
  });
  if (autofocus) requestAnimationFrame(() => ta.focus({ preventScroll: true }));
  return {
    el: node,
    focus: () => ta.focus(),
    setBusy(b) {
      node.classList.toggle('busy', b);
      node.querySelector('.send').disabled = b;
    },
    setMode(m) {
      node.querySelectorAll('[data-mode]').forEach((x) => { x.classList.toggle('on', x.dataset.mode === m); x.setAttribute('aria-checked', String(x.dataset.mode === m)); });
    },
  };
}

function shortTitle(t) {
  return t.replace(/^Business (Mathematics|Statistics) \d* ?[–-]\s*/, '').replace(/^Financial Statements – /, '').replace(/^\d\d\s+/, '').replace(/^Case:\s*/, '').replace(/\s*\(.*?\)\s*$/, '');
}

function moduleCards() {
  const { modules, docs } = state.catalog;
  const cards = modules.map((m) => {
    const list = docs.filter((d) => d.module === m.id && d.origin === 'course');
    if (!list.length) return '';
    const units = list.reduce((s, d) => s + (d.stats?.pages || 0), 0);
    const [ico, tone] = MODULE_ICON[m.id] || ['book', ''];
    const topics = [...new Set(list.filter((d) => d.kind !== 'Student work').map((d) => shortTitle(d.title)))].slice(0, 7).join(' · ');
    return html`<a class="mod" href="#/docs?m=${m.id}">
      <div class="mod-top"><span class="mod-ico ${tone}">${ic(ico, 18)}</span><div><div class="mod-name">${m.title}</div>
      <div class="mod-meta">${list.length} documents · ${fmtNum(units)} pages and slides</div></div></div>
      <div class="mod-topics">${topics}</div></a>`;
  });
  const added = docs.filter((d) => d.origin === 'added');
  cards.push(html`<a class="mod" href="${added.length ? '#/docs?m=added' : '#/add'}">
      <div class="mod-top"><span class="mod-ico teal">${ic('users', 18)}</span><div><div class="mod-name">Added by the class</div>
      <div class="mod-meta">${added.length ? `${added.length} document${added.length === 1 ? '' : 's'}` : 'Nothing added yet'}</div></div></div>
      <div class="mod-topics">${added.length ? added.slice(-4).map((d) => d.title).join(' · ') : 'Notes, summaries and slides that students add become part of the hub.'}</div></a>`);
  return cards;
}

export function renderAsk(main, ctx) {
  let view = null;
  let box = null;
  let turnsEl = null;
  const views = [];

  const ask = (question, mode, extra = {}) => {
    const prior = state.thread.slice();
    const turn = newTurn({ question, mode, module: state.module || '', ...extra });
    if (!turnsEl) draw(true);
    state.thread.push(turn);
    save.thread();
    return run(turn, prior);
  };

  const run = (turn, prior) => {
    const tv = mount(turn);
    tv.el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    box?.setBusy(true);
    tv.start({
      question: turn.question,
      mode: turn.mode,
      module: turn.module || undefined,
      history: historyFrom(prior),
      feedback: turn.feedback,
    }).finally(() => { box?.setBusy(false); save.thread(); });
  };

  const mount = (turn) => {
    const tv = new TurnView(turn, {
      onSource: (s) => ctx.go(`#/doc/${encodeURIComponent(s.docId)}?p=${s.pages[0]}`),
      onReask: (t, mode) => ask(t.question, mode, { module: t.module, label: `Same question · ${MODES[mode].label}` }),
      onCheckAgain: (t, note) => ask(t.question, t.mode, { module: t.module, label: 'Checked again after “Not right”', feedback: { previousAnswer: t.text, note } }),
      onChange: () => save.thread(),
      onNeedsCode: () => ctx.needCode(),
    });
    views.push(tv);
    turnsEl.appendChild(tv.el);
    return tv;
  };

  const draw = (forceThread = false) => {
    main.innerHTML = '';
    turnsEl = null;
    if (!state.thread.length && !forceThread) {
      const page = el(html`<div class="wrap"><section class="hero">
        <h1>Ask the course</h1>
        <p class="lead">Answers come from the ${state.config?.course || 'Finance Prep'} lecture slides, script, cases and exercise files — with the slides they come from.</p>
        <div class="box-slot"></div>
        <div class="modes-help">${Object.values(MODES).map((m) => html`<span><b>${m.label}</b> — ${m.hint.toLowerCase()}</span>`)}</div>
      </section>
      <section class="knows"><h2>What the hub knows</h2><div class="mod-grid">${moduleCards()}</div></section></div>`);
      box = askBox({ placeholder: 'Ask anything about the course — a concept, a formula, an exercise, a case…', onSubmit: (q, m) => ask(q, m), autofocus: true, rows: 2 });
      page.querySelector('.box-slot').replaceWith(box.el);
      main.appendChild(page);
      return;
    }
    const page = el(html`<div class="wrap"><div class="thread">
      <div class="thread-head"><h1>Your questions</h1><span class="spacer"></span>
      <button class="btn small" data-a="new">${ic('add', 16)}New conversation</button></div>
      <div class="turns"></div><div class="dock"></div></div></div>`);
    turnsEl = page.querySelector('.turns');
    box = askBox({ placeholder: 'Ask a follow-up or a new question…', onSubmit: (q, m) => ask(q, m) });
    page.querySelector('.dock').appendChild(box.el);
    page.querySelector('[data-a="new"]').addEventListener('click', () => {
      views.forEach((v) => v.stop());
      views.length = 0;
      state.thread = [];
      save.thread();
      draw();
    });
    main.appendChild(page);
    for (const t of state.thread) {
      const tv = mount(t);
      const pending = tv.attach();
      if (pending) { box.setBusy(true); pending.finally(() => { box?.setBusy(false); save.thread(); }); }
    }
    const last = turnsEl.lastElementChild;
    if (last) requestAnimationFrame(() => last.scrollIntoView({ block: 'start' }));
  };

  draw();
  view = { leave: () => save.thread() };
  return view;
}
