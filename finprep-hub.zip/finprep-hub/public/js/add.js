// Add knowledge: choose a file → read it in the browser → the intake agent cleans, checks,
// chunks and publishes it (or keeps it private in this browser).

import { state, save } from './state.js';
import { stream } from './api.js';
import { html, raw, ic, icon, el, esc, fmtNum, docIcon, unitWord, toast } from './ui.js';
import { extractFile, fileKind, ACCEPT } from './extract.js';

const STEPS = [
  { id: 'read', title: 'Read', who: 'in your browser', idle: 'The file is turned into pages of text.' },
  { id: 'clean', title: 'Clean', who: 'intake agent', idle: 'Repeated headers, footers and page numbers are removed; broken lines are joined.' },
  { id: 'check', title: 'Check', who: 'intake agent · Claude', idle: 'Is it about the course? Is it already in the hub? No personal data?' },
  { id: 'chunk', title: 'Chunk', who: 'intake agent', idle: 'The text is cut into chunks that follow the slides, sections and paragraphs.' },
  { id: 'publish', title: 'Publish', who: 'intake agent · GitHub', idle: 'The document file is saved in the hub’s repository; the site redeploys with it.' },
];
const CK = ['#7aa2ec', '#4fb3c2', '#e2b04a', '#6cc191', '#a3adbd', '#e48f86'];

export function renderAdd(main, ctx) {
  const sharing = state.config?.sharing || { enabled: false, reason: '' };
  let file = null;
  let read = null;
  let intent = sharing.enabled ? 'hub' : 'private';
  let req = null;
  const steps = {};

  const page = el(html`<div class="wrap"><div class="add">
    <div class="page-head"><div><h1>Add knowledge</h1></div></div>
    <p class="add-intro">Add your notes, summaries, slides or worked solutions. An agent reads the file, checks that it fits the course, cuts it into chunks and adds it to the hub for the whole class — or keeps it just for you to talk to.</p>
    <div class="card" data-card="file"></div>
    <div class="card" data-card="pipe" hidden><h2>What happens to the file</h2><ol class="pipe"></ol><div class="result"></div></div>
  </div></div>`);
  main.innerHTML = '';
  main.appendChild(page);
  const fileCard = page.querySelector('[data-card="file"]');
  const pipeCard = page.querySelector('[data-card="pipe"]');

  const drawChoose = (error = '') => {
    fileCard.innerHTML = html`<h2>1. Choose a file</h2>
      <label class="drop" tabindex="0">
        ${ic('upload', 30, 1.6)}<span class="big">Drop a file here, or click to choose one</span>
        <small>PDF, Word (.docx), PowerPoint (.pptx), Excel (.xlsx), text or Markdown · up to 400 pages</small>
        <input type="file" accept="${ACCEPT}" hidden>
      </label>
      ${error ? html`<p class="verdict no" style="margin-top:12px">${error}</p>` : ''}`.html;
    const drop = fileCard.querySelector('.drop');
    const input = fileCard.querySelector('input');
    input.addEventListener('change', () => input.files[0] && takeFile(input.files[0]));
    drop.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); input.click(); } });
    ['dragenter', 'dragover'].forEach((t) => drop.addEventListener(t, (e) => { e.preventDefault(); drop.classList.add('over'); }));
    ['dragleave', 'drop'].forEach((t) => drop.addEventListener(t, (e) => { e.preventDefault(); drop.classList.remove('over'); }));
    drop.addEventListener('drop', (e) => { const f = e.dataTransfer?.files?.[0]; if (f) takeFile(f); });
  };

  const setStep = (id, status, line = '', detail = '') => {
    steps[id] = { status, line, detail };
    drawPipe();
  };

  const drawPipe = () => {
    pipeCard.hidden = false;
    pipeCard.querySelector('.pipe').innerHTML = STEPS.map((s) => {
      const st = steps[s.id] || { status: 'idle' };
      const dot = st.status === 'done' ? icon('check', 17, 2.4) : st.status === 'fail' ? icon('x', 16, 2.4) : st.status === 'run' ? icon('refresh', 16) : st.status === 'skip' ? icon('skip', 16) : `<span style="font-size:13px;font-weight:600">${STEPS.indexOf(s) + 1}</span>`;
      return `<li class="pstep ${st.status}"><span class="pdot">${dot}</span><div>
        <div class="ptitle">${esc(s.title)}<span class="pwho">${esc(s.who)}</span></div>
        <div class="pline">${st.line ? st.line : esc(s.idle)}</div>${st.detail || ''}</div></li>`;
    }).join('');
  };

  const takeFile = async (f) => {
    if (!fileKind(f)) { drawChoose('This file type is not supported. Use PDF, Word, PowerPoint, Excel, text or Markdown.'); return; }
    file = f;
    read = null;
    Object.keys(steps).forEach((k) => delete steps[k]);
    pipeCard.querySelector('.result').innerHTML = '';
    drawFile(true);
    setStep('read', 'run', `Reading <b>${esc(f.name)}</b>…`);
    try {
      read = await extractFile(f, (i, n) => setStep('read', 'run', `Reading <b>${esc(f.name)}</b> — ${i} of ${n}…`));
    } catch (e) {
      setStep('read', 'fail', esc(e.message || 'The file could not be read.'));
      drawFile(false);
      return;
    }
    const emptyPages = read.pages.filter((p) => !p.text.trim()).length;
    const scanned = read.words < 30;
    const max = state.config?.maxUploadChars || 400000;
    if (read.chars > max) {
      setStep('read', 'fail', `This file has ${fmtNum(read.chars)} characters of text; one upload can have up to ${fmtNum(max)}. Split it into parts and add them one by one.`);
      read = null;
      drawFile(false);
      return;
    }
    setStep('read', scanned ? 'fail' : 'done',
      scanned ? 'No text found. This looks like a scanned document (pictures of pages); please use a version with selectable text.'
        : `Read ${unitWord(read.unit, read.pages.length)} with ${fmtNum(read.words)} words${emptyPages ? ` (${emptyPages} without text)` : ''}.`);
    drawFile(false);
  };

  const drawFile = (busy) => {
    if (!file) { drawChoose(); return; }
    const kind = fileKind(file);
    const ico = docIcon({ unit: kind === 'pptx' ? 'slide' : kind === 'xlsx' ? 'sheet' : 'page', kind: '' });
    const title = fileCard.querySelector('#add-title')?.value || file.name.replace(/\.[a-z0-9]+$/i, '').replace(/[_]+/g, ' ');
    const by = fileCard.querySelector('#add-by')?.value || '';
    const ok = read && read.words >= 30;
    fileCard.innerHTML = html`<h2>1. Your file</h2>
      <div class="file-row"><span class="doc-ico ${ico.cls}">${ic(ico.name, 20)}</span>
        <div style="flex:1;min-width:0"><div class="doc-title">${file.name}</div>
        <div class="doc-meta">${fmtNum(Math.round(file.size / 1024))} KB${read ? ` · ${unitWord(read.unit, read.pages.length)} · ${fmtNum(read.words)} words` : busy ? ' · reading…' : ''}</div></div>
        <button class="btn small" data-a="other">${ic('refresh', 15)}Other file</button></div>
      <div class="two">
        <div class="field"><label for="add-title">Title</label><input id="add-title" maxlength="160" value="${title}"></div>
        <div class="field"><label for="add-by">Your name (optional)</label><input id="add-by" maxlength="60" value="${by}" placeholder="Shown with the document"></div>
      </div>
      <h2 style="margin-top:4px">2. Who should see it?</h2>
      <div class="intent">
        <label class="${intent === 'hub' ? 'on' : ''} ${sharing.enabled ? '' : 'off'}"><input type="radio" name="intent" value="hub" ${intent === 'hub' ? raw('checked') : ''} ${sharing.enabled ? '' : raw('disabled')}>
          <span><b>Add to the hub for everyone</b><span>${sharing.enabled ? (sharing.mode === 'pull-request' ? 'An agent checks it fits the course; the hub owner approves it before it goes live.' : 'An agent checks it fits the course; then the whole class can ask about it.') : sharing.reason}</span></span></label>
        <label class="${intent === 'private' ? 'on' : ''}"><input type="radio" name="intent" value="private" ${intent === 'private' ? raw('checked') : ''}>
          <span><b>Only for me</b><span>Stays in this browser. Talk to it on the Documents page; nobody else sees it.</span></span></label>
      </div>
      <button class="btn primary" data-a="go" ${ok && !busy ? '' : raw('disabled')}>${ic(intent === 'hub' ? 'upload' : 'lock', 17)}${intent === 'hub' ? 'Add to the hub' : 'Process it for me'}</button>`.html;
    fileCard.querySelector('[data-a="other"]').addEventListener('click', () => { req?.abort(); file = null; read = null; pipeCard.hidden = true; drawChoose(); });
    fileCard.querySelectorAll('input[name="intent"]').forEach((r) => r.addEventListener('change', () => { intent = r.value; drawFile(false); }));
    fileCard.querySelector('[data-a="go"]').addEventListener('click', start);
  };

  const start = () => {
    if (!read) return;
    const title = fileCard.querySelector('#add-title').value.trim() || file.name;
    const by = fileCard.querySelector('#add-by').value.trim();
    fileCard.querySelector('[data-a="go"]').disabled = true;
    ['clean', 'check', 'chunk', 'publish'].forEach((id) => delete steps[id]);
    pipeCard.querySelector('.result').innerHTML = '';
    drawPipe();
    pipeCard.scrollIntoView({ behavior: 'smooth', block: 'start' });
    const payload = { fileName: file.name, fileType: read.fileType, bytes: file.size, title, by, intent, unit: read.unit, pages: read.pages };
    req = stream('/api/ingest', payload, (event, data) => {
      if (event === 'step') onStep(data);
      else if (event === 'result') onResult(data);
      else if (event === 'error' || event === 'end') {
        const running = Object.entries(steps).find(([, s]) => s.status === 'run');
        if (running) setStep(running[0], 'fail', esc(data.message || 'The connection was interrupted.'));
        showResult('no', data.message || 'Processing stopped before it finished. Please try again.');
        if (data.needsCode) ctx.needCode();
        fileCard.querySelector('[data-a="go"]')?.removeAttribute('disabled');
      }
    });
  };

  const onStep = (s) => {
    const d = s.detail || {};
    if (s.id === 'clean') {
      if (s.status === 'run') return setStep('clean', 'run', 'Cleaning the text…');
      const removed = (d.removedLines || []).map((r) => `<li>“${esc(r.text)}” — on ${r.pages} pages</li>`).join('');
      const bits = [];
      if (d.removedLines?.length) bits.push(`removed ${d.removedLines.length} repeated line${d.removedLines.length === 1 ? '' : 's'}`);
      if (d.pageNumbers) bits.push(`${d.pageNumbers} page numbers`);
      if (d.repairedMathLetters) bits.push('repaired doubled maths letters');
      return setStep('clean', 'done', `${fmtNum(d.words)} words on ${unitWord(read?.unit, d.pages)}${bits.length ? ` — ${bits.join(', ')}` : ' — nothing to remove'}.`,
        removed ? `<div class="pdetail">Removed as headers or footers:<ul>${removed}</ul></div>` : '');
    }
    if (s.id === 'check') {
      if (s.status === 'run') return setStep('check', 'run', intent === 'hub' ? 'Checking for duplicates; Claude reviews whether it fits the course…' : 'Checking for duplicates…');
      if (s.status === 'skip') return setStep('check', 'skip', esc(d.note || 'Not needed for private documents.'));
      if (d.duplicateOf) return setStep('check', 'done', 'This document is already in the hub.');
      if (d.decision) {
        const topics = (d.topics || []).map((t) => `<span class="chip line">${esc(t)}</span>`).join(' ');
        return setStep('check', s.status, d.decision === 'publish'
          ? `Fits the course: <b>${esc(d.moduleTitle)}</b>. ${esc(d.reason)}`
          : `Not added: ${esc(d.reason)}`,
          `<div class="pdetail">${d.summary ? `${esc(d.summary)}<br>` : ''}${topics ? `<div style="margin-top:6px;display:flex;gap:6px;flex-wrap:wrap">${topics}</div>` : ''}</div>`);
      }
      return setStep('check', s.status, s.status === 'fail' ? 'Stopped.' : 'Checked.');
    }
    if (s.id === 'chunk') {
      if (s.status === 'run') return setStep('chunk', 'run', 'Cutting the text into chunks…');
      const u = read?.unit === 'slide' ? ['slide', 'slides'] : read?.unit === 'sheet' ? ['sheet', 'sheets'] : read?.unit === 'section' ? ['section', 'sections'] : ['page', 'pages'];
      const prev = (d.preview || []).map((c, i) => `<div style="--ck:${CK[i % CK.length]}"><b>Chunk ${c.n}</b><span class="muted">${c.pages[0] === c.pages[1] ? `${u[0]} ${c.pages[0]}` : `${u[1]} ${c.pages[0]}–${c.pages[1]}`} · ${c.words} words</span>${(c.keywords || []).slice(0, 4).map((k) => `<span class="chip line">${esc(k)}</span>`).join('')}</div>`).join('');
      return setStep('chunk', 'done', `${d.chunks} chunk${d.chunks === 1 ? '' : 's'} of about ${d.avgWords} words — ${esc(d.rule || '')}.`, prev ? `<div class="ck-mini">${prev}</div>` : '');
    }
    if (s.id === 'publish') {
      if (s.status === 'run') return setStep('publish', 'run', 'Saving the document to the hub’s repository…');
      if (s.status === 'skip') return setStep('publish', 'skip', esc(d.note || 'Not published.'));
      if (d.mode === 'pull-request') return setStep('publish', 'done', `Pull request opened${d.url ? ` — <a href="${esc(d.url)}" target="_blank" rel="noopener">view it on GitHub</a>` : ''}. It goes live when the hub owner merges it.`);
      if (d.mode === 'local') return setStep('publish', 'done', 'Saved to data/docs on this server — live now.');
      return setStep('publish', 'done', `Committed to the repository${d.url ? ` — <a href="${esc(d.url)}" target="_blank" rel="noopener">view the commit</a>` : ''}. The site redeploys with it in about a minute.`);
    }
  };

  const keepPrivately = (doc, extra = {}) => {
    const copy = { ...doc, ...extra, origin: extra.origin || 'private', savedAt: new Date().toISOString() };
    state.privateDocs = state.privateDocs.filter((d) => d.id !== copy.id).concat(copy);
    const allKept = save.privateDocs();
    if (!allKept) toast('This browser’s storage is full: older private documents were removed.', 'err', 5000);
    return copy;
  };

  const showResult = (tone, message, actions = '') => {
    pipeCard.querySelector('.result').innerHTML = `<div class="verdict ${tone}">${message}</div><div class="result-actions">${actions}<button class="btn" data-a="another">${icon('add', 16)}Add another file</button></div>`;
    pipeCard.querySelector('[data-a="another"]').addEventListener('click', () => { file = null; read = null; pipeCard.hidden = true; drawChoose(); window.scrollTo({ top: 0, behavior: 'smooth' }); });
  };

  const onResult = (r) => {
    const open = (id) => `<a class="btn primary" href="#/doc/${encodeURIComponent(id)}">${icon('ask', 16)}Talk to it now</a>`;
    if (r.decision === 'published') {
      keepPrivately(r.doc, { origin: 'private', pendingPublish: r.publish?.mode !== 'local' });
      if (r.publish?.mode === 'local') ctx.refreshCatalog();
      showResult('ok', `<b>Added to the hub.</b> ${r.publish?.mode === 'local' ? 'Everyone can ask about it now.' : 'Everyone can ask about it in about a minute, once the site has redeployed. You can talk to it right away.'}`, open(r.doc.id));
    } else if (r.decision === 'pending') {
      keepPrivately(r.doc, { origin: 'private', pendingPublish: true });
      showResult('wait', `<b>Waiting for approval.</b> The hub owner reviews the pull request; after the merge it is live for everyone. You can talk to it right away.`, open(r.doc.id) + (r.publish?.url ? `<a class="btn" href="${esc(r.publish.url)}" target="_blank" rel="noopener">${icon('external', 15)}Pull request</a>` : ''));
    } else if (r.decision === 'private') {
      keepPrivately(r.doc);
      showResult('ok', '<b>Ready.</b> The document is kept in this browser only. Open it to ask questions about it.', open(r.doc.id));
    } else if (r.decision === 'already') {
      showResult('wait', esc(r.reason || 'This document is already in the hub.'), r.docId ? `<a class="btn primary" href="#/doc/${encodeURIComponent(r.docId)}">${icon('docs', 16)}Open it</a>` : '');
    } else if (r.decision === 'declined') {
      showResult('no', `<b>Not added to the hub.</b> ${esc(r.reason || '')}`, r.doc ? '<button class="btn primary" data-a="keep">Keep it just for me</button>' : '');
      const keep = pipeCard.querySelector('[data-a="keep"]');
      keep?.addEventListener('click', () => { const d = keepPrivately(r.doc); ctx.go(`#/doc/${encodeURIComponent(d.id)}`); });
    } else if (r.decision === 'unavailable') {
      showResult('no', esc(r.reason || 'Adding to the hub is not available.'), '');
    }
    fileCard.querySelector('[data-a="go"]')?.removeAttribute('disabled');
  };

  drawChoose();
  return { leave: () => req?.abort() };
}
