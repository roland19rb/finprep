// Documents: the list of everything in the hub, and the document view where a student reads a
// document (with its chunks marked) and talks to it.

import { state, save, findDoc } from './state.js';
import { getJson } from './api.js';
import { html, raw, ic, icon, el, esc, fmtNum, timeAgo, docIcon, unitWord, toast } from './ui.js';
import { renderMarkdown } from './markdown.js';
import { TurnView, newTurn, historyFrom, MODES } from './answer.js';
import { askBox } from './ask.js';

const CK_COLORS = ['#7aa2ec', '#4fb3c2', '#e2b04a', '#6cc191', '#a3adbd', '#e48f86'];
// panes scroll inside themselves on wide screens; on phones the page itself scrolls
const scrolls = (node) => /(auto|scroll)/.test(getComputedStyle(node).overflowY);

// ------------------------------------------------------------------ list

export function renderDocs(main, ctx, params) {
  let q = params.get('q') || '';
  let mod = params.get('m') || '';
  const { modules, docs } = state.catalog;
  const page = el(html`<div class="wrap">
    <div class="page-head"><div><h1>Documents</h1>
    <p>${fmtNum(docs.length)} documents in the hub. Open one to read it and ask questions about it.</p></div></div>
    <div class="filters">
      <label class="search-in">${ic('search', 17)}<input type="search" placeholder="Filter by title or topic" value="${q}" aria-label="Filter documents"></label>
      <div class="fchips"></div>
    </div>
    <div class="groups"></div></div>`);
  const chipsEl = page.querySelector('.fchips');
  const groupsEl = page.querySelector('.groups');
  const used = modules.filter((m) => docs.some((d) => d.module === m.id && d.origin === 'course'));
  const filters = [['', 'All'], ...used.map((m) => [m.id, m.title]), ['added', 'Added by the class'], ['mine', 'Only for me']];

  const match = (d) => {
    if (!q) return true;
    const hay = `${d.title} ${d.kind} ${d.moduleTitle || ''} ${(d.keywords || []).join(' ')} ${(d.outline || []).map((o) => o.title).join(' ')} ${d.summary || ''}`.toLowerCase();
    return q.toLowerCase().split(/\s+/).every((w) => hay.includes(w));
  };
  const row = (d, { removable = false } = {}) => {
    const ic2 = docIcon(d);
    const added = d.added || (d.origin === 'private' ? { at: d.savedAt } : null);
    return html`<a class="doc-row" href="#/doc/${encodeURIComponent(d.id)}">
      <span class="doc-ico ${ic2.cls}">${ic(ic2.name, 18)}</span>
      <span class="doc-main"><span class="doc-title">${d.title}</span>
      <span class="doc-meta"><span>${d.kind}</span><span>${unitWord(d.unit, d.stats?.pages || 0)}</span><span>${fmtNum(d.stats?.chunks || 0)} chunks</span>
      ${d.origin === 'added' && added ? html`<span>${added.by ? `added by ${added.by}` : 'added by a student'}${added.at ? ` · ${timeAgo(added.at)}` : ''}</span>` : ''}
      ${d.pendingPublish ? html`<span class="chip amber">publishing</span>` : ''}
      ${d.transcribed ? html`<span>transcribed from scanned pages</span>` : ''}</span></span>
      ${removable ? html`<button class="x" data-remove="${d.id}" aria-label="Remove ${d.title} from this browser" title="Remove from this browser">${ic('trash', 16)}</button>` : ''}</a>`;
  };

  const draw = () => {
    chipsEl.innerHTML = filters.map(([id, label]) => html`<button class="fchip ${id === mod ? 'on' : ''}" data-m="${id}">${label}</button>`.html).join('');
    const groups = [];
    for (const m of used) {
      if (mod && mod !== m.id) continue;
      const list = docs.filter((d) => d.module === m.id && d.origin === 'course' && match(d));
      if (list.length) groups.push(html`<section class="group"><div class="group-h"><h2>${m.title}</h2><span class="muted">${list.length}</span></div><div class="doc-list">${list.map((d) => row(d))}</div></section>`);
    }
    if (!mod || mod === 'added') {
      const list = docs.filter((d) => d.origin === 'added' && match(d));
      if (list.length || mod === 'added') groups.push(html`<section class="group"><div class="group-h"><h2>Added by the class</h2><span class="muted">${list.length}</span></div>
        ${list.length ? html`<div class="doc-list">${list.map((d) => row(d))}</div>` : html`<div class="empty">Nothing added yet. <a href="#/add">Add the first document</a>.</div>`}</section>`);
    }
    if (!mod || mod === 'mine') {
      const list = state.privateDocs.filter(match);
      if (list.length || mod === 'mine') groups.push(html`<section class="group"><div class="group-h"><h2>Only for me</h2><span class="muted">${list.length} · kept in this browser</span></div>
        ${list.length ? html`<div class="doc-list">${list.map((d) => row(d, { removable: true }))}</div>` : html`<div class="empty">Documents you add “only for me” appear here. <a href="#/add">Add one</a>.</div>`}</section>`);
    }
    groupsEl.innerHTML = groups.length ? groups.map((g) => g.html).join('') : '<div class="empty">No document matches this filter.</div>';
  };

  chipsEl.addEventListener('click', (e) => {
    const b = e.target.closest('[data-m]');
    if (!b) return;
    mod = b.dataset.m;
    history.replaceState(null, '', `#/docs${mod ? `?m=${mod}` : ''}`);
    draw();
  });
  page.querySelector('input').addEventListener('input', (e) => { q = e.target.value; draw(); });
  groupsEl.addEventListener('click', (e) => {
    const x = e.target.closest('[data-remove]');
    if (!x) return;
    e.preventDefault();
    state.privateDocs = state.privateDocs.filter((d) => d.id !== x.dataset.remove);
    delete state.docThreads[x.dataset.remove];
    save.privateDocs();
    save.docThreads();
    toast('Removed from this browser.');
    draw();
  });
  draw();
  main.innerHTML = '';
  main.appendChild(page);
  return {};
}

// ------------------------------------------------------------------ one document

async function loadDoc(id) {
  const mine = state.privateDocs.find((d) => d.id === id);
  if (mine) return mine;
  if (state.docCache.has(id)) return state.docCache.get(id);
  const d = await getJson(`/api/doc?id=${encodeURIComponent(id)}`);
  state.docCache.set(id, d);
  return d;
}

function pageBody(text) {
  if (!text.trim()) return '<div class="pg-empty">No text on this page (a picture or chart only).</div>';
  const blocks = text.split(/\n{2,}/);
  return blocks.map((b) => {
    const isTable = /^\s*\|.*\|\s*$/m.test(b) && /^\s*\|?\s*:?-{2,}/m.test(b);
    if (isTable || /\\\(|\\\[/.test(b)) return `<div class="pg-body md">${renderMarkdown(b).html}</div>`;
    return `<div class="pg-body">${esc(b)}</div>`;
  }).join('');
}

function chunkLabel(c, doc) {
  const span = c.pages[0] === c.pages[1] ? `${doc.unit === 'sheet' ? 'sheet' : doc.unit === 'slide' ? 'slide' : 'page'} ${c.pages[0]}` : `${doc.unit === 'slide' ? 'slides' : 'pages'} ${c.pages[0]}–${c.pages[1]}`;
  return html`<b>Chunk ${c.n}</b><span>${span} · ${fmtNum(c.words)} words</span>${(c.keywords || []).slice(0, 4).map((k) => html`<span class="chip line">${k}</span>`)}`;
}

function pagesView(doc) {
  const chunks = doc.chunks || [];
  const pageCard = (p) => html`<article class="pg" id="pg-${p.n}" data-p="${p.n}">
    <div class="pg-h"><span class="pg-n">${p.label || `Page ${p.n}`}</span>${p.title ? html`<span class="pg-t">${p.title}</span>` : ''}${p.section ? html`<span class="pg-s">${p.section}</span>` : ''}</div>
    ${raw(pageBody(p.text || ''))}</article>`;
  // consecutive pages that belong to the same chunk(s) are shown together under one chunk label
  const groups = [];
  for (const p of doc.pages) {
    const ids = chunks.filter((c) => p.n >= c.pages[0] && p.n <= c.pages[1]);
    const key = ids.map((c) => c.n).join(',');
    const last = groups[groups.length - 1];
    if (last && last.key === key) last.pages.push(p);
    else groups.push({ key, chunks: ids, pages: [p] });
  }
  return groups.map((g) => {
    if (!g.chunks.length) return html`<div class="ck-group" style="--ck:#d5dbe3"><div class="ck-label"><span>Not in any chunk (no text on ${g.pages.length === 1 ? 'this page' : 'these pages'})</span></div>${g.pages.map(pageCard)}</div>`.html;
    const first = g.chunks[0];
    const color = CK_COLORS[(first.n - 1) % CK_COLORS.length];
    const label = g.chunks.length === 1
      ? chunkLabel(first, doc)
      : html`<b>Chunks ${g.chunks.map((c) => c.n).join(', ')}</b><span>${g.chunks.length} chunks share ${g.pages.length === 1 ? 'this page' : 'these pages'} (a long page is split, or chunks overlap)</span>`;
    return html`<div class="ck-group" style="--ck:${color}"><div class="ck-label">${label}</div>${g.pages.map(pageCard)}</div>`.html;
  }).join('');
}

function chunksView(doc) {
  return (doc.chunks || []).map((c, i) => html`<article class="ck-card" style="--ck:${CK_COLORS[i % CK_COLORS.length]}" data-ck="${c.n}">
    <div class="ck-label">${chunkLabel(c, doc)}${c.overlap ? html`<span>· first ${c.overlap} words repeat the previous chunk</span>` : ''}${c.kind === 'overview' ? html`<span class="chip">overview, ranked lower</span>` : ''}</div>
    ${c.section || c.title ? html`<div class="pg-s">${[c.section, c.title].filter(Boolean).join(' · ')}</div>` : ''}
    <pre>${c.text}</pre></article>`.html).join('');
}

function quickActions(doc) {
  if (doc.unit === 'sheet') {
    return [
      ['Explain this workbook', 'Explain this workbook: what each sheet does, how the sheets connect, and how the main formulas work.', 'explained'],
      ['Key formulas', 'List the key formulas in this workbook. For each one: where it is, what it calculates and what every input means.', 'explained'],
    ];
  }
  return [
    ['Summarise', 'Summarise this document: the main ideas, the key formulas or figures, and how the parts connect.', 'explained'],
    ['Key formulas & terms', 'List the key formulas, definitions and rules in this document. For each: the formula or definition, what every symbol means, and the page.', 'explained'],
    ['Draw it', 'Draw the structure of this document: its main ideas and how they connect.', 'visual'],
  ];
}

export async function renderDoc(main, ctx, id, params) {
  main.innerHTML = `<div class="loading"><span class="a-status"><span class="spin"></span></span>Opening the document…</div>`;
  let doc;
  try {
    doc = await loadDoc(id);
  } catch (e) {
    if (e.status === 401) { ctx.needCode(); return {}; }
    main.innerHTML = html`<div class="wrap"><div class="empty">${e.message || 'The document could not be opened.'} <a href="#/docs">Back to documents</a></div></div>`.html;
    return {};
  }
  const isPrivate = doc.origin === 'private' || !!state.privateDocs.find((d) => d.id === doc.id);
  const turns = (state.docThreads[doc.id] ||= []);
  const views = [];
  const page = el(html`<div class="wrap">
    <a class="dv-back" href="#/docs">${ic('back', 16)}Documents</a>
    <div class="dv-head"><div style="min-width:0;flex:1">
      <h1>${doc.title}</h1>
      <div class="dv-chips">
        <span class="chip accent">${doc.moduleTitle || 'Your document'}</span><span class="chip">${doc.kind}</span>
        <span class="chip">${unitWord(doc.unit, doc.pages.length)} · ${fmtNum(doc.stats?.words || 0)} words · ${fmtNum((doc.chunks || []).length)} chunks</span>
        ${isPrivate ? html`<span class="chip teal">${ic('lock', 13)}only in this browser</span>` : ''}
        ${doc.origin === 'added' ? html`<span class="chip teal">${ic('users', 13)}${doc.added?.by ? `added by ${doc.added.by}` : 'added by a student'}</span>` : ''}
        ${doc.pendingPublish ? html`<span class="chip amber">publishing — live for everyone in about a minute</span>` : ''}
      </div>
      ${doc.note || doc.summary ? html`<p class="dv-note">${doc.summary || ''} ${doc.note || ''}</p>` : ''}
      ${doc.transcribed ? html`<p class="dv-note">This document is a scan; its text was transcribed from the page images.</p>` : ''}
    </div></div>
    <div class="dv-tabs seg" role="tablist"><button class="on" data-pane="doc" role="tab">${ic('docs', 16)}Document</button><button data-pane="chat" role="tab">${ic('ask', 16)}Ask about it</button></div>
    <div class="dv" data-pane="doc">
      <section class="pane doc-pane">
        <div class="pane-h"><h3>Document</h3><span class="spacer"></span>
          <div class="seg" data-view><button class="on" data-v="pages">Pages</button><button data-v="chunks" title="The pieces the search works on">Chunks</button></div></div>
        ${doc.outline?.length ? html`<div class="outline">${doc.outline.map((o) => html`<button data-goto="${o.from}" title="${o.title}">${o.title}</button>`)}</div>` : ''}
        <div class="doc-scroll"></div>
      </section>
      <section class="pane chat-pane">
        <div class="pane-h"><h3>Ask about this document</h3><span class="spacer"></span><button class="btn ghost small" data-a="clear" title="Start over">${ic('refresh', 15)}</button></div>
        <div class="chat"><div class="chat-scroll"><div class="chat-start">
          Questions here are answered from this document only, with page references you can click.
          <div class="quick">${quickActions(doc).map(([label, , mode]) => html`<button class="btn small" data-quick="${label}">${ic(MODES[mode].icon, 15)}${label}</button>`)}</div>
        </div><div class="turns"></div></div><div class="box-slot"></div></div>
      </section>
    </div></div>`);
  main.innerHTML = '';
  main.appendChild(page);

  const dv = page.querySelector('.dv');
  // the two panes fill the rest of the window, so the ask box is always in view
  const fit = () => {
    const top = dv.getBoundingClientRect().top + window.scrollY;
    dv.style.setProperty('--pane-h', `${Math.max(440, window.innerHeight - top - 14)}px`);
  };
  fit();
  window.addEventListener('resize', fit);
  const scroller = page.querySelector('.doc-scroll');
  const turnsEl = page.querySelector('.chat .turns');
  const chatScroll = page.querySelector('.chat-scroll');
  let viewMode = 'pages';
  const drawDoc = () => {
    scroller.innerHTML = viewMode === 'pages' ? pagesView(doc) : chunksView(doc);
  };
  drawDoc();

  const setPane = (p) => {
    dv.dataset.pane = p;
    page.querySelectorAll('.dv-tabs [data-pane]').forEach((b) => b.classList.toggle('on', b.dataset.pane === p));
  };
  page.querySelector('.dv-tabs').addEventListener('click', (e) => { const b = e.target.closest('[data-pane]'); if (b) setPane(b.dataset.pane); });
  page.querySelector('[data-view]').addEventListener('click', (e) => {
    const b = e.target.closest('[data-v]');
    if (!b) return;
    viewMode = b.dataset.v;
    page.querySelectorAll('[data-view] button').forEach((x) => x.classList.toggle('on', x === b));
    drawDoc();
  });

  const gotoPage = (n) => {
    setPane('doc');
    if (viewMode !== 'pages') { viewMode = 'pages'; page.querySelectorAll('[data-view] button').forEach((x) => x.classList.toggle('on', x.dataset.v === 'pages')); drawDoc(); }
    const card = scroller.querySelector(`#pg-${n}`) || [...scroller.querySelectorAll('.pg')].find((c) => Number(c.dataset.p) >= n);
    if (!card) return;
    scroller.querySelectorAll('.pg.hl').forEach((c) => c.classList.remove('hl'));
    card.classList.add('hl');
    const top = card.getBoundingClientRect().top - scroller.getBoundingClientRect().top + scroller.scrollTop - 10;
    if (scrolls(scroller)) scroller.scrollTo({ top, behavior: 'smooth' });
    else card.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };
  page.querySelector('.outline')?.addEventListener('click', (e) => { const b = e.target.closest('[data-goto]'); if (b) gotoPage(Number(b.dataset.goto)); });

  const payloadDoc = () => {
    if (!isPrivate) return { docId: doc.id };
    const chars = doc.pages.reduce((s, p) => s + p.text.length, 0);
    return {
      privateDoc: {
        id: doc.id, title: doc.title, kind: doc.kind, unit: doc.unit, moduleTitle: doc.moduleTitle,
        pages: doc.pages.map((p) => ({ n: p.n, label: p.label, title: p.title, section: p.section, text: p.text })),
        ...(chars > 140000 ? { chunks: doc.chunks.map((c) => ({ id: c.id, n: c.n, pages: c.pages, section: c.section, title: c.title, kind: c.kind, text: c.text })) } : {}),
      },
    };
  };

  let box;
  const mount = (turn) => {
    const tv = new TurnView(turn, {
      docMode: true,
      onPage: (n) => gotoPage(n),
      onReask: (t, mode) => ask(t.question, mode, { label: `Same question · ${MODES[mode].label}` }),
      onCheckAgain: (t, note) => ask(t.question, t.mode, { label: 'Checked again after “Not right”', feedback: { previousAnswer: t.text, note } }),
      onChange: () => save.docThreads(),
      onNeedsCode: () => ctx.needCode(),
    });
    views.push(tv);
    turnsEl.appendChild(tv.el);
    return tv;
  };
  const ask = (question, mode, extra = {}) => {
    const prior = turns.slice();
    const turn = newTurn({ question, mode, docId: doc.id, ...extra });
    turns.push(turn);
    save.docThreads();
    const tv = mount(turn);
    setPane('chat');
    requestAnimationFrame(() => {
      if (scrolls(chatScroll)) chatScroll.scrollTop = tv.el.offsetTop - 8;
      else tv.el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
    box.setBusy(true);
    tv.start({ question, mode, history: historyFrom(prior), feedback: turn.feedback, ...payloadDoc() })
      .finally(() => { box.setBusy(false); save.docThreads(); });
  };
  box = askBox({ placeholder: `Ask about “${doc.title.length > 40 ? doc.title.slice(0, 38) + '…' : doc.title}”…`, withScope: false, onSubmit: (q, m) => ask(q, m) });
  page.querySelector('.box-slot').replaceWith(box.el);
  page.querySelector('.quick').addEventListener('click', (e) => {
    const b = e.target.closest('[data-quick]');
    if (!b) return;
    const qa = quickActions(doc).find(([l]) => l === b.dataset.quick);
    if (qa) ask(qa[1], qa[2], { label: qa[0] });
  });
  page.querySelector('[data-a="clear"]').addEventListener('click', () => {
    views.forEach((v) => v.stop());
    views.length = 0;
    turns.length = 0;
    save.docThreads();
    turnsEl.innerHTML = '';
  });
  for (const t of turns) {
    const tv = mount(t);
    const pending = tv.attach();
    if (pending) { box.setBusy(true); pending.finally(() => { box.setBusy(false); save.docThreads(); }); }
  }
  if (turns.length) requestAnimationFrame(() => { chatScroll.scrollTop = chatScroll.scrollHeight; });
  const p = Number(params.get('p'));
  if (p) requestAnimationFrame(() => setTimeout(() => gotoPage(p), 60));
  return { leave: () => { save.docThreads(); window.removeEventListener('resize', fit); } };
}
