// "How it works": the three flows of the hub in one picture, in plain words.

import { state } from './state.js';
import { html, ic, modal, fmtNum } from './ui.js';

const arrow = ic('next', 20, 2);

function flow(boxes) {
  return html`<div class="flow">${boxes.map(([title, text, key], i) => html`${i ? html`<span class="arr">${arrow}</span>` : ''}<div class="fbox ${key ? 'key' : ''}"><b>${title}</b><span>${text}</span></div>`)}</div>`;
}

export function showHow() {
  const s = state.catalog?.stats || {};
  const cfg = state.config || {};
  const body = html`
    <div class="how-row"><h3>${ic('ask', 18)}Ask the course</h3>${flow([
      ['Your question', 'Choose Short, Explained or Visual. Follow-up questions keep the context.'],
      ['Search', `The agent searches ${fmtNum(s.chunks)} chunks from ${fmtNum(s.documents)} documents for the best passages.`],
      ['Read and search again', 'If the passages are not enough it searches with other words or reads whole slides and sheets.'],
      ['Answer with sources', 'Every statement cites the document and slide it comes from; click a number to see it.', true],
    ])}</div>
    <div class="how-row"><h3>${ic('docs', 18)}Talk to a document</h3>${flow([
      ['Open a document', 'Any lecture, case, exercise file — or one you added.'],
      ['The agent reads it', 'The whole document (or the right parts of a very long one).'],
      ['Answers with page links', 'References like p. 12 jump to the page; Summarise, Key formulas and Draw it are one click.', true],
    ])}</div>
    <div class="how-row"><h3>${ic('upload', 18)}Add knowledge</h3>${flow([
      ['Read', 'Your file becomes pages of text, in your browser.'],
      ['Clean', 'Headers, footers and page numbers go; broken lines are joined.'],
      ['Check', 'Fits the course? Already in the hub? Personal data? Claude decides.'],
      ['Chunk', 'Cut into chunks that follow the slides and sections.'],
      ['Publish', cfg.sharing?.mode === 'pull-request' ? 'A pull request on GitHub; live when the owner merges it.' : 'Saved in the hub’s repository; live after the site redeploys.', true],
    ])}</div>
    <div class="how-note"><b>Where answers come from.</b> Only from the course materials and the documents the class added. When something is not covered, the answer says so; a short general explanation is then marked <span class="chip teal">General knowledge</span>. Important numbers are worth checking against the slide the answer cites.<br><br>
    <b>How the materials are chunked.</b> Slides are grouped by section into chunks of about 230 words; running headers, footers and page numbers are removed first. Long texts (cases, notes) become chunks of about 300 words that overlap by a sentence or two. Every sheet of an Excel file is one chunk with its labels, values and formulas. Open any document and switch to <b>Chunks</b> to see them.<br><br>
    <span class="muted">Answers: ${cfg.models?.answer || ''} · checks: ${cfg.models?.helper || ''}</span></div>`;
  modal({ title: 'How the hub works', body });
}
