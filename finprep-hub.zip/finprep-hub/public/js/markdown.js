// Safe Markdown → HTML for answers: headings, lists, tables, code, formulas (KaTeX),
// citations [3] / [p. 12], the "Outside the course materials" note and visual blocks.
// Everything from the model is escaped; only the tags produced here reach the page.

import { esc } from './ui.js';

const T = (i) => `\u0000${i}\u0000`;

function renderMath(tex, display) {
  const k = window.katex;
  if (!k) return `<code>${esc(tex)}</code>`;
  try {
    return k.renderToString(tex, { displayMode: display, throwOnError: false, strict: 'ignore', trust: false, output: 'html' });
  } catch {
    return `<code>${esc(tex)}</code>`;
  }
}

function cutUnfinished(src) {
  // while an answer streams in, hide a formula or table row that has started but not finished
  for (const [open, close] of [['\\[', '\\]'], ['\\(', '\\)'], ['$$', '$$']]) {
    const i = src.lastIndexOf(open);
    if (i >= 0) {
      const after = src.slice(i + open.length);
      if (!after.includes(close)) src = src.slice(0, i);
    }
  }
  return src;
}

function inline(text, ctx) {
  // text is already HTML-escaped; tokens \u0000n\u0000 are left alone
  const codes = [];
  let s = text.replace(/`([^`\n]+)`/g, (m, c) => { codes.push(`<code>${c}</code>`); return `\u0001${codes.length - 1}\u0001`; });
  s = s.replace(/\[([^\]\n]{1,120})\]\((https?:\/\/[^\s)]+)\)/g, (m, label, url) => `<a href="${url}" target="_blank" rel="noopener noreferrer">${label}</a>`);
  s = s.replace(/\*\*([^*\n]+?)\*\*/g, '<strong>$1</strong>').replace(/__([^_\n]+?)__/g, '<strong>$1</strong>');
  s = s.replace(/(^|[\s(>])\*([^*\s][^*\n]*?)\*(?=[\s).,;:!?<]|$)/g, '$1<em>$2</em>');
  s = s.replace(/(^|[\s(>])_([^_\s][^_\n]*?)_(?=[\s).,;:!?<]|$)/g, '$1<em>$2</em>');
  // page citations: [p. 12], [pp. 12–14], [p. 3, 5]
  s = s.replace(/\[(pp?\.)\s?(\d{1,4})(?:\s?[–-]\s?(\d{1,4}))?((?:\s*,\s*\d{1,4})*)\]/g, (m, pfx, a, b, more) => {
    let out = `<button class="cite page" data-p="${a}" title="Go to ${a}">${b ? `pp. ${a}–${b}` : `p. ${a}`}</button>`;
    for (const x of (more || '').split(',').map((v) => v.trim()).filter(Boolean)) out += `<button class="cite page" data-p="${x}">p. ${x}</button>`;
    ctx.pages.add(Number(a));
    return out;
  });
  // numbered citations: [3], [1, 4], [2–4]
  s = s.replace(/\[(\d{1,3}(?:\s*[,–-]\s*\d{1,3})*)\]/g, (m, inner) => {
    const nums = [];
    for (const part of inner.split(',')) {
      const r = part.split(/[–-]/).map((v) => Number(v.trim()));
      if (r.length === 2 && r[1] >= r[0] && r[1] - r[0] < 10) for (let k = r[0]; k <= r[1]; k++) nums.push(k);
      else if (Number.isFinite(r[0])) nums.push(r[0]);
    }
    return nums.map((n) => {
      ctx.cited.add(n);
      const known = !ctx.sources || ctx.sources.has(n);
      const title = known && ctx.sources ? esc(ctx.sources.get(n)?.title || '') : 'source';
      return `<button class="cite${known ? '' : ' missing'}" data-n="${n}" title="${title}">${n}</button>`;
    }).join('');
  });
  s = s.replace(/\u0001(\d+)\u0001/g, (m, i) => codes[Number(i)]);
  return s;
}

function splitRow(line) {
  let l = line.trim();
  if (l.startsWith('|')) l = l.slice(1);
  if (l.endsWith('|') && !l.endsWith('\\|')) l = l.slice(0, -1);
  return l.split(/(?<!\\)\|/).map((c) => c.trim().replace(/\\\|/g, '|'));
}

const SEP = /^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$/;

/**
 * @param {string} src
 * @param {{streaming?:boolean, sources?:Map<number,object>}} opts
 * @returns {{html:string, visuals:Array<{kind:string, src:string, complete:boolean}>, cited:Set<number>, pages:Set<number>}}
 */
export function renderMarkdown(src, { streaming = false, sources = null } = {}) {
  const ctx = { cited: new Set(), pages: new Set(), sources };
  const tokens = [];
  const visuals = [];
  let s = String(src || '').replace(/\r\n?/g, '\n');

  // fenced blocks (a visual block may still be open while streaming)
  if (streaming) s = s.replace(/```[\w-]*$/, '');
  s = s.replace(/```([\w-]*)[^\n]*\n([\s\S]*?)(```|$(?![\s\S]))/g, (m, lang, body, close) => {
    const complete = close === '```';
    const l = (lang || '').toLowerCase();
    if (l === 'diagram' || l === 'chart' || l === 'mermaid') {
      const kind = l === 'chart' ? 'chart' : 'diagram';
      if (!complete && streaming) {
        tokens.push(`<div class="drawing"><span class="a-status"><span class="spin"></span></span>Drawing the ${kind}…</div>`);
      } else {
        visuals.push({ kind, src: body, complete });
        tokens.push(`<div class="viz-slot" data-viz="${visuals.length - 1}"></div>`);
      }
    } else {
      tokens.push(`<pre><code>${esc(body.replace(/\n$/, ''))}</code></pre>`);
    }
    return `\n${T(tokens.length - 1)}\n`;
  });

  if (streaming) s = cutUnfinished(s);

  // formulas
  s = s.replace(/\\\[([\s\S]+?)\\\]|\$\$([\s\S]+?)\$\$/g, (m, a, b) => {
    tokens.push(`<div class="katex-block">${renderMath((a ?? b).trim(), true)}</div>`);
    return `\n${T(tokens.length - 1)}\n`;
  });
  s = s.replace(/\\\(([\s\S]+?)\\\)/g, (m, a) => { tokens.push(renderMath(a.trim(), false)); return T(tokens.length - 1); });

  s = esc(s);
  const lines = s.split('\n');
  const out = [];
  let para = [];
  const flushPara = () => {
    if (!para.length) return;
    const text = para.join(' ').trim();
    para = [];
    if (!text) return;
    const html = inline(text, ctx);
    if (/^<strong>\s*Outside the course materials:?\s*<\/strong>/i.test(html)) {
      out.push(`<div class="general"><div class="general-label">General knowledge · not from the course materials</div><p>${html.replace(/^<strong>\s*Outside the course materials:?\s*<\/strong>\s*/i, '')}</p></div>`);
    } else out.push(`<p>${html}</p>`);
  };

  let i = 0;
  while (i < lines.length) {
    const line = lines[i];
    const t = line.trim();
    if (!t) { flushPara(); i++; continue; }
    const tok = t.match(/^\u0000(\d+)\u0000$/);
    if (tok) { flushPara(); out.push(tokens[Number(tok[1])]); i++; continue; }
    let m;
    if ((m = t.match(/^(#{1,6})\s+(.*)$/))) {
      flushPara();
      const lvl = Math.min(4, Math.max(3, m[1].length));
      out.push(`<h${lvl}>${inline(m[2].replace(/\s*#+\s*$/, ''), ctx)}</h${lvl}>`);
      i++; continue;
    }
    if (/^(-{3,}|\*{3,}|_{3,})$/.test(t)) { flushPara(); out.push('<hr>'); i++; continue; }
    if (t.includes('|') && i + 1 < lines.length && SEP.test(lines[i + 1])) {
      flushPara();
      const head = splitRow(t);
      i += 2;
      const rows = [];
      while (i < lines.length && lines[i].includes('|') && lines[i].trim()) { rows.push(splitRow(lines[i])); i++; }
      out.push(`<table><thead><tr>${head.map((c) => `<th>${inline(c, ctx)}</th>`).join('')}</tr></thead><tbody>${rows.map((r) => `<tr>${head.map((_, k) => `<td>${inline(r[k] || '', ctx)}</td>`).join('')}</tr>`).join('')}</tbody></table>`);
      continue;
    }
    if (/^&gt;\s?/.test(t)) {
      flushPara();
      const q = [];
      while (i < lines.length && /^&gt;\s?/.test(lines[i].trim())) { q.push(lines[i].trim().replace(/^&gt;\s?/, '')); i++; }
      const inner = q.join(' ');
      if (/^\*\*\s*Outside the course materials/i.test(inner)) {
        out.push(`<div class="general"><div class="general-label">General knowledge · not from the course materials</div><p>${inline(inner.replace(/^\*\*\s*Outside the course materials:?\s*\*\*\s*/i, ''), ctx)}</p></div>`);
      } else out.push(`<blockquote><p>${inline(inner, ctx)}</p></blockquote>`);
      continue;
    }
    if ((m = line.match(/^(\s*)([-*+•]|\d{1,3}[.)])\s+(.*)$/))) {
      flushPara();
      // collect the list block
      const items = [];
      const LI = /^(\s*)([-*+•]|\d{1,3}[.)])\s+(.*)$/;
      const baseIndent = m[1].replace(/\t/g, '    ').length;
      const baseOrdered = /\d/.test(m[2]);
      const sameList = (lm) => lm && (lm[1].replace(/\t/g, '    ').length > baseIndent || /\d/.test(lm[2]) === baseOrdered);
      while (i < lines.length) {
        const l = lines[i];
        const lm = l.match(LI);
        if (lm) {
          if (!sameList(lm)) break;
          items.push({ indent: lm[1].replace(/\t/g, '    ').length, ordered: /\d/.test(lm[2]), start: parseInt(lm[2], 10), text: lm[3] });
          i++;
          continue;
        }
        if (l.trim() && /^\s{2,}\S/.test(l) && items.length) { items[items.length - 1].text += ' ' + l.trim(); i++; continue; }
        if (!l.trim() && i + 1 < lines.length && sameList(lines[i + 1].match(LI))) { i++; continue; }
        break;
      }
      out.push(renderList(items, ctx));
      continue;
    }
    para.push(t);
    i++;
  }
  flushPara();
  let html = out.join('\n');
  html = html.replace(/\u0000(\d+)\u0000/g, (m, k) => tokens[Number(k)] || '');
  return { html, visuals, cited: ctx.cited, pages: ctx.pages };
}

function renderList(items, ctx) {
  const base = Math.min(...items.map((x) => x.indent));
  const build = (start, indent) => {
    const ordered = items[start].ordered;
    const startNum = ordered && items[start].start > 1 ? ` start="${items[start].start}"` : '';
    let h = ordered ? `<ol${startNum}>` : '<ul>';
    let k = start;
    while (k < items.length && items[k].indent >= indent) {
      if (items[k].indent > indent) {
        const [inner, next] = build(k, items[k].indent);
        h = h.replace(/<\/li>$/, '') + inner + '</li>';
        k = next;
        continue;
      }
      h += `<li>${inline(items[k].text, ctx)}</li>`;
      k++;
    }
    return [h + (ordered ? '</ol>' : '</ul>'), k];
  };
  let html = '';
  let k = 0;
  while (k < items.length) {
    const [h, next] = build(k, base);
    html += h;
    k = next === k ? k + 1 : next;
  }
  return html;
}

/** Plain text of an answer, for copying. */
export function answerPlainText(src) {
  return String(src || '').replace(/```(diagram|chart)[\s\S]*?```/g, '[visual]').trim();
}
