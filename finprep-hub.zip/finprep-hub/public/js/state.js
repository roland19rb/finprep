// App state and what this browser remembers (access code, conversation, private documents).
// Browser storage can be missing or full; every read and write is wrapped so the page still works.

const KEY = {
  client: 'finprep.client',
  code: 'finprep.code',
  thread: 'finprep.thread.v1',
  docs: 'finprep.privateDocs.v1',
  mode: 'finprep.mode',
  docThreads: 'finprep.docThreads.v1',
};

function read(key, fallback) {
  try {
    const v = localStorage.getItem(key);
    return v == null ? fallback : JSON.parse(v);
  } catch {
    return fallback;
  }
}
function write(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch {
    return false;
  }
}

function clientId() {
  let id = read(KEY.client, '');
  if (!id) { id = Math.random().toString(36).slice(2, 12) + Date.now().toString(36); write(KEY.client, id); }
  return id;
}

export const state = {
  clientId: clientId(),
  config: null,
  catalog: null, // { modules, docs, stats }
  code: read(KEY.code, ''),
  mode: read(KEY.mode, 'explained'),
  module: '',
  thread: read(KEY.thread, []), // course conversation
  docThreads: read(KEY.docThreads, {}), // docId -> turns
  privateDocs: read(KEY.docs, []), // processed documents kept in this browser
  docCache: new Map(),
};

export const save = {
  code(v) { state.code = v; write(KEY.code, v); },
  mode(v) { state.mode = v; write(KEY.mode, v); },
  thread() { write(KEY.thread, state.thread.slice(-30).map(stripTurn)); },
  docThreads() {
    const out = {};
    for (const [id, turns] of Object.entries(state.docThreads)) out[id] = turns.slice(-12).map(stripTurn);
    write(KEY.docThreads, out);
  },
  privateDocs() {
    // keep the newest documents that fit into storage
    let docs = state.privateDocs.slice(-12);
    while (docs.length && !write(KEY.docs, docs)) docs = docs.slice(1);
    return docs.length === state.privateDocs.length;
  },
};

function stripTurn(t) {
  return {
    id: t.id, question: t.question, mode: t.mode, module: t.module || '', docId: t.docId || null,
    text: t.text || '', sources: t.sources || [], steps: (t.steps || []).slice(0, 12),
    status: t.status === 'run' ? 'stopped' : t.status, error: t.error || null, meta: t.meta || null,
    rating: t.rating || null, at: t.at, label: t.label || null,
  };
}

export function moduleTitle(id) {
  return state.catalog?.modules?.find((m) => m.id === id)?.title || (id === 'other' ? 'Other finance topics' : id);
}

export function findDoc(id) {
  return state.catalog?.docs?.find((d) => d.id === id) || state.privateDocs.find((d) => d.id === id) || null;
}
