// Step "Read": turn a file into pages of text, in the browser, before anything is uploaded.
// PDF (pdf.js), Word .docx, PowerPoint .pptx, Excel .xlsx, text and Markdown.
// The result has the same shape as the course-material extractor (scripts/extract_materials.py):
//   { unit: 'slide'|'page'|'section'|'sheet', pages: [{ n, title, text, marks? }] }

const MAX_PAGES = 400;

export const ACCEPT = '.pdf,.docx,.pptx,.xlsx,.txt,.md,.markdown';

export function fileKind(file) {
  const ext = (file.name.split('.').pop() || '').toLowerCase();
  if (ext === 'pdf' || file.type === 'application/pdf') return 'pdf';
  if (ext === 'docx') return 'docx';
  if (ext === 'pptx') return 'pptx';
  if (ext === 'xlsx') return 'xlsx';
  if (['txt', 'md', 'markdown'].includes(ext) || file.type.startsWith('text/')) return 'text';
  return null;
}

export async function extractFile(file, onProgress = () => {}) {
  const kind = fileKind(file);
  if (!kind) throw new Error('This file type is not supported. Use PDF, Word (.docx), PowerPoint (.pptx), Excel (.xlsx), text or Markdown.');
  if (file.size > 60 * 1024 * 1024) throw new Error('The file is larger than 60 MB.');
  let out;
  if (kind === 'pdf') out = await readPdf(file, onProgress);
  else if (kind === 'docx') out = await readDocx(file);
  else if (kind === 'pptx') out = await readPptx(file, onProgress);
  else if (kind === 'xlsx') out = await readXlsx(file);
  else out = await readText(file);
  out.pages = out.pages.slice(0, MAX_PAGES);
  out.fileType = kind === 'text' ? (file.name.split('.').pop() || 'txt').toLowerCase() : kind;
  out.words = out.pages.reduce((s, p) => s + (p.text.match(/[\p{L}\p{N}]+/gu) || []).length, 0);
  out.chars = out.pages.reduce((s, p) => s + p.text.length, 0);
  return out;
}

// ------------------------------------------------------------------ PDF

let pdfjsPromise = null;
function pdfjs() {
  if (!pdfjsPromise) {
    pdfjsPromise = import('/vendor/pdfjs/pdf.min.mjs').then((lib) => {
      lib.GlobalWorkerOptions.workerSrc = '/vendor/pdfjs/pdf.worker.min.mjs';
      return lib;
    });
  }
  return pdfjsPromise;
}

async function readPdf(file, onProgress) {
  const lib = await pdfjs();
  const data = new Uint8Array(await file.arrayBuffer());
  const doc = await lib.getDocument({ data, isEvalSupported: false, useSystemFonts: false, disableFontFace: true }).promise;
  const pages = [];
  let unit = 'page';
  const total = Math.min(doc.numPages, MAX_PAGES);
  for (let i = 1; i <= total; i++) {
    const page = await doc.getPage(i);
    const vp = page.getViewport({ scale: 1 });
    if (i === 1 && vp.width > vp.height) unit = 'slide';
    const tc = await page.getTextContent();
    pages.push(pdfPage(tc.items, vp.width, vp.height, i));
    page.cleanup();
    onProgress(i, total);
  }
  await doc.destroy();
  return { unit, pages };
}

function pdfPage(items, W, H, n) {
  // group text items into lines by their baseline
  const parts = items.filter((it) => it.str && it.str.trim() !== '' || it.hasEOL).map((it) => ({
    s: it.str, x: it.transform[4], y: it.transform[5], w: it.width, size: Math.hypot(it.transform[2], it.transform[3]) || it.height || 10,
  })).filter((p) => p.s);
  parts.sort((a, b) => b.y - a.y || a.x - b.x);
  const lines = [];
  for (const p of parts) {
    const line = lines.find((l) => Math.abs(l.y - p.y) <= Math.max(2, p.size * 0.35));
    if (line) line.items.push(p);
    else lines.push({ y: p.y, items: [p] });
  }
  for (const l of lines) {
    l.items.sort((a, b) => a.x - b.x);
    let text = '';
    let end = null;
    for (const it of l.items) {
      if (end !== null && it.x - end > it.size * 0.18 && !text.endsWith(' ') && !it.s.startsWith(' ')) text += ' ';
      text += it.s;
      end = it.x + it.w;
    }
    l.text = text.replace(/\s+/g, ' ').trim();
    l.size = Math.max(...l.items.map((it) => it.size));
    l.x = l.items[0].x;
  }
  const real = lines.filter((l) => l.text);
  real.sort((a, b) => b.y - a.y || a.x - b.x);
  if (!real.length) return { n, title: null, text: '' };
  const body = real.filter((l) => l.y > H * 0.125 && l.size >= 8);
  const weights = (body.length ? body : real).flatMap((l) => Array(Math.min(40, l.text.length)).fill(l.size)).sort((a, b) => a - b);
  const median = weights[Math.floor(weights.length / 2)] || 10;
  const wordy = (t) => !/=/.test(t) && (t.match(/\p{L}/gu) || []).length >= 3;
  const cands = real.filter((l) => l.y > H * 0.66 && wordy(l.text));
  let title = null;
  const used = new Set();
  if (cands.length) {
    const top = Math.max(...cands.map((c) => c.size));
    if (top >= median * 1.15 || (real.length <= 4 && top >= median)) {
      const picked = cands.filter((c) => Math.abs(c.size - top) < 0.6).sort((a, b) => b.y - a.y);
      const chosen = [picked[0]];
      for (const c of picked.slice(1)) { if (chosen[chosen.length - 1].y - c.y <= top * 1.9) chosen.push(c); else break; }
      title = chosen.map((c) => c.text).join(' ');
      chosen.forEach((c) => used.add(c));
    }
  }
  const marks = { top: [], bottom: [] };
  for (const l of real) {
    if (used.has(l)) continue;
    if (l.y >= H * 0.925 && l.text.split(' ').length <= 14) marks.top.push(l.text);
    else if (l.y <= H * 0.125 && l.size <= Math.max(10.5, median * 0.85)) marks.bottom.push(l.text);
  }
  // paragraphs: a larger vertical gap starts a new block
  const out = [];
  let prev = null;
  for (const l of real) {
    if (used.has(l)) continue;
    if (prev && prev.y - l.y > Math.max(prev.size, l.size) * 1.75) out.push('');
    out.push(l.text);
    prev = l;
  }
  const text = ((title ? title + '\n\n' : '') + out.join('\n')).trim();
  const page = { n, title, text };
  if (marks.top.length || marks.bottom.length) page.marks = marks;
  return page;
}

// ------------------------------------------------------------------ ZIP (docx, pptx, xlsx)

async function unzip(file) {
  const buf = new Uint8Array(await file.arrayBuffer());
  const dv = new DataView(buf.buffer);
  let eocd = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 70000); i--) {
    if (dv.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
  }
  if (eocd < 0) throw new Error('This file is damaged or not an Office document.');
  const count = dv.getUint16(eocd + 10, true);
  let off = dv.getUint32(eocd + 16, true);
  const entries = new Map();
  for (let k = 0; k < count; k++) {
    if (dv.getUint32(off, true) !== 0x02014b50) break;
    const method = dv.getUint16(off + 10, true);
    const csize = dv.getUint32(off + 20, true);
    const nameLen = dv.getUint16(off + 28, true);
    const extraLen = dv.getUint16(off + 30, true);
    const commentLen = dv.getUint16(off + 32, true);
    const local = dv.getUint32(off + 42, true);
    const name = new TextDecoder().decode(buf.subarray(off + 46, off + 46 + nameLen));
    entries.set(name, { method, csize, local });
    off += 46 + nameLen + extraLen + commentLen;
  }
  const read = async (name) => {
    const e = entries.get(name);
    if (!e) return null;
    const lnl = dv.getUint16(e.local + 26, true);
    const lel = dv.getUint16(e.local + 28, true);
    const start = e.local + 30 + lnl + lel;
    const raw = buf.subarray(start, start + e.csize);
    if (e.method === 0) return new TextDecoder().decode(raw);
    if (e.method !== 8) throw new Error('Unsupported compression in this file.');
    if (typeof DecompressionStream === 'undefined') throw new Error('This browser cannot open Office files. Please use a current Chrome, Edge, Firefox or Safari, or save the file as PDF.');
    const ds = new Blob([raw]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
    return new Response(ds).text();
  };
  return { names: [...entries.keys()], read };
}

const xml = (s) => new DOMParser().parseFromString(s, 'application/xml');
const byTag = (node, ns, tag) => [...node.getElementsByTagNameNS(ns, tag)];
const W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main';
const A = 'http://schemas.openxmlformats.org/drawingml/2006/main';
const PNS = 'http://schemas.openxmlformats.org/presentationml/2006/main';
const S = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main';
const R = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships';

function mdTable(rows) {
  const clean = rows.map((r) => r.map((c) => c.replace(/\s+/g, ' ').trim().replace(/\|/g, '\\|'))).filter((r) => r.some(Boolean));
  if (clean.length < 2) return clean.map((r) => r.join(' ')).join('\n');
  const width = Math.max(...clean.map((r) => r.length));
  const pad = (r) => [...r, ...Array(width - r.length).fill('')];
  return [`| ${pad(clean[0]).join(' | ')} |`, `| ${Array(width).fill('---').join(' | ')} |`, ...clean.slice(1).map((r) => `| ${pad(r).join(' | ')} |`)].join('\n');
}

async function readDocx(file) {
  const z = await unzip(file);
  const docXml = await z.read('word/document.xml');
  if (!docXml) throw new Error('This Word file has no document body.');
  const d = xml(docXml);
  const body = byTag(d, W, 'body')[0];
  const parts = [];
  for (const node of body ? [...body.children] : []) {
    if (node.localName === 'p') {
      const text = byTag(node, W, 't').map((t) => t.textContent).join('').trim();
      if (!text) continue;
      const style = byTag(node, W, 'pStyle')[0]?.getAttributeNS(W, 'val') || '';
      const bold = byTag(node, W, 'r').every((r) => !byTag(r, W, 't').length || byTag(r, W, 'b').length);
      const words = text.split(/\s+/).length;
      const heading = /^(heading|title|berschrift)/i.test(style) || (words <= 7 && text.endsWith(':')) || (words <= 9 && bold && !text.endsWith('.'));
      parts.push({ text, heading });
    } else if (node.localName === 'tbl') {
      const rows = byTag(node, W, 'tr').map((tr) => byTag(tr, W, 'tc').map((tc) => byTag(tc, W, 't').map((t) => t.textContent).join(' ')));
      parts.push({ text: mdTable(rows), heading: false });
    }
  }
  return { unit: 'section', pages: sections(parts) };
}

function sections(parts) {
  const secs = [];
  for (const p of parts) {
    if (p.heading || !secs.length) secs.push({ title: p.heading ? p.text.replace(/:$/, '') : null, lines: [p.text] });
    else secs[secs.length - 1].lines.push(p.text);
  }
  const merged = [];
  for (const s of secs) {
    const words = s.lines.join(' ').split(/\s+/).length;
    const last = merged[merged.length - 1];
    if (last && (words < 25 || last.lines.join(' ').split(/\s+/).length < 25)) last.lines.push(...s.lines);
    else merged.push(s);
  }
  // split very long sections so that a page stays readable
  const pages = [];
  for (const s of merged) {
    let buf = [];
    let count = 0;
    for (const l of s.lines) {
      const w = l.split(/\s+/).length;
      if (count + w > 700 && buf.length) { pages.push({ title: s.title, text: buf.join('\n\n') }); buf = []; count = 0; }
      buf.push(l);
      count += w;
    }
    if (buf.length) pages.push({ title: s.title, text: buf.join('\n\n') });
  }
  return pages.map((p, i) => ({ n: i + 1, title: p.title, text: p.text }));
}

async function readPptx(file, onProgress) {
  const z = await unzip(file);
  const pres = xml(await z.read('ppt/presentation.xml') || '<x/>');
  const rels = xml(await z.read('ppt/_rels/presentation.xml.rels') || '<x/>');
  const target = new Map([...rels.getElementsByTagName('Relationship')].map((r) => [r.getAttribute('Id'), r.getAttribute('Target')]));
  let order = byTag(pres, PNS, 'sldId').map((s) => target.get(s.getAttributeNS(R, 'id'))).filter(Boolean).map((t) => 'ppt/' + t.replace(/^\/?ppt\//, '').replace(/^\.\.\//, ''));
  if (!order.length) order = z.names.filter((n) => /^ppt\/slides\/slide\d+\.xml$/.test(n)).sort((a, b) => Number(a.match(/\d+/g).pop()) - Number(b.match(/\d+/g).pop()));
  const pages = [];
  for (let i = 0; i < order.length && i < MAX_PAGES; i++) {
    const s = await z.read(order[i]);
    if (!s) continue;
    const d = xml(s);
    let title = null;
    const lines = [];
    for (const sp of byTag(d, PNS, 'sp')) {
      const ph = byTag(sp, PNS, 'ph')[0];
      const isTitle = ph && /title/i.test(ph.getAttribute('type') || '');
      const paras = byTag(sp, A, 'p').map((p) => byTag(p, A, 't').map((t) => t.textContent).join('').trim()).filter(Boolean);
      if (!paras.length) continue;
      if (isTitle && !title) title = paras.join(' ');
      else lines.push(...paras.map((p) => (paras.length > 1 ? `• ${p}` : p)), '');
    }
    for (const tbl of byTag(d, A, 'tbl')) {
      const rows = byTag(tbl, A, 'tr').map((tr) => byTag(tr, A, 'tc').map((tc) => byTag(tc, A, 't').map((t) => t.textContent).join(' ')));
      lines.push(mdTable(rows), '');
    }
    const text = ((title ? title + '\n\n' : '') + lines.join('\n')).replace(/\n{3,}/g, '\n\n').trim();
    pages.push({ n: pages.length + 1, title, text });
    onProgress(i + 1, order.length);
  }
  return { unit: 'slide', pages };
}

async function readXlsx(file) {
  const z = await unzip(file);
  const wb = xml(await z.read('xl/workbook.xml') || '<x/>');
  const rels = xml(await z.read('xl/_rels/workbook.xml.rels') || '<x/>');
  const target = new Map([...rels.getElementsByTagName('Relationship')].map((r) => [r.getAttribute('Id'), r.getAttribute('Target')]));
  const ssXml = await z.read('xl/sharedStrings.xml');
  const shared = ssXml ? byTag(xml(ssXml), S, 'si').map((si) => byTag(si, S, 't').map((t) => t.textContent).join('')) : [];
  const sheets = byTag(wb, S, 'sheet').map((s) => ({ name: s.getAttribute('name'), path: 'xl/' + (target.get(s.getAttributeNS(R, 'id')) || '').replace(/^\/?xl\//, '') }));
  const pages = [];
  for (const sh of sheets.slice(0, 60)) {
    const s = await z.read(sh.path);
    if (!s) continue;
    const d = xml(s);
    const lines = [];
    let rowsSeen = 0;
    for (const row of byTag(d, S, 'row')) {
      if (++rowsSeen > 250) { lines.push('… (more rows not shown)'); break; }
      const cells = [];
      for (const c of byTag(row, S, 'c').slice(0, 24)) {
        const ref = c.getAttribute('r') || '';
        const t = c.getAttribute('t');
        const f = byTag(c, S, 'f')[0]?.textContent;
        let v = byTag(c, S, 'v')[0]?.textContent ?? byTag(c, S, 't').map((x) => x.textContent).join('');
        if (t === 's') v = shared[Number(v)] ?? '';
        if (v === '' && !f) continue;
        const num = Number(v);
        const shown = t !== 's' && t !== 'str' && t !== 'inlineStr' && v !== '' && Number.isFinite(num) ? String(Math.round(num * 10000) / 10000) : String(v).replace(/\s+/g, ' ').slice(0, 120);
        cells.push(f ? `${ref} =${f.slice(0, 120)} → ${shown}` : shown);
      }
      if (cells.length) lines.push(`R${row.getAttribute('r')}: ${cells.join(' | ')}`);
    }
    pages.push({ n: pages.length + 1, title: sh.name, text: `Sheet: ${sh.name}\n\n${lines.join('\n') || '(empty sheet)'}` });
  }
  return { unit: 'sheet', pages };
}

// ------------------------------------------------------------------ text and Markdown

async function readText(file) {
  const text = (await file.text()).replace(/\r\n?/g, '\n');
  const parts = [];
  for (const block of text.split(/\n{2,}/)) {
    const t = block.trim();
    if (!t) continue;
    const h = t.match(/^#{1,3}\s+(.+)$/m);
    parts.push({ text: t, heading: !!h && t.split('\n').length === 1 });
  }
  const pages = sections(parts.map((p) => ({ ...p, text: p.heading ? p.text.replace(/^#{1,3}\s+/, '') : p.text })));
  return { unit: 'section', pages };
}
