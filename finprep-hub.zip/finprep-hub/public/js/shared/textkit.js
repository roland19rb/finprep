// FinPrep Hub — text toolkit shared by the build script, the server and the browser.
//
//  normalizeText()   repairs text pulled out of PDFs (math letters, bullets, ligatures, hyphenation)
//  cleanPages()      removes running headers/footers and page numbers, finds slide titles and
//                    section labels, classifies pages (cover, agenda, divider, content)
//  chunkDocument()   cuts a document into retrieval chunks that follow the slides and sections
//  tokenize()        the search tokenizer (lower case, light stemming, stop words removed)
//
// The same code runs for the course materials (scripts/build-docs.mjs) and for documents that
// students add through the site (lib/intake.js), so both are chunked in exactly the same way.

export const TEXTKIT_VERSION = 3;

// ------------------------------------------------------------------ normalisation

const PUA = /[-]/gu;
const ZERO_WIDTH = /[​-‍⁠﻿­]/g;
const LIGATURES = { 'ﬀ': 'ff', 'ﬁ': 'fi', 'ﬂ': 'fl', 'ﬃ': 'ffi', 'ﬄ': 'ffl', 'ﬅ': 'st', 'ﬆ': 'st' };

function isMathAlnum(ch) {
  const cp = ch.codePointAt(0);
  return cp >= 0x1d400 && cp <= 0x1d7ff;
}

/** Some PDF fonts (Cambria Math exports) write every math letter twice: "𝑓𝑓(𝑥𝑥)" for f(x).
 *  Returns true when a document shows that pattern often enough to repair it safely. */
export function hasDoubledMath(text) {
  let total = 0;
  let doubled = 0;
  const chars = Array.from(text);
  for (let i = 0; i < chars.length; i++) {
    if (!isMathAlnum(chars[i])) continue;
    total++;
    if (chars[i + 1] === chars[i]) { doubled++; i++; total++; }
  }
  return total >= 12 && doubled * 2 / total >= 0.6;
}

function collapseDoubledMath(text) {
  const chars = Array.from(text);
  const out = [];
  for (let i = 0; i < chars.length; i++) {
    const ch = chars[i];
    if (isMathAlnum(ch)) {
      let j = i;
      while (j + 1 < chars.length && chars[j + 1] === ch) j++;
      const run = j - i + 1;
      for (let k = 0; k < Math.ceil(run / 2); k++) out.push(ch);
      i = j;
    } else out.push(ch);
  }
  return out.join('');
}

/** Map 𝑓, 𝒙, 𝔼, 𝜇 … to f, x, E, μ so search and reading work on plain letters. */
function plainMathLetters(text) {
  // 𝑓 → f; also restore the space PDFs drop between a math letter and a word ("𝑦changes")
  const chars = Array.from(text);
  let out = '';
  for (let i = 0; i < chars.length; i++) {
    const ch = chars[i];
    const prev = chars[i - 1];
    if (isMathAlnum(ch)) {
      if (prev && /[A-Za-zÄÖÜäöüß]/.test(prev) && /[a-zäöüß]{2}$/.test(out.slice(-2)) && !isMathAlnum(prev)) out += ' ';
      out += ch.normalize('NFKC');
    } else {
      if (prev && isMathAlnum(prev) && /[a-zäöüß]/.test(ch) && /[a-zäöüß]/.test(chars[i + 1] || '')) out += ' ';
      out += ch;
    }
  }
  return out;
}

// Office "Save as PDF" maps some Cambria Math glyphs to code points of unrelated scripts.
// Seen in the course slides: ∑ ∏ ∫ printed as Sinhala letters, bars/hats/tildes as Malayalam
// and Sinhala signs placed before their letter, a large brace as an Ethiopic letter.
const MISMAPPED = { '෍': '∑', 'ෑ': '∏', 'න': '∫', 'ቐ': '{', 'ȉ': '·' };
const ACCENT_BEFORE = { 'ഥ': '\u0304', 'ത': '\u0304', '෠': '\u0302', '෡': '\u0302', '෤': '\u0303', '෥': '\u0303' };
const FOREIGN = /[\u0D00-\u0DFF\u1200-\u137F]/u;

function fixMathGlyphs(t) {
  if (!/[\u0D00-\u0DFF\u1200-\u137F\u0209\u0305]/u.test(t)) return t;
  const chars = Array.from(t);
  const out = [];
  for (let i = 0; i < chars.length; i++) {
    const ch = chars[i];
    const prev = chars[i - 1] || '';
    const next = chars[i + 1] || '';
    const isolated = !FOREIGN.test(prev) && !FOREIGN.test(next); // real Sinhala/Malayalam text has neighbours
    if (ACCENT_BEFORE[ch] && isolated && /[\p{L}]/u.test(next)) { out.push(next, ACCENT_BEFORE[ch]); i++; continue; }
    if (MISMAPPED[ch] && (isolated || ch === 'ȉ')) { out.push(MISMAPPED[ch]); continue; }
    if (ch === '\u0305' && /\s/.test(next) && /[\p{L}]/u.test(chars[i + 2] || '')) { out.push(chars[i + 2], '\u0305'); i += 2; continue; }
    if ((ch === 'ቊ' || ch === 'ቅ') && isolated) continue;
    out.push(ch);
  }
  return out.join('');
}

export function normalizeText(text, { doubledMath = false } = {}) {
  if (!text) return '';
  let t = String(text).replace(/\r\n?/g, '\n').replace(/ /g, ' ').replace(ZERO_WIDTH, '');
  t = t.replace(/[ﬀﬁﬂﬃﬄﬅﬆ]/g, (m) => LIGATURES[m] || m);
  if (doubledMath) t = collapseDoubledMath(t);
  t = plainMathLetters(t);
  t = fixMathGlyphs(t);
  // private-use glyphs are bullet symbols from Wingdings/Symbol fonts
  t = t.replace(/^[ \t]*[-][ \t]*$/gmu, '•').replace(PUA, '•');
  // "_ text" and "▪ text" style bullets
  t = t.replace(/^[ \t]*(?:_|▪|▫|◦|‣|⁃|●|■|□|➢|➤|►|❖|✓|–)[ \t]+/gm, '• ');
  t = t.replace(/^[ \t]*_(?=\S)/gm, '• ');
  t = t.replace(/^[ \t]*_[ \t]*$/gm, '•');
  t = t.replace(/[ \t]+$/gm, '').replace(/^[ \t]+/gm, (m) => (m.length > 2 ? '' : m));
  return t;
}

// ------------------------------------------------------------------ cleaning

const FIGURE_RE = /^(illustration|figure|fig\.|exhibit|table|chart|abbildung|tabelle|source)\b/i;
const AGENDA_RE = /^(agenda|contents?|table of contents|outline|overview|lecture overview|course overview|inhalt|gliederung|roadmap)\b/i;
const PAGE_NO_RES = [
  /^#?\s?\d{1,3}$/,
  /^\d{1,2}\s?[-–]\s?\d{1,3}$/,
  /^(page|slide|seite|folie)\s*\d+(\s*(of|von|\/)\s*\d+)?$/i,
  /^\d{1,3}\s*\/\s*\d{1,3}$/,
];

function lineKey(line) {
  return line.toLowerCase().replace(/\d+/g, '#').replace(/\s+/g, ' ').trim();
}

function wordCount(text) {
  const m = String(text || '').match(/[\p{L}\p{N}]+/gu);
  return m ? m.length : 0;
}

function isPageNumber(line) {
  const l = line.trim();
  return PAGE_NO_RES.some((re) => re.test(l));
}

/** Merge bullet glyphs with the text that follows, re-join wrapped lines, fix hyphenation. */
function tidyLines(text) {
  const raw = text.split('\n');
  const lines = [];
  for (let i = 0; i < raw.length; i++) {
    const l = raw[i];
    if (/^\s*[•\-–]\s*$/.test(l)) {
      let j = i + 1;
      while (j < raw.length && !raw[j].trim()) j++;
      if (j < raw.length) { lines.push('• ' + raw[j].trim()); i = j; continue; }
      continue;
    }
    lines.push(l);
  }
  // a sentence broken into two blocks: "… the time" / (blank) / "value of money" → one line
  for (let i = 1; i + 1 < lines.length; i++) {
    if (lines[i].trim()) continue;
    const p = (lines[i - 1] || '').trim();
    const n = (lines[i + 1] || '').trim();
    if (p && n && !/[.:;!?)\]|]$/.test(p) && /^[a-zäöüß]/.test(n) && !p.startsWith('|') && !/^\s*\d+(\.\d+)*\.?\s/.test(n)) {
      lines.splice(i, 1);
      i--;
    }
  }
  const out = [];
  for (const l of lines) {
    const prev = out.length ? out[out.length - 1] : null;
    const cur = l.trim();
    if (prev !== null && prev.trim() && cur) {
      const p = prev.trimEnd();
      if (/[A-Za-zÄÖÜäöüß]-$/.test(p) && /^[a-zäöüß]/.test(cur)) {
        out[out.length - 1] = p.slice(0, -1) + cur;
        continue;
      }
      if (!/[.:;!?)\]|]$/.test(p) && /^[a-zäöüß(]/.test(cur) && !p.startsWith('|') && !cur.startsWith('|')) {
        out[out.length - 1] = p + ' ' + cur;
        continue;
      }
    }
    out.push(cur ? l.trimEnd() : '');
  }
  return out.join('\n').replace(/\n{3,}/g, '\n\n').trim();
}

/**
 * Clean the raw pages of one document.
 * @param {Array<{n:number,title?:string,subtitle?:string,text:string}>} pages
 * @param {{unit?:string}} opts  unit: 'slide' | 'page' | 'sheet' | 'section'
 */
export function cleanPages(pages, { unit = 'page' } = {}) {
  const allText = pages.map((p) => `${p.title || ''}\n${p.text || ''}`).join('\n');
  const doubledMath = hasDoubledMath(allText);
  const norm = pages.map((p) => ({
    n: p.n,
    title: p.title ? normalizeText(p.title, { doubledMath }).replace(/\s+/g, ' ').trim() : null,
    subtitle: p.subtitle ? normalizeText(p.subtitle, { doubledMath }).replace(/\s+/g, ' ').trim() : null,
    lines: normalizeText(p.text || '', { doubledMath }).split('\n'),
    transcribed: !!p.transcribed,
    hidden: !!p.hidden,
  }));

  const N = norm.length;
  const report = { doubledMath, removed: [], sectionLabels: [], runningHeader: null, pageNumbers: 0, empty: 0 };

  // Lines that repeat across pages. Extractors may say which lines sit in the top band (section
  // labels, chapter names) or the bottom band (course name, copyright, page numbers) of a page.
  // Body lines must repeat exactly, so headings such as "Exercise 1" / "Exercise 2" are never
  // mistaken for a footer; footer-band lines are compared with their numbers ignored.
  const exactKey = (t) => t.toLowerCase().replace(/\s+/g, ' ').trim();
  const hasMarks = pages.some((p) => p.marks);
  const count = (getLines, keyFn) => {
    const seen = new Map(); // key -> {text, pages[]}
    for (let i = 0; i < pages.length; i++) {
      const keys = new Set();
      for (const raw of getLines(pages[i], norm[i])) {
        const t = normalizeText(String(raw || ''), { doubledMath }).trim();
        if (!t || t.length > 160 || t.startsWith('|')) continue;
        const k = keyFn(t);
        if (keys.has(k)) continue;
        keys.add(k);
        if (!seen.has(k)) seen.set(k, { text: t, pages: [] });
        seen.get(k).pages.push(norm[i].n);
      }
    }
    return seen;
  };
  const boilerExact = new Set();
  const boilerNorm = new Set();
  const labels = new Map(); // normalised key -> label text
  const remember = (text, n) => { if (!report.removed.some((r) => r.text === text)) report.removed.push({ text, pages: n }); };
  if (unit !== 'sheet' && N >= 4) {
    const body = count((raw, n) => n.lines.filter((l) => l.trim() !== n.title), exactKey);
    for (const [k, v] of body) {
      if (v.pages.length >= Math.max(3, Math.ceil(N * (hasMarks ? 0.5 : 0.4))) && v.text.split(/\s+/).length <= 14) {
        boilerExact.add(k);
        remember(v.text, v.pages.length);
      }
    }
    if (hasMarks) {
      const bottom = count((raw) => (raw.marks && raw.marks.bottom) || [], lineKey);
      for (const [k, v] of bottom) {
        if (v.pages.length >= Math.max(2, Math.ceil(N * 0.25))) { boilerNorm.add(k); remember(v.text, v.pages.length); }
      }
      const top = count((raw) => (raw.marks && raw.marks.top) || [], lineKey);
      for (const [k, v] of top) {
        const c = v.pages.length;
        if (c >= Math.ceil(N * 0.85)) { boilerNorm.add(k); remember(v.text, c); continue; }
        if (c < 2 || v.text.split(/\s+/).length > 12 || isPageNumber(v.text)) continue;
        const sorted = v.pages.slice().sort((a, b) => a - b);
        const span = sorted[sorted.length - 1] - sorted[0] + 1;
        if (c / span >= 0.6) {
          labels.set(k, v.text);
          report.sectionLabels.push({ text: v.text, from: sorted[0], to: sorted[sorted.length - 1] });
        }
      }
    }
  }
  const isBoiler = (t) => boilerExact.has(exactKey(t)) || boilerNorm.has(lineKey(t));

  // A slide "title" that repeats on many slides is a running header (chapter name): use it as
  // the section and take the slide's own heading (subtitle) as the title.
  const titleCount = new Map();
  for (const p of norm) if (p.title) titleCount.set(p.title, (titleCount.get(p.title) || 0) + 1);
  let runningHeader = null;
  for (const [t, c] of titleCount) if (N >= 6 && c >= Math.max(4, N * 0.3)) runningHeader = t;
  report.runningHeader = runningHeader;

  let lastLabel = null;
  const out = norm.map((p, i) => {
    let section = null;
    for (const t of pages[i].marks?.top || []) {
      const k = lineKey(normalizeText(String(t), { doubledMath }).trim());
      if (labels.has(k)) { section = labels.get(k); break; }
    }
    const kept = [];
    for (const l of p.lines) {
      const t = l.trim();
      if (!t) { kept.push(''); continue; }
      if (isPageNumber(t)) { report.pageNumbers++; continue; }
      const k = lineKey(t);
      if (labels.has(k)) { section = section || labels.get(k); continue; }
      if (isBoiler(t)) continue;
      kept.push(l);
    }
    let title = p.title;
    // the extractor puts the title on the first line of the text; it is shown separately
    while (kept.length && !kept[0].trim()) kept.shift();
    if (title && kept.length && kept[0].trim() === title) kept.shift();
    if (runningHeader && title === runningHeader) {
      section = section || runningHeader;
      title = p.subtitle && p.subtitle !== runningHeader ? p.subtitle : null;
      if (title) {
        const idx = kept.findIndex((l) => l.trim() === title);
        if (idx >= 0) kept.splice(idx, 1);
      } else {
        // slide's own heading is usually the first short line under the running header
        while (kept.length && !kept[0].trim()) kept.shift();
        const first = (kept[0] || '').trim();
        if (first && wordCount(first) <= 8 && !/[.=]$/.test(first) && /\p{L}{3}/u.test(first) && !first.startsWith('•') && !first.startsWith('|')) {
          title = first;
          kept.shift();
        }
      }
    }
    let body = tidyLines(kept.join('\n'));
    const words = wordCount(body) + wordCount(title);
    let kind = 'content';
    const head = (title || body.split('\n')[0] || '').trim();
    const numbered = body.split('\n').filter((l) => /^\s*(\d+(\.\d+)*\.?|[A-Z]\.)\s+\S/.test(l)).length;
    const lineCount = body.split('\n').filter((l) => l.trim()).length;
    if (words === 0) kind = 'empty';
    else if (p.n === 1 && words <= 45 && unit !== 'sheet') kind = 'cover';
    else if (AGENDA_RE.test(head) || (lineCount >= 5 && numbered / lineCount >= 0.6)) kind = 'agenda';
    else if (unit === 'slide' && title && wordCount(body) <= 4 && words <= 16 && !FIGURE_RE.test(title)) kind = 'divider';
    if (kind === 'empty') report.empty++;
    if (section) lastLabel = section;
    else if (unit === 'slide' && kind === 'content' && labels.size) section = lastLabel;
    // a divider names the chunk it opens; it is not carried further, because short slides
    // (a chart with a title) look like dividers too
    if (kind === 'divider' && !section) section = title || body.replace(/\s+/g, ' ').trim();
    const label = unit === 'slide' ? `Slide ${p.n}` : unit === 'sheet' ? `Sheet “${title || p.n}”` : unit === 'section' ? `Section ${p.n}` : `Page ${p.n}`;
    const page = { n: p.n, label, title: title || null, section: section || null, kind, words, text: body };
    if (p.transcribed) page.transcribed = true;
    if (p.hidden) page.hidden = true;
    return page;
  });
  return { pages: out, report };
}

// ------------------------------------------------------------------ chunking

export const CHUNK_RULES = {
  slide: { target: 230, max: 420, min: 70 },
  prose: { target: 300, max: 380, overlap: 40 },
  sheet: { max: 450, part: 360 },
};

function splitSentences(text) {
  const parts = text.replace(/\s+/g, ' ').match(/[^.!?]+(?:[.!?]+(?=\s|$)|$)/g) || [text];
  return parts.map((s) => s.trim()).filter(Boolean);
}

function splitLong(text, maxWords) {
  // split a long block at paragraph, then line, then sentence boundaries
  const out = [];
  let cur = [];
  let curWords = 0;
  const push = () => { if (cur.length) out.push(cur.join('\n')); cur = []; curWords = 0; };
  const units = [];
  for (const para of text.split(/\n{2,}/)) {
    if (wordCount(para) <= maxWords) units.push(para);
    else for (const line of para.split('\n')) {
      if (wordCount(line) <= maxWords) units.push(line);
      else units.push(...splitSentences(line));
    }
  }
  for (const u of units) {
    const w = wordCount(u);
    if (curWords && curWords + w > maxWords) push();
    cur.push(u);
    curWords += w;
  }
  push();
  return out;
}

function chunkTitle(pages) {
  const titles = [];
  for (const p of pages) if (p.title && !titles.includes(p.title)) titles.push(p.title);
  if (!titles.length) return null;
  return titles.length === 1 ? titles[0] : `${titles[0]} · ${titles[1]}${titles.length > 2 ? ' …' : ''}`;
}

function pageBlock(p, unit) {
  const head = unit === 'sheet' ? '' : `[${p.label}]${p.title ? ' ' + p.title : ''}\n`;
  return (head + p.text).trim();
}

function isProse(pages, unit) {
  if (unit === 'section') return true;
  if (unit === 'sheet') return false;
  const content = pages.filter((p) => p.kind !== 'empty');
  if (!content.length) return false;
  const avg = content.reduce((s, p) => s + p.words, 0) / content.length;
  return unit === 'page' ? avg >= 120 : avg >= 280;
}

/**
 * Cut a cleaned document into chunks.
 * @returns {Array<{n:number,pages:[number,number],section:string|null,title:string|null,kind:string,text:string,words:number,overlap?:number}>}
 */
export function chunkDocument(pages, { unit = 'page' } = {}) {
  const chunks = [];
  const add = (c) => chunks.push({ n: chunks.length + 1, ...c });

  if (unit === 'sheet') {
    for (const p of pages) {
      if (p.kind === 'empty') continue;
      if (p.words <= CHUNK_RULES.sheet.max) {
        add({ pages: [p.n, p.n], section: p.title, title: p.title, kind: 'content', text: p.text, words: p.words });
      } else {
        const parts = splitLong(p.text, CHUNK_RULES.sheet.part);
        parts.forEach((t, i) => {
          const text = i === 0 ? t : `Sheet: ${p.title} (continued)\n${t}`;
          add({ pages: [p.n, p.n], section: p.title, title: p.title, kind: 'content', text, words: wordCount(text) });
        });
      }
    }
    return chunks;
  }

  if (isProse(pages, unit)) {
    const R = CHUNK_RULES.prose;
    // paragraphs with their page; join paragraphs that run across a page break
    const paras = [];
    for (const p of pages) {
      if (p.kind === 'empty') continue;
      const blocks = p.text.split(/\n{2,}/).map((b) => b.trim()).filter(Boolean);
      if (p.title && unit !== 'section') blocks.unshift(p.title);
      if (unit === 'section' && p.title && !blocks[0]?.startsWith(p.title)) blocks.unshift(p.title);
      blocks.forEach((b, i) => {
        const last = paras[paras.length - 1];
        if (i === 0 && last && last.page !== p.n && !/[.:;!?)"”]$/.test(last.text) && /^[a-zäöüß]/.test(b)) {
          last.text += ' ' + b;
          last.toPage = p.n;
        } else paras.push({ text: b, page: p.n, toPage: p.n, section: p.section || (unit === 'section' ? p.title : null), ptitle: p.title || null });
      });
    }
    let cur = null;
    const flush = () => {
      if (!cur || !cur.parts.length) return;
      const text = cur.parts.join('\n\n');
      add({ pages: [cur.from, cur.to], section: cur.section, title: cur.title, kind: 'content', text, words: wordCount(text), ...(cur.overlap ? { overlap: cur.overlap } : {}) });
      const sentences = splitSentences(cur.parts[cur.parts.length - 1]);
      let tail = [];
      let tw = 0;
      for (let i = sentences.length - 1; i >= 0 && tw < R.overlap; i--) { tail.unshift(sentences[i]); tw += wordCount(sentences[i]); }
      cur = { tail: tw <= R.overlap * 2 ? tail.join(' ') : '', tailWords: tw <= R.overlap * 2 ? tw : 0, lastTo: cur.to, section: cur.section };
    };
    const start = (para) => {
      const prev = cur;
      cur = { parts: [], words: 0, from: para.page, to: para.toPage, section: para.section, title: para.section || para.ptitle || null, overlap: 0 };
      if (prev && prev.tail) { cur.parts.push(prev.tail); cur.words = prev.tailWords; cur.overlap = prev.tailWords; cur.from = Math.min(para.page, prev.lastTo); }
    };
    for (const para of paras) {
      const pieces = wordCount(para.text) > R.max ? splitLong(para.text, R.target) : [para.text];
      for (const piece of pieces) {
        const w = wordCount(piece);
        if (!cur || !cur.parts) start(para);
        const sectionChange = para.section && cur.section && para.section !== cur.section && cur.words - cur.overlap >= 60;
        if (cur.words > cur.overlap && (cur.words + w > R.max || cur.words >= R.target || sectionChange)) { flush(); start(para); }
        cur.parts.push(piece);
        cur.words += w;
        cur.to = Math.max(cur.to, para.toPage);
        if (!cur.section && para.section) cur.section = para.section;
      }
    }
    if (cur && cur.parts && cur.words > cur.overlap) flush();
    return chunks;
  }

  // slide decks
  const R = CHUNK_RULES.slide;
  let cur = null;
  const flush = () => {
    if (!cur || !cur.pages.length) { cur = null; return; }
    const text = cur.pages.map((p) => pageBlock(p, unit)).join('\n\n');
    add({ pages: [cur.pages[0].n, cur.pages[cur.pages.length - 1].n], section: cur.section, title: chunkTitle(cur.pages), kind: cur.kind, text, words: wordCount(text) });
    cur = null;
  };
  for (const p of pages) {
    if (p.kind === 'empty') continue;
    if (p.kind === 'cover' || p.kind === 'agenda') {
      flush();
      cur = { pages: [p], words: p.words, section: p.section, kind: 'overview' };
      flush();
      continue;
    }
    if (p.kind === 'divider') {
      flush();
      cur = { pages: [p], words: p.words, section: p.section || p.title, kind: 'content' };
      continue;
    }
    if (p.words > R.max) {
      flush();
      const parts = splitLong(p.text, R.target);
      parts.forEach((t, i) => {
        const head = `[${p.label}]${p.title ? ' ' + p.title : ''}${i ? ' (continued)' : ''}\n`;
        add({ pages: [p.n, p.n], section: p.section, title: p.title, kind: 'content', text: head + t, words: wordCount(t) });
      });
      continue;
    }
    if (cur) {
      const changed = p.section && cur.section && p.section !== cur.section;
      if ((changed && cur.words >= R.min) || cur.words + p.words > R.max || cur.words >= R.target) flush();
    }
    if (!cur) cur = { pages: [], words: 0, section: p.section, kind: 'content' };
    cur.pages.push(p);
    cur.words += p.words;
    if (!cur.section && p.section) cur.section = p.section;
  }
  flush();
  return chunks;
}

// ------------------------------------------------------------------ search tokenizer

export const STOPWORDS = new Set(`a about above after again against all also am an and any are aren as at be because been before
being below between both but by can cannot could did do does doing down during each else etc even ever every few for
from further get gets got had has have having he her here hers herself him himself his how however i if in into is
isn it its itself just let lets like may me might more most much must my myself no nor not now of off on once only or
other ought our ours ourselves out over own per please same shall she should so some such than that the their theirs
them themselves then there these they this those through thus to too under until up upon us use used using very via
was we were what when where whether which while who whom whose why will with within without would yes yet you your
yours yourself yourselves one two also e g i e eg ie vs
der die das den dem des ein eine einer eines einem einen und oder aber nicht ist sind war waren wird werden wurde
mit von zu zum zur im in an auf aus bei für fur über uber unter nach vor als wie auch noch nur sich es er sie wir ihr
dass daß bzw usw`.split(/\s+/).filter(Boolean));

export function stem(w) {
  if (w.length <= 3 || /\d/.test(w)) return w;
  if (w.endsWith("'s")) w = w.slice(0, -2);
  if (w.endsWith('ies') && w.length > 4) return w.slice(0, -3) + 'y';
  if (w.endsWith('sses')) return w.slice(0, -2);
  if (/(ches|shes|xes|zes)$/.test(w)) return w.slice(0, -2);
  if (w.endsWith('s') && !/(ss|us|is|ys)$/.test(w) && w.length > 3) w = w.slice(0, -1);
  if (w.endsWith('ing') && w.length > 6) return w.slice(0, -3);
  if (w.endsWith('ed') && w.length > 5 && !w.endsWith('eed')) return w.slice(0, -2);
  if (w.endsWith('ly') && w.length > 5) return w.slice(0, -2);
  return w;
}

const TOKEN_RE = /[\p{L}\p{N}]+(?:[.,][\p{N}]+)*/gu;

// "t-table", "z score", "F-test": keep the one-letter prefix as part of a compound token
const COMPOUND_RE = /\b([tzf])[-\s]?(table|test|tests|value|values|distribution|score|scores|statistic|statistics|stat)\b/gi;

export function tokenize(text, { keepStopwords = false } = {}) {
  const out = [];
  const src = String(text || '').replace(COMPOUND_RE, (m, a, b) => `${a}${b.replace(/s$/, '')} ${b}`);
  const m = src.toLowerCase().normalize('NFKC').match(TOKEN_RE);
  if (!m) return out;
  for (let t of m) {
    if (t.length > 40) continue;
    if (!keepStopwords && STOPWORDS.has(t)) continue;
    if (/^\d/.test(t)) { if (t.length > 12) continue; out.push(t.replace(/,/g, '')); continue; }
    if (t.length < 2) continue;
    out.push(stem(t));
  }
  return out;
}

/** Top keywords of a text given document frequencies (for display in the chunk view). */
export function keywords(text, df, totalDocs, k = 6) {
  const tf = new Map();
  const words = String(text || '').toLowerCase().normalize('NFKC').match(/[\p{L}][\p{L}\p{N}'’-]{2,}/gu) || [];
  const surface = new Map();
  for (const w of words) {
    if (STOPWORDS.has(w) || w.length < 3) continue;
    const s = stem(w);
    tf.set(s, (tf.get(s) || 0) + 1);
    if (!surface.has(s)) surface.set(s, w);
  }
  const scored = [];
  for (const [s, c] of tf) {
    const d = df.get(s) || 1;
    scored.push([s, c * Math.log(1 + totalDocs / d)]);
  }
  scored.sort((a, b) => b[1] - a[1]);
  return scored.slice(0, k).map(([s]) => surface.get(s));
}

export function countWords(text) {
  return wordCount(text);
}
