// Talking to the server: JSON requests and streamed (server-sent event) answers.

import { state } from './state.js';

export class ApiError extends Error {
  constructor(status, message, body) {
    super(message);
    this.status = status;
    this.body = body;
  }
}

function headers(extra = {}) {
  const h = { 'x-client-id': state.clientId, ...extra };
  if (state.code) h['x-access-code'] = state.code;
  return h;
}

export async function getJson(path) {
  let res;
  try {
    res = await fetch(path, { headers: headers() });
  } catch {
    throw new ApiError(0, 'The hub could not be reached. Check your connection.');
  }
  let body = null;
  try { body = await res.json(); } catch { /* not JSON */ }
  if (!res.ok) throw new ApiError(res.status, body?.error || `Request failed (${res.status})`, body);
  return body;
}

export async function postJson(path, data) {
  const res = await fetch(path, { method: 'POST', headers: headers({ 'content-type': 'application/json' }), body: JSON.stringify(data) });
  let body = null;
  try { body = await res.json(); } catch { /* empty */ }
  if (!res.ok) throw new ApiError(res.status, body?.error || `Request failed (${res.status})`, body);
  return body;
}

/**
 * POST and read a server-sent event stream. onEvent(name, data) is called per event.
 * Returns a controller with abort().
 */
export function stream(path, data, onEvent) {
  const ctrl = new AbortController();
  const done = (async () => {
    let res;
    try {
      res = await fetch(path, {
        method: 'POST',
        headers: headers({ 'content-type': 'application/json', accept: 'text/event-stream' }),
        body: JSON.stringify(data),
        signal: ctrl.signal,
      });
    } catch (e) {
      if (ctrl.signal.aborted) return;
      onEvent('error', { message: 'The hub could not be reached. Check your connection and try again.' });
      return;
    }
    if (!res.ok || !res.body) {
      let body = null;
      try { body = await res.json(); } catch { /* not JSON */ }
      onEvent('error', { message: body?.error || `The request failed (${res.status}).`, status: res.status, needsCode: body?.needsCode });
      return;
    }
    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buf = '';
    let gotDone = false;
    try {
      while (true) {
        const { value, done: end } = await reader.read();
        if (end) break;
        buf += decoder.decode(value, { stream: true });
        let i;
        while ((i = buf.indexOf('\n\n')) >= 0) {
          const chunk = buf.slice(0, i);
          buf = buf.slice(i + 2);
          let event = 'message';
          let payload = '';
          for (const line of chunk.split('\n')) {
            if (line.startsWith('event:')) event = line.slice(6).trim();
            else if (line.startsWith('data:')) payload += line.slice(5).trim();
          }
          if (!payload) continue;
          let parsed;
          try { parsed = JSON.parse(payload); } catch { continue; }
          if (event === 'done' || event === 'result' || event === 'error') gotDone = true;
          onEvent(event, parsed);
        }
      }
    } catch (e) {
      if (ctrl.signal.aborted) return;
      onEvent('error', { message: 'The connection was interrupted. Please try again.' });
      return;
    }
    if (!gotDone && !ctrl.signal.aborted) onEvent('end', {});
  })();
  return { abort: () => ctrl.abort(), done };
}
