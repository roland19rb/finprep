// Visual answers: a diagram (boxes in lanes with arrows) or a chart (line / bar), both with Play.
// Claude writes them as small text blocks (```diagram / ```chart); this file draws them as SVG.

import { esc, icon } from './ui.js';

const NS = 'http://www.w3.org/2000/svg';
const COLORS = ['#1f5bd0', '#0b6e80', '#b07a00', '#b3362d'];
let measureCtx = null;

function measure(text, font) {
  if (!measureCtx) measureCtx = document.createElement('canvas').getContext('2d');
  measureCtx.font = font;
  return measureCtx.measureText(text).width;
}

function wrap(text, font, width, maxLines = 4) {
  const words = String(text || '').split(/\s+/).filter(Boolean);
  const lines = [];
  let cur = '';
  for (const w of words) {
    const t = cur ? `${cur} ${w}` : w;
    if (measure(t, font) <= width || !cur) cur = t;
    else { lines.push(cur); cur = w; }
  }
  if (cur) lines.push(cur);
  if (lines.length > maxLines) {
    const kept = lines.slice(0, maxLines);
    kept[maxLines - 1] = kept[maxLines - 1].replace(/\s*\S*$/, '') + '…';
    return kept;
  }
  return lines;
}

const norm = (id) => String(id || '').trim().toLowerCase().replace(/[^a-z0-9_.-]/g, '');
const clean = (s) => String(s || '').trim().replace(/^["'“”]+|["'“”]+$/g, '');

// ------------------------------------------------------------------ diagram

export function parseDiagram(src) {
  const g = { title: '', lanes: [], nodes: new Map(), edges: [], focus: new Set() };
  const ensure = (id) => {
    if (!g.nodes.has(id)) g.nodes.set(id, { id, label: id, detail: '', cites: [] });
    return g.nodes.get(id);
  };
  for (const raw of String(src).split('\n')) {
    const line = raw.trim();
    if (!line || line.startsWith('//') || line.startsWith('%%')) continue;
    let m;
    if ((m = line.match(/^title\s*:\s*(.+)$/i))) { g.title = clean(m[1]); continue; }
    if ((m = line.match(/^focus\s*:\s*(.+)$/i))) { m[1].split(/[,\s]+/).map(norm).filter(Boolean).forEach((id) => g.focus.add(id)); continue; }
    if ((m = line.match(/^lane\s+(.+?)\s*:\s*(.*)$/i))) {
      g.lanes.push({ name: clean(m[1]), ids: m[2].split(/[,\s]+/).map(norm).filter(Boolean) });
      continue;
    }
    if ((m = line.match(/^([\w.-]+)\s*(?:-{1,2}>|→|=>)\s*([\w.-]+)\s*(?::\s*(.*))?$/))) {
      g.edges.push({ from: norm(m[1]), to: norm(m[2]), label: clean(m[3]) });
      continue;
    }
    if ((m = line.match(/^([\w.-]+)\s*[=:]\s*(.+)$/))) {
      const id = norm(m[1]);
      const [label, ...rest] = m[2].split('|');
      let detail = clean(rest.join('|'));
      const cites = [...detail.matchAll(/\[(\d+)\]/g)].map((x) => Number(x[1]));
      detail = detail.replace(/\s*\[\d+\]/g, '').trim();
      const n = ensure(id);
      n.label = clean(label) || id;
      n.detail = detail;
      n.cites = cites;
    }
  }
  for (const e of g.edges) { ensure(e.from); ensure(e.to); }
  for (const l of g.lanes) l.ids.forEach(ensure);
  if (g.nodes.size === 0) throw new Error('The diagram has no boxes.');
  if (g.nodes.size > 24) throw new Error('The diagram has too many boxes to draw clearly.');
  return g;
}

function columnsOf(g) {
  // columns: the lanes in order; boxes outside lanes are placed after their predecessors
  const col = new Map();
  const order = new Map();
  g.lanes.forEach((l, i) => l.ids.forEach((id, k) => { if (!col.has(id)) { col.set(id, i); order.set(id, k); } }));
  const preds = new Map([...g.nodes.keys()].map((id) => [id, []]));
  for (const e of g.edges) if (preds.has(e.to)) preds.get(e.to).push(e.from);
  const depth = new Map();
  const visit = (id, stack = new Set()) => {
    if (col.has(id)) return col.get(id);
    if (depth.has(id)) return depth.get(id);
    if (stack.has(id)) return 0;
    stack.add(id);
    const ps = preds.get(id) || [];
    const d = ps.length ? Math.max(...ps.map((p) => visit(p, stack))) + 1 : 0;
    depth.set(id, d);
    return d;
  };
  for (const id of g.nodes.keys()) if (!col.has(id)) col.set(id, visit(id));
  const ncols = Math.max(...col.values()) + 1;
  const columns = Array.from({ length: ncols }, () => []);
  const listed = [...g.nodes.keys()];
  for (const id of listed) columns[col.get(id)].push(id);
  columns.forEach((c) => c.sort((a, b) => (order.has(a) ? order.get(a) : 100 + listed.indexOf(a)) - (order.has(b) ? order.get(b) : 100 + listed.indexOf(b))));
  const used = columns.filter((c) => c.length);
  const names = used.map((ids) => g.lanes.find((l) => l.ids.includes(ids[0]))?.name || '');
  return { used, names };
}

const FONT_L = '600 15.5px "IBM Plex Sans", sans-serif';
const FONT_D = '400 13.5px "IBM Plex Sans", sans-serif';

function measureBox(g, id, W) {
  const n = g.nodes.get(id);
  const label = wrap(n.label, FONT_L, W - 28, 3);
  const detail = n.detail ? wrap(n.detail, FONT_D, W - 28, 4) : [];
  const h = 14 + label.length * 20 + (detail.length ? 6 + detail.length * 18 : 0) + (n.cites.length ? 18 : 0) + 12;
  return { label, detail, h, node: n };
}

/** Lanes side by side (wide screens). */
function layoutDiagram(g) {
  const { used, names } = columnsOf(g);
  const W = used.length >= 5 ? 196 : used.length === 4 ? 210 : 228;
  const GAPX = 86;
  const GAPY = 30;
  const laneTitle = g.lanes.length ? 34 : 0;
  const M = 18;
  const boxes = new Map();
  let maxH = 0;
  used.forEach((ids, ci) => {
    let y = 0;
    ids.forEach((id) => {
      const b = measureBox(g, id, W);
      boxes.set(id, { id, ci, x: M + ci * (W + GAPX), y, w: W, ...b });
      y += b.h + GAPY;
    });
    maxH = Math.max(maxH, y - GAPY);
  });
  used.forEach((ids) => {
    const colH = ids.reduce((sum, id) => sum + boxes.get(id).h, 0) + GAPY * (ids.length - 1);
    const off = (maxH - colH) / 2;
    ids.forEach((id) => { boxes.get(id).y += off + M + laneTitle; });
  });
  const width = M * 2 + used.length * W + (used.length - 1) * GAPX;
  const height = maxH + M * 2 + laneTitle + 6;
  const lanes = laneTitle ? used.map((ids, ci) => ({ name: names[ci], x: M + ci * (W + GAPX) - 8, y: 6, w: W + 16, h: height - 10, tx: M + ci * (W + GAPX) + 4, ty: 28 })) : [];
  return { boxes, width, height, lanes, sequence: used.flat(), vertical: false };
}

/** Lanes stacked from top to bottom (phones and narrow panes). */
function layoutVertical(g, avail) {
  const { used, names } = columnsOf(g);
  const M = 12;
  const W = Math.max(220, Math.min(380, avail - M - 46));
  const laneTitle = g.lanes.length ? 26 : 0;
  const boxes = new Map();
  const lanes = [];
  let y = M;
  used.forEach((ids, li) => {
    const top = y;
    if (laneTitle) y += laneTitle;
    ids.forEach((id, k) => {
      const b = measureBox(g, id, W);
      boxes.set(id, { id, ci: li, x: M + 8, y, w: W, ...b });
      y += b.h + (k < ids.length - 1 ? 30 : 0);
    });
    y += 12;
    if (laneTitle) lanes.push({ name: names[li], x: M, y: top, w: W + 16, h: y - top, tx: M + 12, ty: top + 18 });
    y += 30;
  });
  return { boxes, width: M + W + 16 + 46, height: y - 18, lanes, sequence: used.flat(), vertical: true };
}

function edgePathV(a, b, seq) {
  const ia = seq.indexOf(a.id), ib = seq.indexOf(b.id);
  if (ib === ia + 1 && b.y > a.y) {
    const x = a.x + a.w / 2;
    return { d: `M${x},${a.y + a.h} L${x},${b.y - 2}`, mx: x + 10, my: (a.y + a.h + b.y) / 2 + 4, anchor: 'start' };
  }
  const side = b.y > a.y ? 1 : -1;
  const x = side > 0 ? a.x + a.w : a.x;
  const xb = side > 0 ? b.x + b.w + 2 : b.x - 2;
  const bend = side * (34 + Math.min(8, Math.abs(ib - ia)) * 2);
  const y1 = a.y + a.h / 2, y2 = b.y + b.h / 2;
  return { d: `M${x},${y1} C${x + bend},${y1} ${xb + bend},${y2} ${xb},${y2}`, mx: x + bend * 0.75, my: (y1 + y2) / 2, anchor: side > 0 ? 'end' : 'start', side: true };
}

function edgePath(a, b) {
  if (a.ci === b.ci) {
    if (b.y > a.y) {
      const x = a.x + a.w / 2;
      return { d: `M${x},${a.y + a.h} L${x},${b.y - 2}`, mx: x, my: (a.y + a.h + b.y) / 2 };
    }
    const x = a.x + a.w;
    const d = `M${x},${a.y + a.h / 2} C${x + 40},${a.y + a.h / 2} ${x + 40},${b.y + b.h / 2} ${x + 2},${b.y + b.h / 2}`;
    return { d, mx: x + 30, my: (a.y + b.y + b.h) / 2 };
  }
  if (b.ci > a.ci) {
    const x1 = a.x + a.w, y1 = a.y + a.h / 2, x2 = b.x - 2, y2 = b.y + b.h / 2;
    const dx = (x2 - x1) / 2;
    return { d: `M${x1},${y1} C${x1 + dx},${y1} ${x2 - dx},${y2} ${x2},${y2}`, mx: (x1 + x2) / 2, my: (y1 + y2) / 2 };
  }
  const x1 = a.x, y1 = a.y + a.h / 2, x2 = b.x + b.w + 2, y2 = b.y + b.h / 2;
  const low = Math.max(a.y + a.h, b.y + b.h) + 40;
  return { d: `M${x1},${y1} C${x1 - 50},${low} ${x2 + 50},${low} ${x2},${y2}`, mx: (x1 + x2) / 2, my: low - 12 };
}

function diagramSvg(g, L) {
  const parts = [];
  parts.push(`<defs><marker id="dg-arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7.5" markerHeight="7.5" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="#9aa6b8"/></marker><marker id="dg-arrow-on" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7.5" markerHeight="7.5" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="#1f5bd0"/></marker></defs>`);
  for (const l of L.lanes) {
    parts.push(`<rect class="dg-lane" x="${l.x}" y="${l.y}" width="${l.w}" height="${l.h}" rx="12"/>`);
    if (l.name) parts.push(`<text class="dg-lane-t" x="${l.tx}" y="${l.ty}">${esc(l.name)}</text>`);
  }
  g.edges.forEach((e, i) => {
    const a = L.boxes.get(e.from), b = L.boxes.get(e.to);
    if (!a || !b || a === b) return;
    const p = L.vertical ? edgePathV(a, b, L.sequence) : edgePath(a, b);
    parts.push(`<path class="dg-edge" data-e="${i}" data-from="${esc(e.from)}" data-to="${esc(e.to)}" d="${p.d}" marker-end="url(#dg-arrow)"/>`);
    if (e.label) {
      const text = e.label.length > 26 ? e.label.slice(0, 25) + '…' : e.label;
      const w = Math.min(160, measure(text, '500 12.5px "IBM Plex Sans", sans-serif') + 12);
      if (L.vertical && p.anchor === 'start' && !p.side) {
        parts.push(`<g class="dg-edge-lbl" data-e="${i}"><rect class="dg-edge-bg" x="${p.mx - 4}" y="${p.my - 14}" width="${w}" height="20" rx="6"/><text class="dg-edge-l" x="${p.mx + 2}" y="${p.my}">${esc(text)}</text></g>`);
      } else {
        parts.push(`<g class="dg-edge-lbl" data-e="${i}"><rect class="dg-edge-bg" x="${p.mx - w / 2}" y="${p.my - 11}" width="${w}" height="20" rx="6"/><text class="dg-edge-l" x="${p.mx}" y="${p.my + 3.5}" text-anchor="middle">${esc(text)}</text></g>`);
      }
    }
  });
  for (const b of L.boxes.values()) {
    const focus = g.focus.has(b.id) ? ' focus' : '';
    let y = b.y + 14 + 15;
    let t = '';
    b.label.forEach((ln) => { t += `<text class="lbl" x="${b.x + 14}" y="${y}">${esc(ln)}</text>`; y += 20; });
    if (b.detail.length) {
      y += 4;
      b.detail.forEach((ln) => { t += `<text class="det" x="${b.x + 14}" y="${y}">${esc(ln)}</text>`; y += 18; });
    }
    if (b.node.cites.length) t += `<text class="cit" x="${b.x + 14}" y="${y + 2}">Source ${b.node.cites.map((c) => `[${c}]`).join(' ')}</text>`;
    parts.push(`<g class="dg-box${focus}" data-id="${esc(b.id)}" tabindex="0" role="button" aria-label="${esc(b.node.label)}"><rect class="box" x="${b.x}" y="${b.y}" width="${b.w}" height="${b.h}" rx="11"/>${t}</g>`);
  }
  return `<svg xmlns="${NS}" width="${L.width}" height="${L.height}" viewBox="0 0 ${L.width} ${L.height}" role="img" aria-label="${esc(g.title || 'Diagram')}">${parts.join('')}</svg>`;
}

// ------------------------------------------------------------------ chart

export function parseChart(src) {
  let spec;
  try {
    spec = JSON.parse(String(src).trim().replace(/,\s*([}\]])/g, '$1'));
  } catch {
    throw new Error('The chart data is not valid JSON.');
  }
  const type = spec.type === 'bar' ? 'bar' : 'line';
  const xs = Array.isArray(spec.x?.values) ? spec.x.values.slice(0, 40) : Array.isArray(spec.x) ? spec.x.slice(0, 40) : null;
  const series = (Array.isArray(spec.series) ? spec.series : []).slice(0, 4).map((s, i) => ({
    name: String(s.name || `Series ${i + 1}`),
    values: (Array.isArray(s.values) ? s.values : []).slice(0, xs ? xs.length : 40).map((v) => (v === null || v === '' ? null : Number(v))),
    color: COLORS[i % COLORS.length],
  })).filter((s) => s.values.some((v) => Number.isFinite(v)));
  if (!series.length) throw new Error('The chart has no numbers to draw.');
  const n = Math.max(...series.map((s) => s.values.length));
  const x = xs || Array.from({ length: n }, (_, i) => i + 1);
  return {
    type,
    title: String(spec.title || ''),
    xLabel: String(spec.x?.label || ''),
    yLabel: String(spec.y?.label || ''),
    x,
    numericX: type === 'line' && x.every((v) => Number.isFinite(Number(v)) && v !== ''),
    series,
    mark: spec.mark && Number.isFinite(Number(spec.mark.x)) ? { x: Number(spec.mark.x), label: String(spec.mark.label || '') } : null,
  };
}

function niceStep(range, count) {
  const raw = range / Math.max(1, count);
  const mag = 10 ** Math.floor(Math.log10(raw || 1));
  const f = raw / mag;
  return (f <= 1 ? 1 : f <= 2 ? 2 : f <= 2.5 ? 2.5 : f <= 5 ? 5 : 10) * mag;
}

export function fmt(v) {
  if (!Number.isFinite(v)) return '–';
  const a = Math.abs(v);
  const d = a >= 1000 ? 0 : a >= 100 ? 1 : a >= 1 ? 2 : 3;
  return v.toLocaleString('en', { maximumFractionDigits: d });
}

function chartSvg(c, width) {
  const H = width < 520 ? 290 : 340;
  const legendRows = c.series.length > 1 ? 1 : 0;
  const m = { l: 62, r: 22, t: 18 + legendRows * 24, b: 58 };
  const iw = width - m.l - m.r, ih = H - m.t - m.b;
  const all = c.series.flatMap((s) => s.values).filter(Number.isFinite);
  let lo = Math.min(...all), hi = Math.max(...all);
  if (c.type === 'bar' || lo > 0 && lo < (hi - lo) * 0.6) lo = Math.min(0, lo);
  if (hi < 0) hi = 0;
  if (lo === hi) { lo -= 1; hi += 1; }
  const step = niceStep(hi - lo, 5);
  lo = Math.floor(lo / step) * step;
  hi = Math.ceil(hi / step) * step;
  const Y = (v) => m.t + ih - ((v - lo) / (hi - lo)) * ih;
  let X;
  let xTicks = [];
  const n = c.x.length;
  if (c.numericX) {
    const xv = c.x.map(Number);
    let x0 = Math.min(...xv), x1 = Math.max(...xv);
    if (x0 === x1) { x0 -= 1; x1 += 1; }
    X = (v) => m.l + ((v - x0) / (x1 - x0)) * iw;
    const xs = niceStep(x1 - x0, Math.min(8, Math.max(2, Math.floor(iw / 70))));
    for (let v = Math.ceil(x0 / xs) * xs; v <= x1 + 1e-9; v += xs) xTicks.push({ v, x: X(v), t: fmt(Math.round(v * 1e6) / 1e6) });
  } else {
    const band = iw / n;
    X = (i) => m.l + band * i + band / 2;
    const every = Math.ceil(n / Math.max(1, Math.floor(iw / 64)));
    xTicks = c.x.map((v, i) => ({ v: i, x: X(i), t: String(v) })).filter((_, i) => i % every === 0);
  }
  const p = [];
  for (let v = lo; v <= hi + 1e-9; v += step) {
    const y = Y(v);
    p.push(`<line class="${Math.abs(v) < step / 1e6 ? 'ch-zero' : 'ch-grid'}" x1="${m.l}" x2="${m.l + iw}" y1="${y}" y2="${y}"/>`);
    p.push(`<text class="ch-axis-t" x="${m.l - 8}" y="${y + 4}" text-anchor="end">${fmt(Math.round(v * 1e6) / 1e6)}</text>`);
  }
  xTicks.forEach((t) => p.push(`<text class="ch-axis-t" x="${t.x}" y="${m.t + ih + 20}" text-anchor="middle">${esc(t.t.length > 12 ? t.t.slice(0, 11) + '…' : t.t)}</text>`));
  if (c.xLabel) p.push(`<text class="ch-axis-l" x="${m.l + iw / 2}" y="${H - 10}" text-anchor="middle">${esc(c.xLabel)}</text>`);
  if (c.yLabel) p.push(`<text class="ch-axis-l" transform="translate(16 ${m.t + ih / 2}) rotate(-90)" text-anchor="middle">${esc(c.yLabel)}</text>`);
  if (c.mark && c.numericX) {
    const x = X(c.mark.x);
    if (x >= m.l - 1 && x <= m.l + iw + 1) {
      p.push(`<line class="ch-mark" x1="${x}" x2="${x}" y1="${m.t}" y2="${m.t + ih}"/>`);
      if (c.mark.label) p.push(`<text class="ch-mark-t" x="${Math.min(x + 6, m.l + iw - 4)}" y="${m.t + 14}" text-anchor="${x > m.l + iw - 120 ? 'end' : 'start'}">${esc(c.mark.label)}</text>`);
    }
  }
  const base = Y(Math.max(lo, Math.min(0, hi)));
  c.series.forEach((s, si) => {
    if (c.type === 'bar') {
      const band = iw / n;
      const bw = Math.max(4, (band * 0.72) / c.series.length);
      s.values.forEach((v, i) => {
        if (!Number.isFinite(v)) return;
        const x = m.l + band * i + band * 0.14 + si * bw;
        const y = Math.min(Y(v), base);
        p.push(`<rect class="ch-bar" data-s="${si}" x="${x}" y="${y}" width="${bw - 2}" height="${Math.max(1, Math.abs(Y(v) - base))}" rx="3" fill="${s.color}"/>`);
      });
    } else {
      const pts = s.values.map((v, i) => (Number.isFinite(v) ? [c.numericX ? X(Number(c.x[i])) : X(i), Y(v)] : null)).filter(Boolean);
      if (!pts.length) return;
      p.push(`<path class="ch-line" data-s="${si}" stroke="${s.color}" d="M${pts.map((q) => q.join(',')).join(' L')}"/>`);
      pts.forEach((q) => p.push(`<circle class="ch-pt" data-s="${si}" cx="${q[0]}" cy="${q[1]}" r="3.6" fill="#fff" stroke="${s.color}" stroke-width="2"/>`));
    }
  });
  if (legendRows) {
    let lx = m.l;
    c.series.forEach((s) => {
      p.push(`<rect x="${lx}" y="8" width="14" height="5" rx="2.5" fill="${s.color}"/><text class="ch-legend" x="${lx + 20}" y="15">${esc(s.name)}</text>`);
      lx += 34 + measure(s.name, '500 13px "IBM Plex Sans", sans-serif');
    });
  }
  p.push(`<line class="ch-hover" x1="0" x2="0" y1="${m.t}" y2="${m.t + ih}" visibility="hidden"/><rect class="ch-catch" x="${m.l}" y="${m.t}" width="${iw}" height="${ih}" fill="transparent"/>`);
  return { svg: `<svg xmlns="${NS}" width="${width}" height="${H}" viewBox="0 0 ${width} ${H}" role="img" aria-label="${esc(c.title || 'Chart')}">${p.join('')}</svg>`, X, m, iw };
}

// ------------------------------------------------------------------ mounting

/**
 * Build the visual element for a ```diagram or ```chart block.
 * onCite(n) is called when a citation in the caption is clicked.
 */
export function createVisual(kind, src, { onCite } = {}) {
  const wrapEl = document.createElement('div');
  wrapEl.className = 'viz';
  let parsed;
  try {
    parsed = kind === 'chart' ? parseChart(src) : parseDiagram(src);
  } catch (e) {
    wrapEl.innerHTML = `<div class="viz-error">${icon('info', 16)} The visual could not be drawn: ${esc(e.message)}<details><summary>Show the description</summary><pre>${esc(src)}</pre></details></div>`;
    return wrapEl;
  }
  const title = parsed.title || (kind === 'chart' ? 'Chart' : 'Diagram');
  wrapEl.innerHTML = `<div class="viz-bar"><div class="viz-title">${esc(title)}</div>
    <button class="viz-btn" data-v="prev" aria-label="Previous step">${icon('prev', 16)}</button>
    <button class="viz-btn" data-v="play">${icon('play', 15)}<span class="t">Play</span></button>
    <button class="viz-btn" data-v="next" aria-label="Next step">${icon('next', 16)}</button>
    <button class="viz-btn" data-v="fit" aria-label="Fit to width">${icon('fit', 16)}<span class="t">Fit</span></button></div>
    <div class="viz-canvas"></div><div class="viz-caption" aria-live="polite"></div>`;
  const canvas = wrapEl.querySelector('.viz-canvas');
  const caption = wrapEl.querySelector('.viz-caption');
  const btn = (v) => wrapEl.querySelector(`[data-v="${v}"]`);
  let timer = null;
  let step = -1;
  let fitted = null;
  let api;

  const citeChips = (cites) => cites.map((n) => `<button class="cite" data-cite="${n}">${n}</button>`).join('');
  caption.addEventListener('click', (e) => {
    const b = e.target.closest('[data-cite]');
    if (b) onCite?.(Number(b.dataset.cite));
  });

  if (kind === 'diagram') {
    let L = null;
    let svg = null;
    const seq = () => L.sequence;
    const build = () => {
      const avail = (canvas.clientWidth || wrapEl.clientWidth || 800) - 12;
      const wide = layoutDiagram(parsed);
      const fitsWide = avail >= wide.width * 0.72;
      if (fitsWide || avail >= 620) {
        // side by side; shrink to the width only while the text stays legible, else scroll sideways
        L = wide;
        if (fitted === null || L.vertical === false) fitted = fitted === null ? fitsWide : fitted;
        btn('fit').hidden = fitsWide && avail >= wide.width;
      } else {
        L = layoutVertical(parsed, avail);
        fitted = true;
        btn('fit').hidden = true;
      }
      canvas.innerHTML = diagramSvg(parsed, L);
      svg = canvas.querySelector('svg');
      if (api) { api.svg = svg; api.width = L.width; }
      applyFit(fitted);
      if (step >= 0) show(step); else reset();
    };
    const show = (i) => {
      step = i;
      svg.classList.add('playing');
      const cur = seq()[i];
      const seen = new Set(seq().slice(0, i));
      svg.querySelectorAll('.dg-box').forEach((gEl) => {
        gEl.classList.toggle('cur', gEl.dataset.id === cur);
        gEl.classList.toggle('seen', seen.has(gEl.dataset.id));
      });
      svg.querySelectorAll('.dg-edge').forEach((p) => {
        const f = p.dataset.from, t = p.dataset.to;
        const isCur = t === cur && (seen.has(f) || f === cur);
        p.classList.toggle('cur', isCur);
        p.classList.toggle('seen', seen.has(f) && seen.has(t));
        p.setAttribute('marker-end', isCur ? 'url(#dg-arrow-on)' : 'url(#dg-arrow)');
      });
      const n = parsed.nodes.get(cur);
      caption.innerHTML = `<span class="step-n">${i + 1} / ${seq().length}</span><span><b>${esc(n.label)}</b>${n.detail ? ' — ' + esc(n.detail) : ''} ${citeChips(n.cites)}</span>`;
      const box = L.boxes.get(cur);
      if (box && canvas.scrollWidth > canvas.clientWidth && !fitted) {
        canvas.scrollTo({ left: Math.max(0, box.x - canvas.clientWidth / 2 + box.w / 2), behavior: 'smooth' });
      }
    };
    const reset = () => {
      step = -1;
      svg.classList.remove('playing');
      svg.querySelectorAll('.cur,.seen').forEach((x) => x.classList.remove('cur', 'seen'));
      svg.querySelectorAll('.dg-edge').forEach((p) => p.setAttribute('marker-end', 'url(#dg-arrow)'));
      caption.innerHTML = `<span class="muted">${seq().length} steps. Press Play to walk through them, or click a box.</span>`;
    };
    canvas.addEventListener('click', (e) => {
      const gEl = e.target.closest('.dg-box');
      if (!gEl) return;
      stop();
      show(seq().indexOf(gEl.dataset.id));
    });
    canvas.addEventListener('keydown', (e) => {
      const gEl = e.target.closest('.dg-box');
      if (gEl && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); stop(); show(seq().indexOf(gEl.dataset.id)); }
    });
    const applyFit = (on) => {
      fitted = on;
      if (!svg) return;
      if (on) { svg.style.width = '100%'; svg.style.height = 'auto'; svg.style.maxWidth = `${L.width}px`; }
      else { svg.style.width = `${L.width}px`; svg.style.height = ''; svg.style.maxWidth = ''; }
      btn('fit').classList.toggle('on', on);
    };
    api = { show, reset, get count() { return seq().length; }, svg: null, width: 0, applyFit };
    btn('fit').addEventListener('click', () => applyFit(!fitted));
    // first layout once the element is on the page and has a width
    let lastW = 0;
    const ro = new ResizeObserver(() => {
      const w = canvas.clientWidth;
      if (!w || Math.abs(w - lastW) < 40) return;
      lastW = w;
      build();
    });
    ro.observe(canvas);
    canvas.innerHTML = '<div style="height:120px"></div>';
  } else {
    const draw = () => {
      const w = Math.max(320, Math.min(900, (canvas.clientWidth || wrapEl.clientWidth || 640) - 12));
      const out = chartSvg(parsed, w);
      canvas.innerHTML = out.svg;
      const svg = canvas.querySelector('svg');
      const tip = document.createElement('div');
      tip.className = 'ch-tip';
      tip.hidden = true;
      canvas.appendChild(tip);
      const hover = svg.querySelector('.ch-hover');
      const xsPx = parsed.x.map((v, i) => (parsed.numericX ? out.X(Number(v)) : out.X(i)));
      svg.querySelector('.ch-catch').addEventListener('pointermove', (e) => {
        const r = svg.getBoundingClientRect();
        const px = ((e.clientX - r.left) / r.width) * w;
        let best = 0;
        xsPx.forEach((x, i) => { if (Math.abs(x - px) < Math.abs(xsPx[best] - px)) best = i; });
        hover.setAttribute('x1', xsPx[best]); hover.setAttribute('x2', xsPx[best]); hover.setAttribute('visibility', 'visible');
        tip.hidden = false;
        tip.innerHTML = `<b>${esc(parsed.xLabel || 'x')}: ${esc(parsed.x[best])}</b><br>${parsed.series.map((s) => `<span style="color:${s.color}">●</span> ${esc(s.name)}: ${fmt(s.values[best])}`).join('<br>')}`;
        const left = Math.min((xsPx[best] / w) * r.width + 14, canvas.clientWidth - tip.offsetWidth - 6);
        tip.style.left = `${Math.max(4, left) + canvas.scrollLeft}px`;
        tip.style.top = '18px';
      });
      svg.querySelector('.ch-catch').addEventListener('pointerleave', () => { hover.setAttribute('visibility', 'hidden'); tip.hidden = true; });
      return svg;
    };
    let svg = draw();
    const steps = parsed.series.length;
    const describe = () => {
      const s = parsed.series;
      return `<span class="muted">${esc(parsed.yLabel || 'Value')} against ${esc(parsed.xLabel || 'x')}${s.length > 1 ? ` for ${s.length} series` : ''}. Press Play to draw it step by step; hover for values.</span>`;
    };
    const show = (i) => {
      step = i;
      const s = parsed.series[i];
      svg.querySelectorAll('[data-s]').forEach((node) => {
        const si = Number(node.dataset.s);
        node.style.opacity = si < i ? '0.55' : si === i ? '1' : '0';
      });
      svg.querySelectorAll(`.ch-line[data-s="${i}"]`).forEach((path) => {
        const len = path.getTotalLength();
        path.style.transition = 'none';
        path.style.strokeDasharray = `${len}`;
        path.style.strokeDashoffset = `${len}`;
        path.getBoundingClientRect();
        path.style.transition = 'stroke-dashoffset 1.4s ease';
        path.style.strokeDashoffset = '0';
      });
      const valid = s.values.map((v, k) => [v, k]).filter(([v]) => Number.isFinite(v));
      const maxv = valid.reduce((a, b) => (b[0] > a[0] ? b : a), valid[0]);
      const minv = valid.reduce((a, b) => (b[0] < a[0] ? b : a), valid[0]);
      caption.innerHTML = `<span class="step-n">${i + 1} / ${steps}</span><span><b>${esc(s.name)}</b> — from ${fmt(s.values[0])} at ${esc(parsed.x[0])} to ${fmt(s.values[s.values.length - 1])} at ${esc(parsed.x[parsed.x.length - 1])}; highest ${fmt(maxv[0])} at ${esc(parsed.x[maxv[1]])}, lowest ${fmt(minv[0])} at ${esc(parsed.x[minv[1]])}.</span>`;
    };
    const reset = () => {
      step = -1;
      svg.querySelectorAll('[data-s]').forEach((node) => { node.style.opacity = ''; });
      svg.querySelectorAll('.ch-line').forEach((p) => { p.style.transition = 'none'; p.style.strokeDasharray = ''; p.style.strokeDashoffset = ''; });
      caption.innerHTML = describe();
    };
    let lastW = 0;
    const ro = new ResizeObserver(() => {
      const w = canvas.clientWidth;
      if (Math.abs(w - lastW) > 30) { lastW = w; svg = draw(); if (step >= 0) show(step); }
    });
    ro.observe(canvas);
    btn('fit').hidden = true;
    api = { show, reset, count: steps, svg };
    reset();
  }

  function stop() {
    clearInterval(timer);
    timer = null;
    btn('play').innerHTML = `${icon('play', 15)}<span class="t">Play</span>`;
    btn('play').classList.remove('on');
  }
  function play() {
    if (timer) { stop(); return; }
    btn('play').innerHTML = `${icon('pause', 15)}<span class="t">Pause</span>`;
    btn('play').classList.add('on');
    const next = () => {
      if (step + 1 >= api.count) { stop(); return; }
      api.show(step + 1);
    };
    if (step + 1 >= api.count) api.reset();
    next();
    timer = setInterval(next, kind === 'chart' ? 2400 : 2300);
  }
  btn('play').addEventListener('click', play);
  btn('next').addEventListener('click', () => { stop(); api.show(Math.min(api.count - 1, step + 1)); });
  btn('prev').addEventListener('click', () => { stop(); if (step <= 0) api.reset(); else api.show(step - 1); });
  return wrapEl;
}
