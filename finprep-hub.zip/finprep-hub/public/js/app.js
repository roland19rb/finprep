// FinPrep Hub — start-up, top bar, routes (#/ask, #/docs, #/doc/<id>, #/add) and the access code.

import { state, save } from './state.js';
import { getJson, ApiError } from './api.js';
import { html, ic, esc } from './ui.js';
import { renderAsk } from './ask.js';
import { renderDocs, renderDoc } from './docs.js';
import { renderAdd } from './add.js';
import { showHow } from './how.js';

const root = document.getElementById('app');
let main = null;
let current = null;

const BRAND = `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 19h16"/><path d="m5 15 4-4 3 3 6-7"/><circle cx="18" cy="7" r="1.6" fill="currentColor"/></svg>`;

const ctx = {
  go(hash) {
    if (location.hash === hash) route();
    else location.hash = hash;
  },
  needCode() {
    showGate('Please enter the class access code again.');
  },
  async refreshCatalog() {
    try {
      await loadCatalog();
    } catch { /* keep the old list */ }
  },
};

async function loadCatalog() {
  state.catalog = await getJson('/api/catalog');
  // a document this browser published is live once it shows up in the catalogue
  const live = new Set(state.catalog.docs.map((d) => d.id));
  const before = state.privateDocs.length;
  state.privateDocs = state.privateDocs.filter((d) => !(d.pendingPublish && live.has(d.id)));
  if (state.privateDocs.length !== before) save.privateDocs();
}

function shell() {
  const cfg = state.config;
  root.innerHTML = html`
    <header class="top">
      <a class="brand" href="#/ask" aria-label="${cfg.name} — start"><span class="brand-mark">${{ __raw: true, html: BRAND }}</span>
        <span><span class="brand-name">${cfg.name}</span><br><span class="brand-sub">${cfg.course} course · knowledge hub</span></span></a>
      <nav class="nav" aria-label="Main">
        <a href="#/ask" data-nav="ask">${ic('ask', 17)}Ask</a>
        <a href="#/docs" data-nav="docs">${ic('docs', 17)}Documents</a>
        <a href="#/add" data-nav="add">${ic('add', 17)}<span>Add<span class="t-long"> knowledge</span></span></a>
      </nav>
      <div class="top-right"><button class="top-btn" data-a="how">${ic('help', 18)}<span class="t">How it works</span></button></div>
    </header>
    ${!cfg.ready ? html`<div class="banner">${ic('info', 18)}<span>Answers are switched off: this hub has no Anthropic API key yet. The site owner adds it as <b>ANTHROPIC_API_KEY</b> (see DEPLOY.md). Documents can still be browsed.</span></div>` : ''}
    <main id="main" tabindex="-1"></main>`.html;
  main = root.querySelector('#main');
  root.querySelector('[data-a="how"]').addEventListener('click', showHow);
}

async function route() {
  if (!main || !state.catalog) return;
  const hash = location.hash || '#/ask';
  const [path, qs] = hash.slice(1).split('?');
  const params = new URLSearchParams(qs || '');
  try { current?.leave?.(); } catch { /* ignore */ }
  const section = path.startsWith('/doc') ? 'docs' : path.replace('/', '') || 'ask';
  root.querySelectorAll('[data-nav]').forEach((a) => {
    const on = a.dataset.nav === section;
    a.classList.toggle('on', on);
    if (on) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current');
  });
  window.scrollTo(0, 0);
  if (path.startsWith('/doc/')) {
    current = await renderDoc(main, ctx, decodeURIComponent(path.slice(5)), params);
    document.title = `${document.querySelector('.dv-head h1')?.textContent || 'Document'} · ${state.config.name}`;
  } else if (path === '/docs') {
    current = renderDocs(main, ctx, params);
    document.title = `Documents · ${state.config.name}`;
  } else if (path === '/add') {
    current = renderAdd(main, ctx);
    document.title = `Add knowledge · ${state.config.name}`;
  } else {
    current = renderAsk(main, ctx);
    document.title = state.config.name;
  }
}

function showGate(message = '') {
  const cfg = state.config || { name: 'FinPrep Hub' };
  root.innerHTML = html`<header class="top"><span class="brand"><span class="brand-mark">${{ __raw: true, html: BRAND }}</span><span class="brand-name">${cfg.name}</span></span></header>
    <div class="gate"><form class="card">
      <span class="mod-ico" style="margin:0 auto;width:46px;height:46px">${ic('lock', 22)}</span>
      <h1>Class access code</h1>
      <p>This hub is for the students of the ${cfg.course || 'Finance Prep'} course. Enter the access code you got in class.</p>
      <input type="password" autocomplete="current-password" placeholder="Access code" aria-label="Access code" required>
      <div class="err" role="alert">${message}</div>
      <button class="btn primary" style="width:100%" type="submit">Open the hub</button>
    </form></div>`.html;
  main = null;
  const form = root.querySelector('form');
  const input = form.querySelector('input');
  input.focus();
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    save.code(input.value.trim());
    form.querySelector('button').disabled = true;
    try {
      await loadCatalog();
      shell();
      route();
    } catch (err) {
      form.querySelector('.err').textContent = err.status === 401 ? 'That code is not right.' : err.message;
      form.querySelector('button').disabled = false;
    }
  });
}

async function boot() {
  root.innerHTML = '<div class="loading"><span class="a-status"><span class="spin"></span></span>Opening the hub…</div>';
  // registered once, before the access code screen, so navigation works after the code is entered
  window.addEventListener('hashchange', route);
  try {
    state.config = await getJson('/api/config');
  } catch (e) {
    root.innerHTML = `<div class="gate"><div class="card"><h1>The hub is not reachable</h1><p>${esc(e.message)}</p></div></div>`;
    return;
  }
  if (state.config.needsCode && !state.code) { showGate(); return; }
  try {
    await loadCatalog();
  } catch (e) {
    if (e instanceof ApiError && e.status === 401) { showGate(state.code ? 'That code is not right any more.' : ''); return; }
    root.innerHTML = `<div class="gate"><div class="card"><h1>The documents could not be loaded</h1><p>${esc(e.message)}</p></div></div>`;
    return;
  }
  shell();
  window.addEventListener('focus', () => {
    // pick up documents that went live while the tab was in the background
    if (state.privateDocs.some((d) => d.pendingPublish)) ctx.refreshCatalog();
  });
  route();
}

boot();
