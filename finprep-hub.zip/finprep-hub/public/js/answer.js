// One question and its answer: streams the answer in, shows what the agent did, the sources,
// visuals, and the buttons to rate it, have it checked again, or get it in another style.

import { renderMarkdown, answerPlainText } from './markdown.js';
import { createVisual } from './visual.js';
import { stream, postJson } from './api.js';
import { esc, html, raw, ic, icon, el, copyText, toast } from './ui.js';
import { state } from './state.js';

export const MODES = {
  short: { label: 'Short', icon: 'short', hint: 'A few lines and the key formula' },
  explained: { label: 'Explained', icon: 'explained', hint: 'Step by step, with an example from the course' },
  visual: { label: 'Visual', icon: 'visual', hint: 'A diagram or chart you can play through' },
};

let fontsReady = false;
(document.fonts?.ready || Promise.resolve()).then(() => { fontsReady = true; });

export function modeSwitch(current, name = 'mode') {
  return html`<div class="seg" role="radiogroup" aria-label="Answer as" data-seg="${name}">${Object.entries(MODES).map(([k, m]) => html`<button type="button" role="radio" aria-checked="${k === current}" class="${k === current ? 'on' : ''}" data-mode="${k}" title="${m.hint}">${ic(m.icon, 16)}${m.label}</button>`)}</div>`;
}

export function bindModeSwitch(root, onChange) {
  root.addEventListener('click', (e) => {
    const b = e.target.closest('[data-mode]');
    if (!b || !root.contains(b)) return;
    root.querySelectorAll('[data-mode]').forEach((x) => { x.classList.toggle('on', x === b); x.setAttribute('aria-checked', String(x === b)); });
    onChange(b.dataset.mode);
  });
}

export function newTurn(fields) {
  return {
    id: Math.random().toString(36).slice(2, 10),
    status: 'run',
    text: '',
    steps: [],
    sources: [],
    at: new Date().toISOString(),
    ...fields,
  };
}

function stepText(s) {
  const q = (t) => `<q>${esc(t)}</q>`;
  switch (s.kind) {
    case 'search':
      if (s.scope === 'document') return `Searched this document for ${q(s.query)}${s.count != null ? ` — ${s.count} passages` : ''}`;
      return s.auto ? `Searched the course for ${q(s.query)}${s.module ? ` in ${esc(moduleName(s.module))}` : ''}` : `Searched again for ${q(s.query)} — ${s.count} new passage${s.count === 1 ? '' : 's'}`;
    case 'found': return `Found ${s.count} passage${s.count === 1 ? '' : 's'} in ${s.documents} document${s.documents === 1 ? '' : 's'}`;
    case 'read': return `Read ${esc(s.label)}${s.title ? ` of “${esc(s.title)}”` : ''}`;
    case 'note': return `<span class="note">“${esc(s.text)}”</span>`;
    default: return '';
  }
}
const STEP_ICON = { search: 'search', found: 'check', read: 'read', note: 'write' };

function moduleName(id) {
  return state.catalog?.modules?.find((m) => m.id === id)?.title || id;
}

function statusText(turn) {
  const last = [...turn.steps].reverse().find((s) => s.kind !== 'found' && s.kind !== 'note');
  if (turn.writing) return 'Writing the answer…';
  if (!last) return 'Starting…';
  if (last.kind === 'read') return `Reading ${last.label}…`;
  if (last.kind === 'search') return turn.docId || turn.privateDoc ? 'Reading the document…' : 'Searching the course…';
  return 'Working…';
}

export class TurnView {
  /**
   * @param {object} turn
   * @param {{onSource?:(src)=>void, onPage?:(n:number)=>void, onReask?:(turn, mode)=>void, onCheckAgain?:(turn, note)=>void, onChange?:()=>void, docMode?:boolean}} opts
   */
  constructor(turn, opts = {}) {
    this.turn = turn;
    this.opts = opts;
    this.vizCache = new Map();
    this.showSteps = false;
    this.showAll = false;
    this.fbOpen = false;
    this.el = document.createElement('div');
    this.el.className = 'turn';
    this.el.dataset.turn = turn.id;
    this.el.addEventListener('click', (e) => this.onClick(e));
    this.renderAll();
  }

  sourceMap() {
    return new Map(this.turn.sources.map((s) => [s.n, s]));
  }

  renderAll() {
    const t = this.turn;
    const m = MODES[t.mode] || MODES.explained;
    this.el.innerHTML = html`
      <div class="q"><div class="q-bubble">${t.question}</div></div>
      ${t.label ? html`<div class="q-meta">${t.label}</div>` : ''}
      <div class="answer">
        <div class="a-head">
          <span class="chip accent">${ic(m.icon, 14)}${m.label}</span>
          ${t.module ? html`<span class="chip">${moduleName(t.module)}</span>` : ''}
          <span class="a-status" aria-live="polite"></span>
          <button class="a-steps-toggle" data-a="steps" aria-expanded="false"></button>
        </div>
        <div class="a-steps" hidden></div>
        <div class="a-body md"></div>
        <div class="a-error" hidden></div>
        <div class="a-cut" hidden>The answer was cut short. Ask for “Short” or a narrower question to get the rest.</div>
        <div class="a-sources" hidden></div>
        <div class="a-actions" hidden></div>
        <div class="fb-box" hidden>
          <input type="text" maxlength="500" placeholder="What is wrong? (optional) — e.g. the formula, a number, the wrong lecture" aria-label="What is wrong">
          <button class="btn primary small" data-a="check">${ic('refresh', 15)}Check again</button>
          <button class="btn ghost small" data-a="fb-cancel">Cancel</button>
        </div>
      </div>`.html;
    this.$ = (s) => this.el.querySelector(s);
    this.$('.fb-box input').addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); this.checkAgain(); } });
    this.update(true);
  }

  update(force = false) {
    const t = this.turn;
    // status
    const st = this.$('.a-status');
    if (t.status === 'run') st.innerHTML = `<span class="spin"></span>${esc(statusText(t))}`;
    else if (t.status === 'done') st.innerHTML = `${icon('check', 15)}<span>${t.meta?.ms ? `Answered in ${(t.meta.ms / 1000).toFixed(1)} s` : 'Answered'}</span>`;
    else if (t.status === 'stopped') st.innerHTML = '<span class="muted">Stopped</span>';
    else st.innerHTML = '';
    // steps
    const steps = t.steps.filter((s) => stepText(s));
    const tog = this.$('.a-steps-toggle');
    const searches = t.steps.filter((s) => s.kind === 'search' || s.kind === 'read').length;
    tog.hidden = !steps.length;
    tog.innerHTML = `${searches ? `${searches} step${searches === 1 ? '' : 's'}` : 'Steps'} ${icon('chevron', 14)}`;
    tog.setAttribute('aria-expanded', String(this.showSteps));
    const sp = this.$('.a-steps');
    sp.hidden = !this.showSteps || !steps.length;
    if (!sp.hidden) sp.innerHTML = `<ol>${steps.map((s) => `<li>${icon(STEP_ICON[s.kind] || 'dot', 14)}<span>${stepText(s)}</span></li>`).join('')}</ol>`;
    this.renderBody(force);
    // error
    const er = this.$('.a-error');
    er.hidden = !t.error;
    if (t.error) er.innerHTML = `${icon('info', 16)} ${esc(t.error)}`;
    this.$('.a-cut').hidden = t.meta?.stop !== 'max_tokens';
    this.renderSources();
    this.renderActions();
  }

  renderBody(force) {
    const now = performance.now();
    if (!force && this.turn.status === 'run' && now - (this.lastBody || 0) < 70) {
      if (!this.pending) {
        this.pending = true;
        setTimeout(() => { this.pending = false; this.renderBody(true); }, 80);
      }
      return;
    }
    this.lastBody = now;
    const t = this.turn;
    const body = this.$('.a-body');
    const streaming = t.status === 'run';
    if (!t.text && streaming) {
      body.innerHTML = `<p class="muted">${esc(statusText(t))}</p>`;
      return;
    }
    const r = renderMarkdown(t.text, { streaming, sources: this.opts.docMode ? null : this.sourceMap() });
    this.cited = r.cited;
    body.innerHTML = r.html;
    if (streaming) {
      const lastP = body.querySelector(':scope > p:last-child, :scope > ul:last-child li:last-child, :scope > ol:last-child li:last-child');
      if (lastP) lastP.classList.add('typing');
    }
    body.querySelectorAll('.viz-slot').forEach((slot) => {
      const v = r.visuals[Number(slot.dataset.viz)];
      if (!v) return;
      const key = `${v.kind}\n${v.src}`;
      let node = this.vizCache.get(key);
      if (!node) {
        if (!fontsReady && streaming) return;
        node = createVisual(v.kind, v.src, { onCite: (n) => this.focusSource(n) });
        this.vizCache.set(key, node);
      }
      slot.replaceWith(node);
    });
  }

  renderSources() {
    const box = this.$('.a-sources');
    if (this.opts.docMode) { box.hidden = true; return; }
    const t = this.turn;
    const cited = this.cited ? [...this.cited] : [];
    const map = this.sourceMap();
    const citedList = cited.map((n) => map.get(n)).filter(Boolean);
    const rest = t.sources.filter((s) => !this.cited?.has(s.n));
    const showList = t.status === 'run' ? [] : citedList.length ? citedList : t.sources.slice(0, 4);
    if (!showList.length && !rest.length) { box.hidden = true; return; }
    box.hidden = t.status === 'run' && !citedList.length;
    const card = (s) => html`<button class="src" data-src="${s.n}">
        <span class="src-n">${s.n}</span>
        <span class="src-main"><span class="src-title">${s.title}</span>
        <span class="src-meta">${[s.label, s.moduleTitle, s.kind, s.origin === 'added' && !/student/i.test(s.kind || '') ? 'added by a student' : ''].filter(Boolean).join(' · ')}</span>
        ${s.heading ? html`<span class="src-snip">${s.heading}</span>` : html`<span class="src-snip">${s.snippet || ''}</span>`}</span></button>`;
    const others = rest.filter((s) => !showList.includes(s));
    box.innerHTML = html`<h4>${citedList.length ? 'Sources used' : 'Passages found'}</h4>
      <div class="src-list">${showList.map(card)}</div>
      ${others.length ? html`<button class="more-src" data-a="more">${this.showAll ? 'Hide' : 'Show'} ${others.length} other passage${others.length === 1 ? '' : 's'} the agent looked at</button>` : ''}
      ${this.showAll && others.length ? html`<div class="src-list" style="margin-top:8px">${others.map(card)}</div>` : ''}`.html;
  }

  renderActions() {
    const t = this.turn;
    const box = this.$('.a-actions');
    box.hidden = t.status === 'run';
    if (box.hidden) return;
    // after an error or a stop, the same style can be tried again
    const lock = (k) => k === t.mode && t.status === 'done';
    const again = Object.entries(MODES).map(([k, m]) => html`<button class="act ${lock(k) ? 'cur' : ''}" data-a="reask" data-mode="${k}" ${lock(k) ? raw('disabled') : ''} title="${m.hint}">${ic(m.icon, 15)}${m.label}</button>`);
    box.innerHTML = html`
      ${t.status === 'done' ? html`<button class="act ${t.rating === 'helpful' ? 'on' : ''}" data-a="helpful" aria-pressed="${t.rating === 'helpful'}">${ic('thumb', 15)}Helpful</button>
      <button class="act warn ${t.rating === 'not_right' ? 'on' : ''}" data-a="notright" aria-expanded="${this.fbOpen}">${ic('flag', 15)}Not right…</button>
      <span class="sep"></span>` : ''}
      <span class="lbl">${t.status === 'done' ? 'Answer again as' : 'Try again as'}</span>${again}
      ${t.status === 'done' ? html`<span class="sep"></span><button class="act" data-a="copy">${ic('copy', 15)}Copy</button>` : ''}`.html;
    this.$('.fb-box').hidden = !this.fbOpen;
  }

  focusSource(n) {
    if (this.opts.docMode) return;
    if (!this.cited?.has(n)) this.showAll = true;
    this.renderSources();
    const card = this.el.querySelector(`.src[data-src="${n}"]`);
    if (card) {
      card.scrollIntoView({ behavior: 'smooth', block: 'center' });
      card.classList.remove('flash');
      void card.offsetWidth;
      card.classList.add('flash');
    }
  }

  onClick(e) {
    const t = this.turn;
    const cite = e.target.closest('.cite');
    if (cite) {
      if (cite.dataset.p) this.opts.onPage?.(Number(cite.dataset.p));
      else if (cite.dataset.n) this.focusSource(Number(cite.dataset.n));
      return;
    }
    const src = e.target.closest('.src[data-src]');
    if (src) { const s = this.sourceMap().get(Number(src.dataset.src)); if (s) this.opts.onSource?.(s); return; }
    const a = e.target.closest('[data-a]');
    if (!a) return;
    const act = a.dataset.a;
    if (act === 'steps') { this.showSteps = !this.showSteps; this.update(true); }
    else if (act === 'more') { this.showAll = !this.showAll; this.renderSources(); }
    else if (act === 'helpful') {
      t.rating = t.rating === 'helpful' ? null : 'helpful';
      this.renderActions();
      this.opts.onChange?.();
      if (t.rating) {
        postJson('/api/feedback', { rating: 'helpful', mode: t.mode, question: t.question, sources: t.sources.map((s) => s.docId) }).catch(() => {});
        toast('Thanks — marked as helpful.');
      }
    } else if (act === 'notright') {
      this.fbOpen = !this.fbOpen;
      this.renderActions();
      if (this.fbOpen) this.$('.fb-box input').focus();
    } else if (act === 'fb-cancel') { this.fbOpen = false; this.renderActions(); }
    else if (act === 'check') this.checkAgain();
    else if (act === 'reask') this.opts.onReask?.(t, a.dataset.mode);
    else if (act === 'copy') {
      const srcs = t.sources.filter((s) => this.cited?.has(s.n)).map((s) => `[${s.n}] ${s.title} — ${s.label}`).join('\n');
      copyText(`${answerPlainText(t.text)}${srcs ? `\n\nSources\n${srcs}` : ''}`).then((ok) => toast(ok ? 'Answer copied.' : 'Copy did not work in this browser.', ok ? 'ok' : 'err'));
    }
  }

  checkAgain() {
    const t = this.turn;
    const note = this.$('.fb-box input').value.trim();
    this.fbOpen = false;
    t.rating = 'not_right';
    this.renderActions();
    this.opts.onChange?.();
    postJson('/api/feedback', { rating: 'not_right', mode: t.mode, question: t.question, note, sources: t.sources.map((s) => s.docId) }).catch(() => {});
    this.opts.onCheckAgain?.(t, note);
  }

  /** Stream the answer from the server. The stream keeps running when the page changes;
   *  a view created later for the same turn picks it up (see attach()). */
  start(payload) {
    const t = this.turn;
    t.status = 'run';
    const run = { views: new Set([this]), req: null };
    RUNNING.set(t.id, run);
    const each = (fn) => run.views.forEach((v) => { if (v.el.isConnected || v === this) fn(v); });
    this.update(true);
    run.req = stream('/api/ask', payload, (event, data) => {
      if (event === 'step') {
        if (data.kind === 'write') t.writing = true;
        else { t.writing = false; t.steps.push(data); }
        each((v) => v.update());
      } else if (event === 'sources') {
        for (const s of data.items || []) if (!t.sources.some((x) => x.n === s.n)) t.sources.push(s);
      } else if (event === 'delta') {
        t.text += data.text;
        each((v) => { v.renderBody(false); v.$('.a-status').innerHTML = '<span class="spin"></span>Writing the answer…'; });
      } else if (event === 'reset') {
        if (data.note) t.steps.push({ kind: 'note', text: data.note });
        t.text = '';
        t.writing = false;
        each((v) => v.update(true));
      } else if (event === 'done') {
        t.status = 'done';
        t.writing = false;
        t.meta = data;
        each((v) => v.update(true));
        this.opts.onChange?.();
      } else if (event === 'error' || event === 'end') {
        t.status = t.text ? 'done' : 'error';
        t.writing = false;
        t.error = event === 'end' ? 'The answer stopped before it was finished (the server took too long). Ask again, or choose Short.' : data.message;
        if (data.needsCode) this.opts.onNeedsCode?.();
        each((v) => v.update(true));
        this.opts.onChange?.();
      }
    });
    return run.req.done.finally(() => RUNNING.delete(t.id));
  }

  /** Re-attach to an answer that is still streaming (after switching pages). */
  attach() {
    const run = RUNNING.get(this.turn.id);
    if (run) { run.views.add(this); return run.req.done; }
    if (this.turn.status === 'run') { this.turn.status = this.turn.text ? 'done' : 'stopped'; this.update(true); }
    return null;
  }

  stop() {
    const run = RUNNING.get(this.turn.id);
    run?.req?.abort();
    RUNNING.delete(this.turn.id);
    if (this.turn.status === 'run') { this.turn.status = this.turn.text ? 'done' : 'stopped'; this.update(true); }
  }
}

const RUNNING = new Map();
export const isRunning = (id) => RUNNING.has(id);

/** The history the server gets for follow-up questions. */
export function historyFrom(turns) {
  return turns.filter((x) => x.status === 'done' && x.text).slice(-3).map((x) => ({ q: x.question, a: x.text.slice(0, 2400) }));
}
