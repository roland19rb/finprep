// DOM helpers, icons, toasts and the modal.

export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

export function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

/** Tagged template that escapes interpolations unless they are marked raw(). */
export function html(strings, ...values) {
  let out = '';
  strings.forEach((s, i) => {
    out += s;
    if (i < values.length) {
      const v = values[i];
      if (v == null || v === false) out += '';
      else if (Array.isArray(v)) out += v.map((x) => (x && x.__raw ? x.html : esc(x))).join('');
      else if (v.__raw) out += v.html;
      else out += esc(v);
    }
  });
  return { __raw: true, html: out };
}
export const raw = (h) => ({ __raw: true, html: String(h ?? '') });

export function el(h) {
  const t = document.createElement('template');
  t.innerHTML = (h && h.__raw ? h.html : String(h)).trim();
  return t.content.firstElementChild;
}

const P = {
  ask: '<path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12Z"/><path d="M9.5 9.5a2.5 2.5 0 1 1 3.4 2.3c-.6.3-.9.8-.9 1.4V14"/><circle cx="12" cy="17" r=".6" fill="currentColor"/>',
  docs: '<path d="M8 3h7l5 5v11a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2Z"/><path d="M14 3v5h5"/><path d="M9.5 13h6M9.5 16.5h6"/>',
  add: '<path d="M12 5v14M5 12h14"/>',
  upload: '<path d="M12 16V4"/><path d="m7 9 5-5 5 5"/><path d="M5 20h14"/>',
  send: '<path d="M5 12h13"/><path d="m13 6 6 6-6 6"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
  read: '<path d="M3 5.5C5.5 4.5 8.5 4.5 12 6.5c3.5-2 6.5-2 9-1V19c-2.5-1-5.5-1-9 1-3.5-2-6.5-2-9-1Z"/><path d="M12 6.5V20"/>',
  write: '<path d="M4 20h4L19 9a2.1 2.1 0 0 0-4-4L4 16Z"/>',
  check: '<path d="m5 12.5 4.5 4.5L19 7.5"/>',
  x: '<path d="M6 6l12 12M18 6 6 18"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6"/><circle cx="12" cy="7.6" r=".7" fill="currentColor"/>',
  help: '<circle cx="12" cy="12" r="9"/><path d="M9.6 9.4a2.5 2.5 0 1 1 3.4 2.3c-.6.3-1 .8-1 1.5v.5"/><circle cx="12" cy="17" r=".7" fill="currentColor"/>',
  up: '<path d="M7 10l5-5 5 5M12 5v14"/>',
  thumb: '<path d="M7 11v9H4v-9Z"/><path d="M7 11l4-7c1.4 0 2.2 1 2 2.4L12.5 10H18a2 2 0 0 1 2 2.3l-1.2 6A2 2 0 0 1 16.8 20H7"/>',
  flag: '<path d="M5 21V4"/><path d="M5 4h11l-2 4 2 4H5"/>',
  copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/>',
  refresh: '<path d="M20 11a8 8 0 0 0-14.6-4.5L4 8"/><path d="M4 4v4h4"/><path d="M4 13a8 8 0 0 0 14.6 4.5L20 16"/><path d="M20 20v-4h-4"/>',
  play: '<path d="M7 5v14l11-7Z" fill="currentColor"/>',
  pause: '<path d="M8 5v14M16 5v14"/>',
  prev: '<path d="m15 6-6 6 6 6"/>',
  next: '<path d="m9 6 6 6-6 6"/>',
  fit: '<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/>',
  expand: '<path d="M14 4h6v6M10 20H4v-6M20 4l-7 7M4 20l7-7"/>',
  back: '<path d="M19 12H5"/><path d="m11 6-6 6 6 6"/>',
  chevron: '<path d="m6 9 6 6 6-6"/>',
  short: '<path d="M5 9h14M5 15h9"/>',
  explained: '<path d="M5 6h14M5 10h14M5 14h14M5 18h9"/>',
  visual: '<rect x="3" y="4" width="7" height="6" rx="1.5"/><rect x="14" y="14" width="7" height="6" rx="1.5"/><path d="M10 7h4a2 2 0 0 1 2 2v5"/>',
  slides: '<rect x="3" y="4" width="18" height="13" rx="2"/><path d="M8 21h8M12 17v4"/>',
  sheet: '<rect x="4" y="3" width="16" height="18" rx="2"/><path d="M4 9h16M4 15h16M10 3v18"/>',
  page: '<path d="M7 3h7l5 5v11a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2Z"/><path d="M14 3v5h5"/>',
  case: '<rect x="3" y="7" width="18" height="13" rx="2"/><path d="M9 7V5a2 2 0 0 1 2-2h2a2 2 0 0 1 2 2v2"/><path d="M3 13h18"/>',
  calc: '<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M8 7h8M8 11h2M12 11h2M16 11h0M8 15h2M12 15h2M8 18h2M12 18h2"/>',
  book: '<path d="M5 4h10a4 4 0 0 1 4 4v12H9a4 4 0 0 1-4-4Z"/><path d="M5 16a4 4 0 0 1 4-4h10"/>',
  chart: '<path d="M4 20V4M4 20h16"/><path d="m7 15 4-5 3 3 5-7"/>',
  sigma: '<path d="M18 6V4H6l6 8-6 8h12v-2"/>',
  coins: '<ellipse cx="9" cy="7" rx="5" ry="2.5"/><path d="M4 7v4c0 1.4 2.2 2.5 5 2.5s5-1.1 5-2.5V7"/><path d="M10 15.4c.6.4 1.8.6 3 .6 2.8 0 5-1.1 5-2.5V9.6"/><path d="M14 18.8c.6.1 1.3.2 2 .2 2.8 0 5-1.1 5-2.5"/>',
  ledger: '<rect x="4" y="3" width="16" height="18" rx="2"/><path d="M12 3v18M7 8h2M7 12h2M15 8h2M15 12h2"/>',
  users: '<circle cx="9" cy="8" r="3.5"/><path d="M3 20a6 6 0 0 1 12 0"/><path d="M16 4.5a3.5 3.5 0 0 1 0 7M18 20a6 6 0 0 0-3-5.2"/>',
  lock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
  spark: '<path d="M12 3v4M12 17v4M3 12h4M17 12h4M5.6 5.6l2.8 2.8M15.6 15.6l2.8 2.8M18.4 5.6l-2.8 2.8M8.4 15.6l-2.8 2.8"/>',
  trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
  external: '<path d="M14 4h6v6M20 4l-9 9"/><path d="M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/>',
  dot: '<circle cx="12" cy="12" r="3" fill="currentColor"/>',
  skip: '<path d="M6 12h12"/>',
  scissors: '<circle cx="6" cy="7" r="2.5"/><circle cx="6" cy="17" r="2.5"/><path d="M8 8.5 20 17M8 15.5 20 7"/>',
  broom: '<path d="M14 4 9 13"/><path d="M6 13h7l2 7H4Z"/>',
  shield: '<path d="M12 3 5 6v6c0 4.4 3 7.6 7 9 4-1.4 7-4.6 7-9V6Z"/><path d="m9 12 2 2 4-4"/>',
};

export function icon(name, size = 18, stroke = 1.8) {
  return `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="${stroke}" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${P[name] || P.dot}</svg>`;
}
export const ic = (name, size, stroke) => raw(icon(name, size, stroke));

export function toast(message, kind = 'ok', ms = 3200) {
  let box = document.querySelector('.toasts');
  if (!box) { box = document.createElement('div'); box.className = 'toasts'; box.setAttribute('aria-live', 'polite'); document.body.appendChild(box); }
  const t = document.createElement('div');
  t.className = `toast ${kind === 'err' ? 'err' : ''}`;
  t.textContent = message;
  box.appendChild(t);
  setTimeout(() => t.remove(), ms);
}

export function modal({ title, body, onClose }) {
  const bg = el(html`<div class="modal-bg" role="dialog" aria-modal="true" aria-label="${title}">
    <div class="modal"><div class="modal-h"><h2>${title}</h2><button class="btn ghost small" data-close aria-label="Close">${ic('x', 18)}</button></div>
    <div class="modal-b"></div></div></div>`);
  const b = bg.querySelector('.modal-b');
  if (typeof body === 'string') b.innerHTML = body; else if (body && body.__raw) b.innerHTML = body.html; else if (body) b.appendChild(body);
  const close = () => { bg.remove(); document.removeEventListener('keydown', onKey); onClose?.(); };
  const onKey = (e) => { if (e.key === 'Escape') close(); };
  bg.addEventListener('click', (e) => { if (e.target === bg || e.target.closest('[data-close]')) close(); });
  document.addEventListener('keydown', onKey);
  document.body.appendChild(bg);
  bg.querySelector('[data-close]').focus();
  return { el: bg, close };
}

export async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    let ok = false;
    try { ok = document.execCommand('copy'); } catch { ok = false; }
    ta.remove();
    return ok;
  }
}

export function fmtNum(n) {
  return Number(n || 0).toLocaleString('en');
}

export function timeAgo(iso) {
  const t = Date.parse(iso);
  if (!t) return '';
  const s = Math.round((Date.now() - t) / 1000);
  if (s < 90) return 'just now';
  const m = Math.round(s / 60);
  if (m < 60) return `${m} min ago`;
  const h = Math.round(m / 60);
  if (h < 36) return `${h} h ago`;
  const d = Math.round(h / 24);
  if (d < 45) return `${d} days ago`;
  return new Date(t).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
}

/** Grow a textarea with its content. */
export function autosize(ta) {
  const fit = () => { ta.style.height = 'auto'; ta.style.height = Math.min(ta.scrollHeight, 220) + 'px'; };
  ta.addEventListener('input', fit);
  requestAnimationFrame(fit);
}

export function docIcon(d) {
  if (d.origin === 'added' || d.origin === 'private') return { name: 'users', cls: 'added' };
  if (d.unit === 'sheet') return { name: 'sheet', cls: 'sheet' };
  if (/case/i.test(d.kind)) return { name: 'case', cls: 'case' };
  if (d.unit === 'slide') return { name: 'slides', cls: 'slides' };
  return { name: 'page', cls: '' };
}

export function unitWord(unit, n) {
  const w = unit === 'slide' ? 'slide' : unit === 'sheet' ? 'sheet' : unit === 'section' ? 'section' : 'page';
  return `${fmtNum(n)} ${w}${n === 1 ? '' : 's'}`;
}

export const MODULE_ICON = {
  accounting: ['ledger', ''], finance: ['coins', 'teal'], 'financial-management': ['case', 'amber'],
  'maths-stats': ['sigma', 'green'], excel: ['sheet', 'green'], other: ['book', 'gray'],
};
