# Using FinPrep Hub

The hub answers from our Finance Prep course: the lecture slides, the Excel script, the cases and
the exercise solutions. Every answer shows where it comes from.

## Ask

Type a question on **Ask** — in English or German — and choose how you want the answer:

| | You get |
|---|---|
| **Short** | a few lines and the key formula |
| **Explained** | the idea, the formula with every symbol explained, a worked example from the course, common mistakes |
| **Visual** | a diagram or a chart; press **Play** to go through it step by step |

- The small numbers in the answer are its sources. Click one to see the document and slides;
  click the source to open the document at that slide.
- Ask follow-ups in the same conversation ("and for bonds?"). **New conversation** starts fresh.
- Limit a question to one module with the menu next to the answer styles.
- Under every answer: **Answer again as** another style, **Copy**, **Helpful**, and **Not right…**
  — say what is wrong and the hub checks the materials again and tells you what it corrected.
- A teal box marked **General knowledge** means the course materials did not cover that part.
- Check important numbers against the slide the answer cites.

![A Visual answer: a chart with Play](images/desktop-visual.png)

## Read and ask one document

**Documents** lists everything in the hub by module. Open one to read it slide by slide.
On the right, ask questions about just this document; references like **p. 12** jump to the page.
**Summarise**, **Key formulas & terms** and **Draw it** are one click. **Chunks** shows how the
document was cut up for the search.

![A lecture on the left, questions about it on the right](images/desktop-document.png)

## Add knowledge

**Add knowledge** takes a PDF, Word, PowerPoint, Excel, text or Markdown file.

- **Add to the hub for everyone** — the hub checks that it fits the course and contains no personal
  data, then everyone can ask about it (about a minute later). Your name is optional.
- **Only for me** — it stays in your browser; you can talk to it, nobody else sees it.

![Adding a file: read, clean, check, chunk, publish](images/desktop-add.png)

Scanned PDFs (photos of pages) have no text the hub can read; use a version with selectable text.
Please only add material you are allowed to share with the class.
