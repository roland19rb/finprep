# API

All endpoints live under `/api`. Requests and responses are JSON, except the two streams.
When `ACCESS_CODE` is set, every endpoint except `/api/config` needs the header
`x-access-code: <code>`; without it the answer is `401 {"error": "...", "needsCode": true}`.
Browsers also send `x-client-id` (a random id kept in the browser) for the rate limit.

## GET /api/config

```json
{ "name": "FinPrep Hub", "course": "Finance Prep", "needsCode": true, "ready": true,
  "sharing": { "enabled": true, "mode": "direct", "reason": "" },
  "generalKnowledge": true, "maxUploadChars": 400000,
  "models": { "answer": "claude-sonnet-5-5", "helper": "claude-haiku-5-5" }, "version": "1.0.0" }
```

`ready` is false when no Anthropic key is set. `sharing.mode` is `direct`, `pull-request` or `local`.

## GET /api/catalog

```json
{ "modules": [{ "id": "accounting", "title": "Fundamentals of Accounting" }, …],
  "docs": [{ "id": "fof-04-risk-and-return", "title": "04 Risk and Return", "module": "finance",
             "moduleTitle": "Fundamentals of Finance", "kind": "Lecture slides", "origin": "course",
             "unit": "slide", "stats": { "pages": 29, "words": 4671, "chunks": 20 },
             "outline": [ … ], "keywords": [ … ], "added": null }, …],
  "stats": { "documents": 53, "chunks": 684, "pages": 1100, "words": 150581, "loadMs": 175 } }
```

## GET /api/doc?id=<id>

The full document file (see [ARCHITECTURE.md](ARCHITECTURE.md#the-knowledge-files)). `404` for unknown ids.

## POST /api/ask

```json
{ "question": "How do I calculate the WACC?",
  "mode": "short | explained | visual",
  "module": "finance",
  "history": [{ "q": "previous question", "a": "previous answer" }],
  "feedback": { "previousAnswer": "…", "note": "the tax rate is missing" },
  "docId": "fof-04-risk-and-return",
  "privateDoc": { "id": "…", "title": "…", "unit": "page", "pages": [{ "n": 1, "label": "Page 1", "text": "…" }] } }
```

Only `question` is required. With `docId` or `privateDoc` the question is about that document;
otherwise it is about the whole course (optionally one `module`). `400` for an empty or too long
question, `404` for an unknown `docId`, `429` when the rate limit is reached.

The answer is a stream of server-sent events:

| Event | Data | Meaning |
|---|---|---|
| `step` | `{ "kind": "search", "query": "…", "module": null, "auto": true }` | the first search |
| `step` | `{ "kind": "found", "count": 7, "documents": 4 }` | what it found |
| `step` | `{ "kind": "search", "query": "…", "count": 5 }` | a further search by the agent |
| `step` | `{ "kind": "read", "docId": "…", "title": "…", "label": "Slides 12–14" }` | read whole pages |
| `step` | `{ "kind": "write" }` | answer text starts |
| `sources` | `{ "items": [{ "n": 1, "docId": "…", "title": "…", "label": "Slides 13–14", "pages": [13, 14], "moduleTitle": "…", "kind": "…", "origin": "course", "section": "…", "heading": "…", "snippet": "…" }] }` | numbered sources the answer may cite |
| `delta` | `{ "text": "…" }` | a piece of the answer (Markdown) |
| `reset` | `{ "note": "Let me also check the lecture…" }` | text so far was a note before a tool call; start the answer again |
| `done` | `{ "stop": "end_turn", "rounds": 2, "ms": 9120, "model": "…", "usage": { … } }` | finished; `stop: "max_tokens"` means the answer was cut |
| `error` | `{ "message": "…" }` | a message that can be shown as it is |

## POST /api/ingest

```json
{ "fileName": "wacc-notes.pdf", "fileType": "pdf", "bytes": 48213,
  "title": "WACC summary", "by": "Anna", "intent": "hub | private", "unit": "slide | page | section | sheet",
  "pages": [{ "n": 1, "title": "…", "text": "…", "marks": { "top": ["…"], "bottom": ["…"] } }] }
```

Stream of events:

| Event | Data |
|---|---|
| `step` | `{ "id": "clean", "status": "run" }`, then `"done"` with `detail` (words, removed lines, page numbers) |
| `step` | `{ "id": "check", "status": "run" | "done" | "fail" | "skip", "detail": { "decision", "reason", "module", "moduleTitle", "title", "summary", "topics" } }` |
| `step` | `{ "id": "chunk", "status": "done", "detail": { "chunks", "avgWords", "preview": [ … ] } }` |
| `step` | `{ "id": "publish", "status": "done", "detail": { "mode": "direct", "url": "https://github.com/…/commit/…", "path": "data/docs/added-….json" } }` |
| `result` | `{ "decision": "published | pending | private | declined | already | unavailable", "doc": { … }, "reason": "…", "publish": { … } }` |
| `error` | `{ "message": "…" }` |

`pending` = a pull request waits for approval. `already` comes with `docId` of the existing document.

## POST /api/feedback

```json
{ "rating": "helpful | not_right", "mode": "short", "question": "…", "note": "…", "sources": ["doc-id", …] }
```

Answer `{"ok": true}`. The entry is written to the function log as one JSON line.
