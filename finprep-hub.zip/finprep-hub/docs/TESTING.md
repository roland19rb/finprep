# Testing

No Anthropic key and no GitHub token are needed: two stand-in servers in `test/` speak the same
wire format as the real APIs and reject requests the real APIs would reject.

## npm test

```bash
npm test          # Node 20+, no packages to install
```

| File | Checks |
|---|---|
| `test/textkit.test.mjs` | maths-letter repair, bullets, footer and page-number removal, section labels, running headers, slide/prose/sheet chunking rules, tokenizer |
| `test/search.test.mjs` | the course data loads completely; ten typical questions find the right lecture in the top 3 (WACC, debit/credit, Lagrange, NPV vs IRR, perpetuity proof, Euroland, p-value, VLOOKUP, "Kapitalwert", beta regression); expansions; module and document filters |
| `test/render.test.mjs` | escaping of model output, formulas, tables, lists, citations, dollar signs, "General knowledge" box, streaming placeholder, diagram grammar, chart JSON |
| `test/api.test.mjs` | the real handlers end to end: access code, catalogue, documents, a question with a tool round and streamed answer, forced final round, visual answers, talking to a document and to a private document, "Not right", bad input, adding a document (commit), pull-request mode, declined and private uploads, re-upload of a course PDF recognised, scans, an invalid key, repository detected on Vercel and Render |

`test/mock-anthropic.mjs` validates every request: API headers, alternating roles, every
`tool_result` matching an earlier `tool_use`, tools present when tool blocks are used, no
`temperature` (rejected by current models).

`node scripts/check-data.mjs` validates the knowledge files (run by the GitHub workflow on every push).

## Browser walkthrough

```bash
pip install playwright && python3 -m playwright install chromium
python3 test/e2e_browser.py
```

Starts both stand-ins and `server.js`, then runs the site in Chromium at desktop size and at phone
size (390 × 844): access code, start page, an Explained answer with formulas and sources, a Visual
answer with Play, the document list, a deep link to slide 12, a document question with a page
citation that jumps, adding a private document and opening it, no console errors. Screenshots go
to `test/screens/`.

## Trying the site without a key

```bash
node test/mock-anthropic.mjs 8787 &
ANTHROPIC_API_KEY=test ANTHROPIC_BASE_URL=http://localhost:8787 LOCAL_PUBLISH=true node server.js
```

The stand-in answers every question with the same short NPV text (so the flow can be seen);
`LOCAL_PUBLISH=true` saves added documents into `data/docs` instead of GitHub. Delete the
`added-*.json` files it creates before committing.

## After each deploy

1. Open the site, enter the access code.
2. Ask "What is the WACC?" in **Short** — an answer with at least one source.
3. Ask the same in **Visual** — a diagram or chart; press **Play**.
4. **Documents** → any lecture → **Summarise** — page citations that jump.
5. **Add knowledge** → a small PDF of notes → **Add to the hub** — a commit appears on GitHub;
   after about a minute the document is listed under **Added by the class**. Delete it on GitHub
   afterwards if it was only a test.
