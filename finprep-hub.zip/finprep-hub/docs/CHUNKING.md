# How the materials became searchable

A chunk is the unit the search works on: a few slides or a few paragraphs about one thing, about
230–300 words, with the document, section and slide numbers attached. Good chunks decide whether
the agent finds the right slide.

```mermaid
flowchart LR
  F["Course folder<br/>PDF · DOCX · XLSX · XLSB"] --> E["1 Extract<br/>extract_materials.py"]
  E --> P["Pages<br/>title · text · top/bottom lines"]
  P --> C["2 Clean<br/>textkit.cleanPages"]
  C --> K["3 Chunk<br/>textkit.chunkDocument"]
  K --> W["4 Keywords + outline<br/>build-docs.mjs"]
  W --> J[("data/docs/&lt;id&gt;.json")]
  J --> I["5 Index at start-up<br/>BM25, lib/search.js"]
```

Steps 2 and 3 are the same code (`public/js/shared/textkit.js`) for the course materials, for
documents students add (on the server) and in the browser.

## 1 · Extract: files to pages

| Type | How | One "page" is |
|---|---|---|
| Lecture slides, scripts (PDF, landscape) | PyMuPDF reads text blocks with positions and font sizes. Blocks are put in reading order with a recursive XY-cut (top to bottom, then column by column), so a two-column slide reads the left box, then the right box. The largest text in the top third is the slide title; formulas and numbers are never taken as titles. Tables are detected and rewritten as Markdown tables. | a slide |
| Cases, notes (PDF, portrait) | Same reader; paragraphs that continue on the next page are joined later. | a page |
| Scanned PDFs (the two maths proofs) | No text layer: the four pages were transcribed, formulas in LaTeX (`scripts/transcriptions.json`). | a page |
| t- and z-tables | Rebuilt row by row from word positions, so each line is one row of the table. | a page |
| Word (.docx) | Paragraphs and tables in order, split at headings and "Heading:" lines. | a section |
| Excel (.xlsx) | Each sheet, row by row: labels, values, and formulas with their results, e.g. `K7 =NPV(10%,C7:F7)+B7 → 191.75`. A formula copied across a row is written once with all its results; rows that repeat the same formulas and long blocks of data (price histories) are summarised in one line. | a sheet |
| Excel binary (.xlsb) | Cell values per sheet (formulas are not readable in this format). | a sheet |

For every PDF page the extractor also records the short lines in the top band (section labels such
as `B. PORTFOLIO THEORY`) and the bottom band (course name, copyright, page number). Cleaning uses
them.

## 2 · Clean

| What | Example | Rule |
|---|---|---|
| Running footers and headers | `Fundamentals of Finance`, `Kieso et al. 2017, Intermediate Accounting IFRS Edition`, `© Prof. Dr. …` | A line in the bottom band on ≥ 25 % of pages, or any line repeated exactly on ≥ 50 % of pages, is removed. |
| Page numbers | `43`, `# 50`, `3-20`, `Page 4 of 20` | Removed. |
| Section labels | `A. INTRODUCTION TO RISK AND RETURN` | A short top-band line repeated on consecutive slides becomes the **section** of those slides (and of the slides that follow until the next label). |
| Chapter name used as title | `Analysis of a Single Variable` on every slide | Becomes the section; the slide's own heading (`Average rate of change`) becomes the title. |
| Doubled maths letters | `𝑓𝑓(𝑥𝑥)` from Cambria Math exports | Repaired to `f(x)`; maths alphabet letters become plain letters so search finds them. |
| Bullets and ligatures | private-use bullet glyphs, `_ item`, `ﬁ` | `• item`, `fi`. |
| Broken lines | `… depends only on cash flow` / `forecasts and the discount rate.` | Joined when the next line continues the sentence; hyphenated words are rejoined. |
| Page kinds | cover, agenda/contents, section divider, content, empty | Covers and agendas become their own **overview** chunks (ranked lower in search); empty pages (pictures only) are skipped. |

What was removed is recorded in each file under `processing` (e.g. `removedRepeatedLines`).

## 3 · Chunk

| Document | Rule | Typical size |
|---|---|---|
| Slide decks | Consecutive slides are collected until about **230 words**; a chunk never exceeds **420 words** and never crosses a change of section. A section divider opens a new chunk. A single dense slide over 420 words is split at paragraphs. Each slide inside a chunk keeps its marker, e.g. `[Slide 12] Title`, so answers can cite the exact slide. | 2–4 slides |
| Text documents (cases, notes, Word) | Paragraphs are collected to about **300 words** (max 380). Each chunk starts with the last one or two sentences of the previous chunk (about 40 words), so an idea cut at the boundary is still found whole. Paragraphs that run across a page break are joined first. | 300 words |
| Spreadsheets | One chunk per sheet; long sheets are split into parts of about 360 words, each starting with `Sheet: <name> (continued)`. | 1 sheet |
| Overview pages | Cover, contents and agenda slides: one chunk each, weight 0.45 in search. | short |

Every chunk stores: `id` (`<doc>#006`), the page range, section, title(s), kind, word count,
6 keywords (most distinctive words, TF-IDF over all chunks) and the text.

**Result for the course:** 53 documents, 1,100 pages/slides/sheets → **684 chunks**, median 258
words (10 % are short overview or table chunks under 30 words, 90 % are under 360 words).

Open any document in the hub and switch to **Chunks** to see exactly what the search works on; the
**Pages** view marks which slides belong to which chunk.

Example (`data/docs/fof-04-risk-and-return.json`):

```json
{
  "id": "fof-04-risk-and-return#006",
  "pages": [11, 12],
  "section": "B. PORTFOLIO THEORY",
  "title": "What is a portfolio and what makes it useful? · Let us assume, the objective of an investor is …",
  "words": 314,
  "keywords": ["portfolio", "ωbasf", "ωdaimler", "daimler", "aug-2010", "aug-2020"],
  "text": "[Slide 11] What is a portfolio and what makes it useful?\nDefinition Portfolio\n\nA portfolio is a specific combination of securities, usually defined by portfolio weights that sum to 1.\n\n• Portfolio weights can sum to 0 …"
}
```

## 4 · Search

`lib/search.js` builds a BM25 index when the server starts (≈ 0.2 s for 684 chunks):

- Tokens: lower case, light English stemming (`returns → return`), English and German stop words
  removed, numbers kept; `t-table`, `z score`, `F-test` stay recognisable as `ttable`, `zscore`, `ftest`.
- Fields: document title, section and chunk title count twice; the text once.
- Query expansion: 61 course abbreviations and German terms in both directions
  (`NPV ↔ net present value`, `WACC`, `CAPM`, `P&L ↔ income statement`, `GuV`, `Kapitalwert`,
  `Ableitung`, `df ↔ degrees of freedom`, …) at half weight, plus 14 everyday synonyms
  (`revenue ↔ sales`, `volatility ↔ standard deviation`, …).
- Ranking: BM25 (k1 1.2, b 0.72) × chunk weight (overview 0.45, student work 0.85) × how many of
  the asked words a chunk contains.
- Variety: at most 3 chunks per document in the first results, 2 per document in later searches,
  and chunks already given to Claude are skipped.

The answering agent then decides whether the passages are enough or searches again with its own
words — see [AGENTS.md](AGENTS.md).

## Rebuilding the course materials

Needed only when the course folder changes in bulk (single documents are best added through the site).

```bash
pip install pymupdf openpyxl pyxlsb python-docx
python3 scripts/extract_materials.py --source "/path/to/OneDrive_1_13-10-2026" --out build/raw
node scripts/build-docs.mjs --raw build/raw --out data/docs
node scripts/check-data.mjs
npm test
```

To include a new file, add a line to `scripts/materials.json` (id, module, kind, title, file name
inside the module folder). Documents added by students (`added-*.json`) are never touched by the
build. Commit the changed `data/docs` files; the site redeploys.
