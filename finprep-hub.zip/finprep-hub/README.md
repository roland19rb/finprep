# FinPrep Hub

A knowledge hub for the Finance Prep course. Students ask questions and get answers from the
course's own lecture slides, script, cases and exercise files — with the slides they come from —
talk to any single document, and add their own notes for the whole class.

![Answer with sources](docs/images/desktop-answer.png)

<sub>Screens from the test run; the answer text there comes from the stand-in API, not from Claude.</sub>

| A Visual answer on a phone | Reading a lecture on a phone |
|---|---|
| <img src="docs/images/phone-visual.png" width="300" alt="Visual answer with a chart on a phone"> | <img src="docs/images/phone-document.png" width="300" alt="A lecture slide on a phone"> |

## What students can do

| | |
|---|---|
| **Ask the course** | Any question about accounting, finance, financial management, maths & statistics or Excel modelling. Choose how the answer comes back: **Short** (a few lines and the key formula), **Explained** (step by step, with an example from the course) or **Visual** (a diagram or chart with Play). Every statement cites its source; follow-up questions keep the context. |
| **Talk to a document** | Open any lecture, case or exercise file, read it slide by slide, see how it was cut into chunks, and ask about it. Answers cite pages (`p. 12`) that jump to the page. One-click **Summarise**, **Key formulas & terms**, **Draw it**. |
| **Add knowledge** | Upload a PDF, Word, PowerPoint, Excel, text or Markdown file. An agent reads, cleans, checks (fits the course? already there? personal data?), chunks and publishes it to the hub for everyone — or keeps it only in the student's browser. |
| **Rate and correct** | **Helpful** / **Not right…** on every answer. "Not right" sends the answer back to the agent with the student's note; it checks the materials again and says what it corrected. |

## What is inside

Built from the course folder (the two prompt `.md` files in that folder are not part of the knowledge):

| Module | Documents | Pages, slides, sheets | Chunks | Words |
|---|---:|---:|---:|---:|
| Fundamentals of Accounting | 6 | 226 | 62 | 9,089 |
| Fundamentals of Finance | 14 | 174 | 135 | 34,830 |
| Financial Management | 6 | 209 | 155 | 33,628 |
| Mathematics & Statistics | 23 | 359 | 220 | 50,759 |
| Excel Modelling | 4 | 132 | 112 | 22,275 |
| **Total** | **53** | **1,100** | **684** | **150,581** |

Lecture slides (32), exercise solutions and Excel models with their formulas (11), the course
script, two case studies, two scanned maths proofs (transcribed), the t- and z-tables, example data
and three pieces of student work on the Murray Ohio case. The Excel session files S01–S12 are
represented by the last state of each model (S05, S09, S12).

## How it works

```mermaid
flowchart LR
  subgraph Browser
    UI["Ask · Documents · Add knowledge"]
    RD["Read files<br/>(pdf.js, docx, pptx, xlsx)"]
  end
  subgraph Server["Vercel functions (Node)"]
    AG["Answering agent<br/>search → read → answer"]
    IN["Intake agent<br/>clean → check → chunk → publish"]
    IX["BM25 index over<br/>684+ chunks"]
  end
  D[("data/docs/*.json<br/>in the repository")]
  C["Claude<br/>(Anthropic API)"]
  G["GitHub<br/>commit = new knowledge"]
  UI -- question --> AG
  AG <--> IX
  AG <--> C
  RD -- pages --> IN
  IN <--> C
  IN --> G --> D
  D --> IX
```

- The knowledge is plain JSON in the repository: one file per document with its pages and chunks.
- Search is BM25 over the chunks with the course's abbreviations and German terms expanded
  (NPV ↔ net present value, Kapitalwert ↔ NPV, …). Claude searches again with its own words when
  the first results are not enough.
- A document added by a student is committed to `data/docs/` through the GitHub API; the push
  redeploys the site and the document is searchable for everyone about a minute later.
- The Anthropic key stays on the server. Students enter a class access code once.

## Quick start

- **Host it:** follow [DEPLOY.md](DEPLOY.md) (GitHub → Vercel, about 20 minutes, free hosting).
- **Run it locally:** `cp .env.example .env`, add `ANTHROPIC_API_KEY`, `node server.js`, open <http://localhost:3000>.
- **Test it:** `npm test` (no key needed — a stand-in Anthropic API checks every request).

## Repository

```
api/                 Vercel functions, one per endpoint (logic in lib/)
lib/
  routes.js          request handlers shared by Vercel and server.js
  agent.js           answering agent: search, tool rounds, streaming, citations
  intake.js          intake agent: clean, duplicate check, review, chunk, publish
  publish.js         commit or pull request on GitHub
  search.js          BM25 index and query expansion
  store.js           loads data/docs and builds the index
  prompts.js         all instructions to Claude, answer styles, tools
  anthropic.js       Messages API client with streaming and tool use
  env.js, http.js    settings, access code, rate limit, server-sent events
public/              the website (no build step)
  js/shared/textkit.js  cleaning + chunking + tokenizer — shared by build, server and browser
  js/extract.js      reads PDF/Word/PowerPoint/Excel/text in the browser
  js/visual.js       diagrams and charts with Play
  js/markdown.js     safe Markdown, formulas (KaTeX), citations
  vendor/            KaTeX, pdf.js     fonts/  IBM Plex
data/
  docs/*.json        the knowledge: 53 course documents (+ documents students add)
  modules.json       the five modules
scripts/
  materials.json     which course files are included, titles, modules
  extract_materials.py   course files → pages (PyMuPDF, openpyxl, pyxlsb, python-docx)
  build-docs.mjs     pages → cleaned pages + chunks + keywords → data/docs
  check-data.mjs     validates data/docs
  transcriptions.json    text of the two scanned proofs
test/                unit, search, rendering and API tests; stand-in Anthropic and GitHub APIs;
                     browser walkthrough (e2e_browser.py)
server.js            plain Node server (local runs, other hosts)
vercel.json          output folder, function limits, security headers
docs/                how it is built and how to use it
```

## Documentation

| | |
|---|---|
| [DEPLOY.md](DEPLOY.md) | Hosting step by step, settings, costs, limits, troubleshooting |
| [docs/USING.md](docs/USING.md) | One page for students |
| [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) | Components, flows, data files, security |
| [docs/CHUNKING.md](docs/CHUNKING.md) | How the materials became searchable chunks; rebuilding them |
| [docs/AGENTS.md](docs/AGENTS.md) | The answering, document and intake agents; their instructions and tools |
| [docs/API.md](docs/API.md) | Endpoints and streamed events |
| [docs/TESTING.md](docs/TESTING.md) | Tests, stand-in APIs, checks after a deploy |

Third-party files: KaTeX (MIT), pdf.js (Apache-2.0) and IBM Plex fonts (SIL Open Font License),
each with its licence in its folder. The course materials belong to their authors; see
[DEPLOY.md](DEPLOY.md#the-course-materials).
