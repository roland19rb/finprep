// Vercel function: POST /api/ask. The logic lives in lib/routes.js (shared with server.js).
import { handleAsk } from '../lib/routes.js';

export function POST(request) {
  return handleAsk(request);
}
