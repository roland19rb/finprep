// Vercel function: POST /api/ingest. The logic lives in lib/routes.js (shared with server.js).
import { handleIngest } from '../lib/routes.js';

export function POST(request) {
  return handleIngest(request);
}
