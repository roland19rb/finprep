// Vercel function: POST /api/feedback. The logic lives in lib/routes.js (shared with server.js).
import { handleFeedback } from '../lib/routes.js';

export function POST(request) {
  return handleFeedback(request);
}
