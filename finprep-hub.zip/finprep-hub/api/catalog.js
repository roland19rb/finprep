// Vercel function: GET /api/catalog. The logic lives in lib/routes.js (shared with server.js).
import { handleCatalog } from '../lib/routes.js';

export function GET(request) {
  return handleCatalog(request);
}
