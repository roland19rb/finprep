// Vercel function: GET /api/config. The logic lives in lib/routes.js (shared with server.js).
import { handleConfig } from '../lib/routes.js';

export function GET(request) {
  return handleConfig(request);
}
