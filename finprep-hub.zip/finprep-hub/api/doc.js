// Vercel function: GET /api/doc. The logic lives in lib/routes.js (shared with server.js).
import { handleDoc } from '../lib/routes.js';

export function GET(request) {
  return handleDoc(request);
}
