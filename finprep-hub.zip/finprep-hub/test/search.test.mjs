// Retrieval quality on the real course data in data/docs: typical questions must find the
// lecture that teaches the topic among the first results.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { getStore } from '../lib/store.js';
import { queryTerms } from '../lib/search.js';

const store = getStore();

const CASES = [
  ['What is WACC and how is it calculated?', ['fm-p21-lecture', 'fof-05-cash-flows-capital-budgeting', 'fof-ex05-07-solution']],
  ['difference between debit and credit', ['acc-2-bookkeeping-part-1']],
  ['Lagrange multiplier', ['bm-14-optimization-with-constraints']],
  ['IRR vs NPV which to choose', ['fm-p21-lecture', 'fof-03-investment-decisions']],
  ['perpetuity formula proof', ['fof-01-proof-perpetuity']],
  ['Euroland Foods spending limit capital budget', ['fm-case-euroland-foods']],
  ['p-value hypothesis test', ['bs-5-inferential-statistics']],
  ['VLOOKUP INDEX MATCH', ['xl-course-script', 'xl-product-analysis-model']],
  ['Wie berechnet man den Kapitalwert?', ['fof-03-investment-decisions', 'fm-p21-lecture']],
  ['beta regression', ['fof-ex04-portfolios-solution']],
];

test('the course data loads', () => {
  assert.ok(store.docs.length >= 50, `documents: ${store.docs.length}`);
  assert.ok(store.index.items.length >= 600, `chunks: ${store.index.items.length}`);
  for (const d of store.docs) {
    assert.ok(d.title && d.module && d.pages.length, `document ${d.id} is complete`);
    for (const c of d.chunks) assert.ok(c.id.startsWith(d.id + '#') && c.text.length > 0, `chunk ${c.id}`);
  }
});

for (const [q, expected] of CASES) {
  test(`finds the right lecture: ${q}`, () => {
    const hits = store.index.search(q, { k: 5 });
    assert.ok(hits.length, 'has results');
    const ids = hits.map((h) => h.doc.id);
    assert.ok(expected.some((e) => ids.slice(0, 3).includes(e)), `top 3 were ${ids.slice(0, 3).join(', ')}`);
  });
}

test('abbreviations and German terms are expanded', () => {
  const t = queryTerms('NPV');
  assert.ok(t.has('npv') && t.has('present') && t.get('present') < 1);
  assert.ok(queryTerms('net present value').has('npv'));
  assert.ok(queryTerms('Kapitalwert').has('present'));
});

test('module filter and document filter', () => {
  const hits = store.index.search('present value', { k: 10, module: 'accounting' });
  assert.ok(hits.every((h) => h.doc.module === 'accounting'));
  const inDoc = store.index.search('portfolio', { k: 10, docId: 'fof-04-risk-and-return', perDoc: 10 });
  assert.ok(inDoc.length && inDoc.every((h) => h.doc.id === 'fof-04-risk-and-return'));
});
