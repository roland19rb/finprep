#!/usr/bin/env python3
"""Browser walkthrough of the whole site against the stand-in Claude and GitHub APIs.

    pip install playwright && python3 -m playwright install chromium
    python3 test/e2e_browser.py            # desktop and phone, screenshots in test/screens/

It starts test/mock-anthropic.mjs, test/mock-github.mjs and server.js on free ports, then
checks: start page, a course question (Explained and Visual), sources, the documents list,
a document with its chunks and a question about it, adding a private document, the access code.
Exit code 1 when a check fails or the page logs an error.
"""
import os
import socket
import subprocess
import sys
import shutil
import tempfile
import time
from contextlib import closing

from playwright.sync_api import sync_playwright

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SHOTS = os.path.join(ROOT, 'test', 'screens')


def free_port():
    with closing(socket.socket()) as s:
        s.bind(('127.0.0.1', 0))
        return s.getsockname()[1]


def wait_port(port, timeout=10):
    end = time.time() + timeout
    while time.time() < end:
        try:
            with closing(socket.create_connection(('127.0.0.1', port), timeout=0.3)):
                return
        except OSError:
            time.sleep(0.1)
    raise RuntimeError(f'port {port} did not open')


def start(cmd, env=None):
    return subprocess.Popen(cmd, cwd=ROOT, env={**os.environ, **(env or {})}, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)


failures = []


def check(cond, what):
    print(('  ok   ' if cond else '  FAIL ') + what)
    if not cond:
        failures.append(what)


def run(pw, base, mobile):
    browser = pw.chromium.launch()
    ctx = browser.new_context(**({'viewport': {'width': 390, 'height': 844}, 'is_mobile': True, 'has_touch': True, 'device_scale_factor': 2} if mobile else {'viewport': {'width': 1440, 'height': 900}}))
    page = ctx.new_page()
    errors = []
    page.on('pageerror', lambda e: errors.append(str(e)))
    page.on('console', lambda m: errors.append(m.text) if m.type == 'error' else None)
    tag = 'phone' if mobile else 'desktop'
    shot = lambda name: page.screenshot(path=os.path.join(SHOTS, f'{tag}-{name}.png'))
    print(f'\n{tag}')

    page.goto(base + '/')
    page.wait_for_selector('.gate input')
    page.fill('.gate input', 'class2026')
    page.keyboard.press('Enter')
    page.wait_for_selector('.mod-grid .mod')
    check(page.locator('.mod-grid .mod').count() >= 5, 'start page lists the course modules')
    shot('start')

    page.click('.seg [data-mode="explained"]')
    page.fill('.askbox textarea', 'What is the NPV and how do I calculate it?')
    page.keyboard.press('Enter')
    page.wait_for_selector('.a-actions:not([hidden])', timeout=15000)
    check(page.locator('.a-body .katex').count() >= 1, 'formulas are rendered')
    check(page.locator('.a-sources .src').count() >= 1, 'the answer lists its sources')
    check(page.locator('.a-body .cite').count() >= 1, 'the answer has citations')
    shot('answer')

    page.locator('.dock .askbox textarea').click()
    page.click('.dock .seg [data-mode="visual"]')
    page.fill('.dock .askbox textarea', 'Show how NPV changes with the discount rate as a chart')
    page.keyboard.press('Enter')
    # (locators instead of wait_for_function: the site's Content-Security-Policy forbids eval)
    page.locator('.turn').nth(1).locator('.a-actions:not([hidden])').wait_for(timeout=15000)
    page.wait_for_selector('.turn:nth-child(2) .viz svg', timeout=5000)
    check(page.locator('.turn:nth-child(2) .viz svg .ch-line').count() >= 1, 'a chart answer is drawn')
    page.locator('.turn:nth-child(2) .viz').scroll_into_view_if_needed()
    page.click('.turn:nth-child(2) .viz [data-v="play"]')
    page.wait_for_timeout(600)
    check('1 /' in page.inner_text('.turn:nth-child(2) .viz-caption'), 'Play steps through the visual')
    shot('visual')

    page.goto(base + '/#/docs')
    page.wait_for_selector('.doc-row')
    check(page.locator('.doc-row').count() >= 50, 'the documents page lists the course documents')
    page.goto(base + '/#/doc/fof-04-risk-and-return?p=12')
    page.wait_for_selector('#pg-12.hl')
    check(True, 'a deep link opens the document at slide 12')
    if mobile:
        page.click('.dv-tabs [data-pane="chat"]')
    page.click('[data-quick="Summarise"]')
    page.wait_for_selector('.chat .a-actions:not([hidden])', timeout=15000)
    check(page.locator('.chat .cite.page').count() >= 1, 'answers about a document cite its pages')
    page.locator('.chat .cite.page').first.click()
    page.wait_for_timeout(500)
    check(page.locator('.pg.hl').count() == 1, 'a page citation jumps to the page')
    shot('document')

    tmpdir = tempfile.mkdtemp()
    notes = os.path.join(tmpdir, 'bond-pricing-notes.md')
    with open(notes, 'w') as f:
        f.write('# Bond pricing\n\nA bond price is the present value of its coupons and face value, discounted at the yield to maturity.\n\n# Duration\n\nDuration measures how sensitive the price is to a change in yields; longer bonds react more strongly.\n' * 3)
    page.goto(base + '/#/add')
    page.set_input_files('input[type=file]', notes)
    page.wait_for_selector('[data-a="go"]:not([disabled])')
    page.click('.intent label:nth-child(2)')
    page.click('[data-a="go"]')
    page.wait_for_selector('.result .verdict', timeout=15000)
    check('kept in this browser' in page.inner_text('.result'), 'a private document is processed')
    shot('add')
    page.click('.result a.btn.primary')
    page.wait_for_selector('.dv-head h1')
    check('only in this browser' in page.inner_text('.dv-chips'), 'the private document opens')
    shutil.rmtree(tmpdir, ignore_errors=True)

    real = [e for e in errors if 'status of 401' not in e]
    check(not real, 'no errors in the browser console' + (f': {real[:3]}' if real else ''))
    browser.close()


def main():
    os.makedirs(SHOTS, exist_ok=True)
    pa, pg, ps = free_port(), free_port(), free_port()
    procs = [
        start(['node', 'test/mock-anthropic.mjs', str(pa)]),
        start(['node', 'test/mock-github.mjs', str(pg)]),
    ]
    try:
        wait_port(pa)
        wait_port(pg)
        procs.append(start(['node', 'server.js'], {
            'PORT': str(ps), 'ANTHROPIC_API_KEY': 'sk-test', 'ANTHROPIC_BASE_URL': f'http://127.0.0.1:{pa}',
            'GITHUB_TOKEN': 'ghp_test', 'GITHUB_REPO': 'class/finprep-hub', 'GITHUB_API_URL': f'http://127.0.0.1:{pg}',
            'ACCESS_CODE': 'class2026',
        }))
        wait_port(ps)
        with sync_playwright() as pw:
            for mobile in (False, True):
                run(pw, f'http://127.0.0.1:{ps}', mobile)
    finally:
        for p in procs:
            p.terminate()
    print(f'\n{len(failures)} failure(s)' if failures else '\nall browser checks passed')
    sys.exit(1 if failures else 0)


if __name__ == '__main__':
    main()
