// Cleaning and chunking (public/js/shared/textkit.js) — the code shared by the build script,
// the server and the browser.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { normalizeText, hasDoubledMath, cleanPages, chunkDocument, tokenize, keywords } from '../public/js/shared/textkit.js';

test('repairs doubled maths letters and maps them to plain letters', () => {
  const raw = 'The function 𝑓𝑓 on [𝑥𝑥0, 𝑥𝑥0 + Δ𝑥𝑥] and 𝑦𝑦changes when 𝑥𝑥changes; 𝑓𝑓(𝑥𝑥) = 𝑥𝑥𝟐𝟐';
  assert.equal(hasDoubledMath(raw), true);
  const t = normalizeText(raw, { doubledMath: true });
  assert.match(t, /function f on \[x0, x0 \+ Δx\]/);
  assert.match(t, /y changes when x changes/);
});

test('bullets, ligatures and private-use glyphs become plain text', () => {
  const t = normalizeText('\nfirst point\n_ second point\nThe ﬁrm');
  assert.match(t, /• second point/);
  assert.match(t, /The firm/);
  assert.ok(!/[-]/u.test(t));
});

test('removes running footers, page numbers and finds section labels', () => {
  const pages = Array.from({ length: 8 }, (_, i) => ({
    n: i + 1,
    title: `Topic ${i + 1} explained`,
    text: `Topic ${i + 1} explained\n\nBody text for slide ${i + 1} about net present value and discounting of cash flows.\n${i + 3}\nFundamentals of Finance`,
    marks: { top: [i < 4 ? 'A. INTRODUCTION' : 'B. PORTFOLIO THEORY'], bottom: ['Fundamentals of Finance', String(i + 3)] },
  }));
  const { pages: out, report } = cleanPages(pages, { unit: 'slide' });
  assert.ok(report.removed.some((r) => r.text === 'Fundamentals of Finance'));
  assert.ok(out.every((p) => !p.text.includes('Fundamentals of Finance')));
  assert.equal(out[0].section, 'A. INTRODUCTION');
  assert.equal(out[6].section, 'B. PORTFOLIO THEORY');
  assert.ok(report.pageNumbers >= 1);
});

test('a title repeated on most slides becomes the section; the slide heading becomes the title', () => {
  const pages = Array.from({ length: 10 }, (_, i) => ({
    n: i + 1, title: 'Analysis of a Single Variable',
    text: `Analysis of a Single Variable\n\nHeading ${i + 1}\nThe derivative measures the rate of change of a function at a point number ${i}.`,
  }));
  const { pages: out, report } = cleanPages(pages, { unit: 'slide' });
  assert.equal(report.runningHeader, 'Analysis of a Single Variable');
  assert.equal(out[3].title, 'Heading 4');
  assert.equal(out[3].section, 'Analysis of a Single Variable');
});

test('slides are grouped into chunks without crossing a section change', () => {
  const pages = Array.from({ length: 12 }, (_, i) => ({
    n: i + 1, label: `Slide ${i + 1}`, title: `Slide title ${i + 1}`, section: i < 6 ? 'A. First part' : 'B. Second part', kind: 'content',
    text: 'word '.repeat(90).trim(), words: 93,
  }));
  const chunks = chunkDocument(pages, { unit: 'slide' });
  assert.ok(chunks.length >= 4);
  for (const c of chunks) {
    assert.ok(c.words <= 430, `chunk ${c.n} has ${c.words} words`);
    const secs = new Set(pages.filter((p) => p.n >= c.pages[0] && p.n <= c.pages[1]).map((p) => p.section));
    assert.equal(secs.size, 1, 'a chunk stays inside one section');
  }
  assert.match(chunks[0].text, /^\[Slide 1\] Slide title 1/);
});

test('long prose becomes overlapping chunks of about 300 words', () => {
  const sentence = 'Euroland Foods had to choose among eleven projects under a strict capital budget. ';
  const pages = Array.from({ length: 4 }, (_, i) => ({ n: i + 1, label: `Page ${i + 1}`, title: null, section: null, kind: 'content', text: sentence.repeat(30), words: 390 }));
  const chunks = chunkDocument(pages, { unit: 'page' });
  assert.ok(chunks.length >= 5);
  assert.ok(chunks.slice(1).every((c) => c.overlap > 0), 'every chunk after the first repeats the end of the previous one');
  assert.ok(chunks.every((c) => c.words <= 400));
});

test('one chunk per sheet, long sheets split into parts', () => {
  const rows = Array.from({ length: 160 }, (_, i) => `R${i + 1}: Sales | 100, 110, 121 | B${i + 1} =A${i + 1}*1.1 → 110`).join('\n');
  const chunks = chunkDocument([
    { n: 1, label: 'Sheet “Small”', title: 'Small', kind: 'content', text: 'Sheet: Small\nR1: r | 10%', words: 6 },
    { n: 2, label: 'Sheet “IS”', title: 'IS', kind: 'content', text: `Sheet: IS\n${rows}`, words: 1600 },
  ], { unit: 'sheet' });
  assert.equal(chunks[0].pages[0], 1);
  assert.ok(chunks.filter((c) => c.pages[0] === 2).length >= 4);
  assert.ok(chunks.filter((c) => c.pages[0] === 2).slice(1).every((c) => c.text.startsWith('Sheet: IS (continued)')));
});

test('tokenizer: stems, stop words, t-table compounds', () => {
  assert.deepEqual(tokenize('The returns of the portfolios'), ['return', 'portfolio']);
  assert.ok(tokenize('t-distribution table').includes('tdistribution'));
  assert.ok(tokenize('z score').includes('zscore'));
  const df = new Map([['portfolio', 50], ['variance', 3]]);
  assert.deepEqual(keywords('portfolio variance variance', df, 100, 2), ['variance', 'portfolio']);
});
