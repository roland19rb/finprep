// A stand-in for the Anthropic Messages API, used by the tests and for trying the site
// without a key:  node test/mock-anthropic.mjs 8787  then  ANTHROPIC_BASE_URL=http://localhost:8787
//
// It speaks the real wire format (JSON and server-sent events with tool use) and checks the
// requests the hub sends: headers, alternating roles, tool_result ids that match tool_use ids,
// no temperature (rejected by current models).

import http from 'node:http';

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export function validate(body, headers) {
  const problems = [];
  if (!headers['x-api-key']) problems.push('missing x-api-key');
  if (headers['anthropic-version'] !== '2023-06-01') problems.push('wrong anthropic-version');
  if (!body.model) problems.push('missing model');
  if (!body.max_tokens) problems.push('missing max_tokens');
  if ('temperature' in body) problems.push('temperature is not accepted by current models');
  if (!Array.isArray(body.messages) || !body.messages.length) problems.push('missing messages');
  let prevRole = null;
  const toolIds = new Set();
  for (const m of body.messages || []) {
    if (m.role === prevRole) problems.push('roles must alternate');
    prevRole = m.role;
    const parts = Array.isArray(m.content) ? m.content : [{ type: 'text', text: m.content }];
    for (const p of parts) {
      if (p.type === 'tool_use') toolIds.add(p.id);
      if (p.type === 'tool_result' && !toolIds.has(p.tool_use_id)) problems.push(`tool_result for unknown id ${p.tool_use_id}`);
      if ((p.type === 'tool_use' || p.type === 'tool_result') && !body.tools) problems.push('tool blocks need tools');
    }
  }
  if (body.messages?.[0]?.role !== 'user') problems.push('first message must be from the user');
  return problems;
}

function textOf(content) {
  if (typeof content === 'string') return content;
  return (content || []).map((p) => (p.type === 'text' ? p.text : p.type === 'tool_result' ? (typeof p.content === 'string' ? p.content : textOf(p.content)) : '')).join('\n');
}

function systemText(body) {
  return Array.isArray(body.system) ? body.system.map((b) => b.text).join('\n') : String(body.system || '');
}

function plan(body) {
  const system = systemText(body);
  const all = body.messages.map((m) => textOf(m.content)).join('\n');
  const first = textOf(body.messages[0].content);
  const question = (first.match(/Question(?: about this document)?: ([^\n]+)/) || [])[1] || 'the question';
  const hasToolResult = body.messages.some((m) => Array.isArray(m.content) && m.content.some((p) => p.type === 'tool_result'));
  const tools = (body.tools || []).map((t) => t.name);

  if (tools.includes('record_review')) {
    const decline = /DECLINE-ME|lottery|password list/i.test(all);
    return {
      blocks: [{
        type: 'tool_use', name: 'record_review', input: {
          decision: decline ? 'decline' : 'publish',
          reason: decline ? 'This file is not about the course topics.' : 'These are clear study notes on a course topic.',
          module: /bookkeeping|debit|balance sheet/i.test(all) ? 'accounting' : 'finance',
          title: (all.match(/Title given by the student: ([^\n]+)/) || [])[1] || 'Student notes',
          summary: 'Notes that explain a course topic with formulas and an example.',
          topics: ['net present value', 'discounting'],
          personal_data: false,
        },
      }],
      stop: 'tool_use',
    };
  }

  const docMode = /working with one document/.test(system);
  const visual = /Answer style: VISUAL/.test(all);
  const short = /Answer style: SHORT/.test(all);
  if (tools.includes('search_materials') && !hasToolResult && body.tool_choice?.type !== 'none' && !/NO-TOOLS/.test(question)) {
    return {
      blocks: [
        { type: 'text', text: 'Let me also check the lecture on this.' },
        { type: 'tool_use', name: 'search_materials', input: { query: question.replace(/[?]/g, '') + ' formula example' } },
      ],
      stop: 'tool_use',
    };
  }
  const numbers = [...new Set([...all.matchAll(/^\[(\d+)\]/gm)].map((m) => Number(m[1])))].slice(0, 4);
  const cite = (i) => (docMode ? `[p. ${i + 2}]` : numbers.length ? `[${numbers[i % numbers.length]}]` : '');
  let text;
  if (/feedback|not right/i.test(all) && /previous_answer/.test(all)) {
    text = `I corrected the discount factor: it uses \\((1+r)^t\\), not \\(1+r\\cdot t\\) ${cite(0)}.\n\n`;
  } else text = '';
  if (visual) {
    const chart = /chart|rate|grow|over time/i.test(question);
    text += `Here is how it fits together ${cite(0)}.\n\n` + (chart
      ? '```chart\n{"type":"line","title":"NPV falls as the discount rate rises","x":{"label":"Discount rate (%)","values":[0,5,10,15,20,25]},"y":{"label":"NPV (€)"},"series":[{"name":"Project A","values":[400,264,150,54,-27,-95]},{"name":"Project B","values":[650,420,240,98,-15,-110]}],"mark":{"x":18.4,"label":"IRR ≈ 18.4%"}}\n```\n'
      : '```diagram\ntitle: From cash flows to the investment decision\nlane Inputs: cf, r\nlane Valuation: pv, npv\nlane Decision: dec\ncf = Expected cash flows | forecast for each year [1]\nr = Discount rate | cost of capital, from CAPM [2]\npv = Present values | each cash flow divided by (1+r)^t [1]\nnpv = NPV | sum of PVs minus the investment [1]\ndec = Invest if NPV > 0 | adds value for the owners [3]\ncf -> pv : discount\nr -> pv\npv -> npv : add up\nnpv -> dec : compare with 0\nfocus: npv\n```\n')
      + `\n- Read it from left to right ${cite(1)}.\n- The highlighted box is the key result ${cite(0)}.\n`;
  } else if (short) {
    text += `The **net present value** is the sum of all discounted cash flows minus the initial investment ${cite(0)}: \\(NPV = -I_0 + \\sum_{t=1}^{T} \\frac{CF_t}{(1+r)^t}\\). Invest when it is positive ${cite(1)}.`;
  } else {
    text += `### The idea\nA euro today is worth more than a euro tomorrow, so future cash flows are discounted ${cite(0)}.\n\n### The formula\n\\[ NPV = -I_0 + \\sum_{t=1}^{T} \\frac{CF_t}{(1+r)^t} \\]\nwhere \\(I_0\\) is the investment, \\(CF_t\\) the cash flow in year \\(t\\) and \\(r\\) the discount rate ${cite(1)}.\n\n### Worked example\n| Year | Cash flow | Discount factor at 10% | Present value |\n|---|---|---|---|\n| 0 | −600 | 1.000 | −600.00 |\n| 1 | 200 | 0.909 | 181.82 |\n| 2 | 300 | 0.826 | 247.93 |\n\n**Outside the course materials:** many textbooks call the discount factor \\(1/(1+r)^t\\) the *present value factor*.`;
  }
  return { blocks: [{ type: 'text', text }], stop: 'end_turn' };
}

async function stream(res, body, p) {
  res.writeHead(200, { 'content-type': 'text/event-stream', 'cache-control': 'no-cache' });
  const send = (event, data) => res.write(`event: ${event}\ndata: ${JSON.stringify({ type: event, ...data })}\n\n`);
  send('message_start', { message: { id: 'msg_mock', type: 'message', role: 'assistant', model: body.model, content: [], usage: { input_tokens: 1200, output_tokens: 1, cache_read_input_tokens: 0 } } });
  send('ping', {});
  let index = 0;
  for (const b of p.blocks) {
    if (b.type === 'text') {
      send('content_block_start', { index, content_block: { type: 'text', text: '' } });
      const parts = b.text.match(/[\s\S]{1,18}/g) || [];
      for (const part of parts) {
        send('content_block_delta', { index, delta: { type: 'text_delta', text: part } });
        await sleep(4);
      }
    } else {
      send('content_block_start', { index, content_block: { type: 'tool_use', id: `toolu_mock_${Math.random().toString(36).slice(2, 10)}`, name: b.name, input: {} } });
      const json = JSON.stringify(b.input);
      for (let i = 0; i < json.length; i += 12) send('content_block_delta', { index, delta: { type: 'input_json_delta', partial_json: json.slice(i, i + 12) } });
    }
    send('content_block_stop', { index });
    index++;
  }
  send('message_delta', { delta: { stop_reason: p.stop, stop_sequence: null }, usage: { output_tokens: 240 } });
  send('message_stop', {});
  res.end();
}

export function createMockAnthropic({ log = [] } = {}) {
  return http.createServer((req, res) => {
    let raw = '';
    req.on('data', (c) => { raw += c; });
    req.on('end', async () => {
      if (req.method !== 'POST' || req.url !== '/v1/messages') { res.writeHead(404).end(); return; }
      let body;
      try { body = JSON.parse(raw); } catch { res.writeHead(400).end('{"type":"error","error":{"type":"invalid_request_error","message":"bad json"}}'); return; }
      const problems = validate(body, req.headers);
      log.push({ body, problems });
      if (problems.length) {
        res.writeHead(400, { 'content-type': 'application/json' });
        res.end(JSON.stringify({ type: 'error', error: { type: 'invalid_request_error', message: problems.join('; ') } }));
        return;
      }
      if (req.headers['x-api-key'] === 'sk-invalid') {
        res.writeHead(401, { 'content-type': 'application/json' }).end('{"type":"error","error":{"type":"authentication_error","message":"invalid x-api-key"}}');
        return;
      }
      const p = plan(body);
      if (body.stream) { await stream(res, body, p); return; }
      const content = p.blocks.map((b) => (b.type === 'text' ? b : { ...b, id: 'toolu_mock_review' }));
      res.writeHead(200, { 'content-type': 'application/json' });
      res.end(JSON.stringify({ id: 'msg_mock', type: 'message', role: 'assistant', model: body.model, content, stop_reason: p.stop, usage: { input_tokens: 900, output_tokens: 120 } }));
    });
  });
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const port = Number(process.argv[2]) || 8787;
  createMockAnthropic().listen(port, () => console.log(`mock Anthropic API on http://localhost:${port}`));
}
