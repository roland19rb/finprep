// The API end to end: the real handlers talk to a stand-in Anthropic API (same wire format,
// with request checks) and a stand-in GitHub API.
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { createMockAnthropic } from './mock-anthropic.mjs';
import { createMockGitHub } from './mock-github.mjs';

const claudeLog = [];
const ghLog = [];
const ghFiles = new Map();
let claude;
let github;
let routes;

function listen(server) {
  return new Promise((resolve) => server.listen(0, '127.0.0.1', () => resolve(server.address().port)));
}

before(async () => {
  claude = createMockAnthropic({ log: claudeLog });
  github = createMockGitHub({ files: ghFiles, log: ghLog });
  const cp = await listen(claude);
  const gp = await listen(github);
  Object.assign(process.env, {
    ANTHROPIC_API_KEY: 'sk-test',
    ANTHROPIC_BASE_URL: `http://127.0.0.1:${cp}`,
    GITHUB_TOKEN: 'ghp_test',
    GITHUB_REPO: 'class/finprep-hub',
    GITHUB_BRANCH: 'main',
    GITHUB_API_URL: `http://127.0.0.1:${gp}`,
    ACCESS_CODE: 'class2026',
    PUBLISH_MODE: 'direct',
  });
  routes = await import('../lib/routes.js');
});

after(() => { claude.close(); github.close(); });

const req = (path, { method = 'GET', body, code = 'class2026' } = {}) => new Request(`http://hub.test${path}`, {
  method,
  headers: { 'content-type': 'application/json', ...(code ? { 'x-access-code': code } : {}) },
  body: body ? JSON.stringify(body) : undefined,
});

async function events(response) {
  const text = await response.text();
  return text.split('\n\n').filter((b) => b.startsWith('event:')).map((b) => {
    const [e, d] = b.split('\n');
    return { event: e.slice(7), data: JSON.parse(d.slice(6)) };
  });
}

test('config is public and says an access code is needed', async () => {
  const r = await routes.handleConfig(req('/api/config', { code: null }));
  const body = await r.json();
  assert.equal(r.status, 200);
  assert.equal(body.needsCode, true);
  assert.equal(body.ready, true);
  assert.equal(body.sharing.enabled, true);
  assert.ok(!JSON.stringify(body).includes('sk-test'), 'the key never leaves the server');
});

test('the catalogue needs the right access code', async () => {
  assert.equal((await routes.handleCatalog(req('/api/catalog', { code: null }))).status, 401);
  assert.equal((await routes.handleCatalog(req('/api/catalog', { code: 'nope' }))).status, 401);
  const r = await routes.handleCatalog(req('/api/catalog'));
  const body = await r.json();
  assert.equal(r.status, 200);
  assert.ok(body.docs.length >= 50 && body.modules.length >= 5);
  assert.ok(!('pages' in body.docs[0]), 'the catalogue is light');
});

test('a document with pages and chunks; unknown ids are 404', async () => {
  const r = await routes.handleDoc(req('/api/doc?id=fof-03-investment-decisions'));
  const doc = await r.json();
  assert.equal(doc.id, 'fof-03-investment-decisions');
  assert.ok(doc.pages.length && doc.chunks.length);
  assert.equal((await routes.handleDoc(req('/api/doc?id=nothing'))).status, 404);
});

test('a course question: search, a tool round, a streamed answer with sources', async () => {
  claudeLog.length = 0;
  const r = await routes.handleAsk(req('/api/ask', { method: 'POST', body: { question: 'What is the NPV and how do I calculate it?', mode: 'explained' } }));
  assert.equal(r.headers.get('content-type'), 'text/event-stream; charset=utf-8');
  const ev = await events(r);
  const kinds = ev.map((e) => e.event);
  assert.ok(kinds.includes('sources') && kinds.includes('delta') && kinds.at(-1) === 'done', kinds.join(','));
  assert.ok(ev.some((e) => e.event === 'reset'), 'the note before the tool call is moved out of the answer');
  assert.ok(ev.filter((e) => e.event === 'step' && e.data.kind === 'search').length >= 2, 'searched twice');
  const text = ev.filter((e) => e.event === 'delta').map((e) => e.data.text).join('');
  assert.match(text, /NPV/);
  assert.equal(ev.at(-1).data.rounds, 2);
  assert.equal(claudeLog.length, 2);
  assert.deepEqual(claudeLog.flatMap((l) => l.problems), [], 'every request to Claude was valid');
  const first = claudeLog[0].body;
  assert.equal(first.model, 'claude-sonnet-5-5');
  assert.equal(first.system[0].cache_control.type, 'ephemeral');
  assert.ok(first.tools.some((t) => t.name === 'search_materials'));
  assert.match(first.messages[0].content[0].text, /Answer style: EXPLAINED/);
});

test('the last round cannot call tools', async () => {
  process.env.MAX_TOOL_ROUNDS = '0';
  claudeLog.length = 0;
  const ev = await events(await routes.handleAsk(req('/api/ask', { method: 'POST', body: { question: 'What is a perpetuity?', mode: 'short' } })));
  delete process.env.MAX_TOOL_ROUNDS;
  assert.equal(claudeLog[0].body.tool_choice.type, 'none');
  assert.equal(ev.at(-1).event, 'done');
});

test('visual answers carry a diagram or chart block', async () => {
  const ev = await events(await routes.handleAsk(req('/api/ask', { method: 'POST', body: { question: 'Show how NPV changes with the discount rate as a chart', mode: 'visual' } })));
  const text = ev.filter((e) => e.event === 'delta').map((e) => e.data.text).join('');
  assert.match(text, /```chart\n\{/);
});

test('talk to a document: the whole document goes to Claude, answers cite pages', async () => {
  claudeLog.length = 0;
  const ev = await events(await routes.handleAsk(req('/api/ask', { method: 'POST', body: { question: 'What is the main idea?', mode: 'short', docId: 'fof-01-introduction' } })));
  assert.equal(ev.at(-1).event, 'done');
  const body = claudeLog[0].body;
  assert.match(body.messages[0].content[0].text, /^<document title=/);
  assert.equal(body.messages[0].content[0].cache_control.type, 'ephemeral');
  assert.match(ev.filter((e) => e.event === 'delta').map((e) => e.data.text).join(''), /\[p\. \d+\]/);
});

test('talk to a private document sent by the browser', async () => {
  const privateDoc = { id: 'private-x', title: 'My notes', unit: 'page', pages: [{ n: 1, label: 'Page 1', text: 'The WACC mixes the cost of equity and the after-tax cost of debt.' }] };
  const ev = await events(await routes.handleAsk(req('/api/ask', { method: 'POST', body: { question: 'What is in it?', mode: 'short', privateDoc } })));
  assert.equal(ev.at(-1).event, 'done');
});

test('"Not right" sends the previous answer and the note back for a second check', async () => {
  claudeLog.length = 0;
  const ev = await events(await routes.handleAsk(req('/api/ask', { method: 'POST', body: { question: 'What is the NPV?', mode: 'short', feedback: { previousAnswer: 'NPV is the sum of cash flows.', note: 'discounting is missing' } } })));
  const sent = claudeLog[0].body.messages[0].content[0].text;
  assert.match(sent, /previous_answer/);
  assert.match(sent, /discounting is missing/);
  assert.match(ev.filter((e) => e.event === 'delta').map((e) => e.data.text).join(''), /corrected/);
});

test('bad input is refused politely', async () => {
  assert.equal((await routes.handleAsk(req('/api/ask', { method: 'POST', body: { question: '' } }))).status, 400);
  assert.equal((await routes.handleAsk(req('/api/ask', { method: 'POST', body: { question: 'x'.repeat(2500) } }))).status, 400);
});

const notes = (title, words) => ({
  fileName: `${title}.pdf`, fileType: 'pdf', title, by: 'Anna', intent: 'hub', unit: 'page',
  pages: [1, 2, 3].map((n) => ({ n, title: `${title} part ${n}`, text: `${title} part ${n}\n\n${words} `.repeat(4) })),
});

test('adding a document: clean, check, chunk and commit to GitHub', async () => {
  ghLog.length = 0;
  const ev = await events(await routes.handleIngest(req('/api/ingest', { method: 'POST', body: notes('Discounting notes', 'The net present value adds discounted cash flows and subtracts the investment; a positive value creates wealth for the owners.') })));
  const result = ev.find((e) => e.event === 'result').data;
  assert.equal(result.decision, 'published');
  assert.equal(result.doc.origin, 'added');
  assert.ok(result.doc.chunks.length >= 1);
  const put = ghLog.find((l) => l.method === 'PUT');
  assert.ok(put.url.startsWith('/repos/class/finprep-hub/contents/data/docs/added-'));
  assert.equal(put.body.branch, 'main');
  const saved = JSON.parse([...ghFiles.values()].at(-1));
  assert.equal(saved.id, result.doc.id);
  assert.equal(saved.added.by, 'Anna');
  const steps = ev.filter((e) => e.event === 'step').map((e) => `${e.data.id}:${e.data.status}`);
  assert.deepEqual(steps, ['clean:run', 'clean:done', 'check:run', 'check:done', 'chunk:run', 'chunk:done', 'publish:run', 'publish:done']);
});

test('pull-request mode opens a pull request instead of committing to main', async () => {
  process.env.PUBLISH_MODE = 'pull-request';
  ghLog.length = 0;
  const ev = await events(await routes.handleIngest(req('/api/ingest', { method: 'POST', body: notes('Bond pricing notes', 'A bond price is the present value of the coupons and the face value discounted at the yield to maturity.') })));
  process.env.PUBLISH_MODE = 'direct';
  const result = ev.find((e) => e.event === 'result').data;
  assert.equal(result.decision, 'pending');
  assert.match(result.publish.url, /\/pull\/7$/);
  assert.ok(ghLog.some((l) => l.method === 'POST' && l.url.endsWith('/git/refs')));
  assert.ok(ghLog.some((l) => l.method === 'PUT' && l.body.branch.startsWith('knowledge/')));
});

test('off-topic documents are declined; private documents are not reviewed', async () => {
  const bad = notes('Weekend', 'DECLINE-ME lottery numbers and party plans for the weekend with friends and music.');
  const ev = await events(await routes.handleIngest(req('/api/ingest', { method: 'POST', body: bad })));
  assert.equal(ev.find((e) => e.event === 'result').data.decision, 'declined');
  claudeLog.length = 0;
  const priv = await events(await routes.handleIngest(req('/api/ingest', { method: 'POST', body: { ...bad, intent: 'private' } })));
  assert.equal(priv.find((e) => e.event === 'result').data.decision, 'private');
  assert.equal(claudeLog.length, 0, 'no review call for private documents');
});

test('a re-upload of a course document is recognised', async () => {
  const { getStore } = await import('../lib/store.js');
  const d = getStore().byId.get('fof-04-risk-and-return');
  const pages = d.pages.slice(4, 16).map((p) => ({ n: p.n, title: p.title, text: `${p.title || ''}\n${p.text}` }));
  const ev = await events(await routes.handleIngest(req('/api/ingest', { method: 'POST', body: { fileName: 'copy.pdf', intent: 'hub', unit: 'slide', pages } })));
  const result = ev.find((e) => e.event === 'result').data;
  assert.equal(result.decision, 'already');
  assert.equal(result.docId, 'fof-04-risk-and-return');
});

test('scanned files without text are declined with a clear reason', async () => {
  const ev = await events(await routes.handleIngest(req('/api/ingest', { method: 'POST', body: { fileName: 'scan.pdf', intent: 'hub', unit: 'page', pages: [{ n: 1, text: '' }, { n: 2, text: ' ' }] } })));
  const result = ev.find((e) => e.event === 'result').data;
  assert.equal(result.decision, 'declined');
  assert.match(result.reason, /scanned/i);
});

test('an invalid Anthropic key gives a message the owner can act on', async () => {
  process.env.ANTHROPIC_API_KEY = 'sk-invalid';
  const ev = await events(await routes.handleAsk(req('/api/ask', { method: 'POST', body: { question: 'What is beta?', mode: 'short' } })));
  process.env.ANTHROPIC_API_KEY = 'sk-test';
  const err = ev.find((e) => e.event === 'error');
  assert.match(err.data.message, /API key/);
});

test('the repository and branch are detected on Vercel and Render', async () => {
  const { config } = await import('../lib/env.js');
  const keys = ['GITHUB_REPO', 'GITHUB_BRANCH', 'VERCEL_GIT_REPO_OWNER', 'VERCEL_GIT_REPO_SLUG', 'VERCEL_GIT_COMMIT_REF', 'RENDER_GIT_REPO_SLUG', 'RENDER_GIT_BRANCH'];
  const saved = Object.fromEntries(keys.map((k) => [k, process.env[k]]));
  try {
    for (const k of keys) delete process.env[k];
    assert.equal(config().sharing.enabled, false, 'no repository known: adding for everyone is off');
    Object.assign(process.env, { VERCEL_GIT_REPO_OWNER: 'anna', VERCEL_GIT_REPO_SLUG: 'finprep-hub', VERCEL_GIT_COMMIT_REF: 'main' });
    assert.deepEqual([config().github.repo, config().github.branch], ['anna/finprep-hub', 'main']);
    for (const k of keys) delete process.env[k];
    Object.assign(process.env, { RENDER_GIT_REPO_SLUG: 'ben/finprep-hub', RENDER_GIT_BRANCH: 'live' });
    assert.deepEqual([config().github.repo, config().github.branch], ['ben/finprep-hub', 'live']);
    process.env.GITHUB_REPO = 'class/other';
    assert.equal(config().github.repo, 'class/other', 'GITHUB_REPO always wins');
  } finally {
    for (const k of keys) { if (saved[k] === undefined) delete process.env[k]; else process.env[k] = saved[k]; }
  }
});
