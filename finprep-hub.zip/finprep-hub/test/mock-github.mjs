// A stand-in for the parts of the GitHub REST API the hub uses to publish documents.
//   node test/mock-github.mjs 8788   then   GITHUB_API_URL=http://localhost:8788

import http from 'node:http';

export function createMockGitHub({ files = new Map(), log = [] } = {}) {
  let commit = 0;
  return http.createServer((req, res) => {
    let raw = '';
    req.on('data', (c) => { raw += c; });
    req.on('end', () => {
      const body = raw ? JSON.parse(raw) : null;
      log.push({ method: req.method, url: req.url, body });
      const send = (status, data) => { res.writeHead(status, { 'content-type': 'application/json' }); res.end(JSON.stringify(data)); };
      if (req.headers.authorization !== 'Bearer ghp_test') return send(401, { message: 'Bad credentials' });
      let m;
      if (req.method === 'GET' && (m = req.url.match(/^\/repos\/([^/]+\/[^/]+)\/git\/ref\/heads\/(.+)$/))) {
        return send(200, { ref: `refs/heads/${m[2]}`, object: { sha: 'base0000000000000000000000000000000000000' } });
      }
      if (req.method === 'POST' && /^\/repos\/[^/]+\/[^/]+\/git\/refs$/.test(req.url)) return send(201, { ref: body.ref });
      if (req.method === 'PUT' && (m = req.url.match(/^\/repos\/([^/]+\/[^/]+)\/contents\/(.+)$/))) {
        const path = decodeURIComponent(m[2]);
        const key = `${body.branch}:${path}`;
        if (files.has(key) && !body.sha) return send(422, { message: 'Invalid request. "sha" wasn\'t supplied.' });
        files.set(key, Buffer.from(body.content, 'base64').toString('utf8'));
        commit++;
        return send(201, { content: { path }, commit: { sha: `c${commit}`.padEnd(40, '0'), html_url: `https://github.com/${m[1]}/commit/c${commit}` } });
      }
      if (req.method === 'POST' && (m = req.url.match(/^\/repos\/([^/]+\/[^/]+)\/pulls$/))) {
        return send(201, { number: 7, html_url: `https://github.com/${m[1]}/pull/7` });
      }
      return send(404, { message: 'Not Found' });
    });
  });
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const port = Number(process.argv[2]) || 8788;
  createMockGitHub().listen(port, () => console.log(`mock GitHub API on http://localhost:${port}`));
}
