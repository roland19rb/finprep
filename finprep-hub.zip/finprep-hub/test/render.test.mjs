// Answer rendering (public/js/markdown.js) and visual parsing (public/js/visual.js).
import { test } from 'node:test';
import assert from 'node:assert/strict';

globalThis.window = { katex: { renderToString: (tex, o) => `<span class="k${o.displayMode ? 'd' : ''}">${tex}</span>` } };
const { renderMarkdown } = await import('../public/js/markdown.js');
const { parseDiagram, parseChart } = await import('../public/js/visual.js');

test('escapes HTML from the model', () => {
  const { html } = renderMarkdown('<img src=x onerror=alert(1)> **bold**');
  assert.ok(!html.includes('<img'));
  assert.match(html, /&lt;img/);
  assert.match(html, /<strong>bold<\/strong>/);
});

test('formulas, tables, lists and citations', () => {
  const src = 'Use \\(r\\) [1][2] and [p. 4].\n\n\\[ NPV = \\sum CF_t \\]\n\n| A | B |\n|---|---|\n| 1 | 2 |\n\n1. one\n2. two\n\n- x\n- y';
  const { html, cited, pages } = renderMarkdown(src, { sources: new Map([[1, { title: 'Lecture' }]]) });
  assert.match(html, /class="k">r</);
  assert.match(html, /class="kd">NPV = \\sum CF_t</);
  assert.match(html, /<table>/);
  assert.match(html, /<ol><li>one<\/li><li>two<\/li><\/ol>/);
  assert.match(html, /<ul><li>x<\/li><li>y<\/li><\/ul>/);
  assert.deepEqual([...cited], [1, 2]);
  assert.deepEqual([...pages], [4]);
  assert.match(html, /cite missing" data-n="2"/);
});

test('dollar amounts are not treated as maths', () => {
  const { html } = renderMarkdown('It costs $5 and returns $10.');
  assert.match(html, /\$5 and returns \$10/);
});

test('general knowledge is marked', () => {
  const { html } = renderMarkdown('**Outside the course materials:** textbooks call this the PV factor.');
  assert.match(html, /class="general"/);
});

test('an unfinished visual block shows a placeholder while streaming', () => {
  const r = renderMarkdown('Intro\n\n```diagram\ntitle: X\na = A', { streaming: true });
  assert.match(r.html, /Drawing the diagram/);
  assert.equal(r.visuals.length, 0);
  const done = renderMarkdown('Intro\n\n```diagram\ntitle: X\na = A\n```\n');
  assert.equal(done.visuals.length, 1);
});

test('diagram grammar', () => {
  const g = parseDiagram('title: Flow\nlane In: a, b\nlane Out: c\na = Cash flows | forecast per year [1]\nb = Rate | from CAPM [2]\nc = NPV | sum of PVs\na -> c : discount\nb -> c\nfocus: c');
  assert.equal(g.title, 'Flow');
  assert.equal(g.nodes.size, 3);
  assert.deepEqual(g.nodes.get('a').cites, [1]);
  assert.equal(g.nodes.get('a').detail, 'forecast per year');
  assert.equal(g.edges.length, 2);
  assert.ok(g.focus.has('c'));
  assert.throws(() => parseDiagram('title: empty'));
});

test('chart JSON (with a trailing comma tolerated)', () => {
  const c = parseChart('{"type":"line","x":{"label":"r","values":[0,5,10]},"series":[{"name":"A","values":[10,5,1],}],"mark":{"x":7,"label":"IRR"}}');
  assert.equal(c.type, 'line');
  assert.equal(c.numericX, true);
  assert.equal(c.series[0].values.length, 3);
  assert.equal(c.mark.x, 7);
  assert.throws(() => parseChart('{"series":[]}'));
});
