#!/usr/bin/env python3
"""
Extract the course materials into raw page records.

This is step 1 of building the hub's built-in knowledge:

  1. scripts/extract_materials.py  reads every file listed in scripts/materials.json
                                   and writes one raw JSON file per document to build/raw/
  2. scripts/build-docs.mjs        cleans, chunks and indexes the raw pages and writes
                                   data/docs/<id>.json (the files the live site reads)

Usage:
  pip install pymupdf openpyxl pyxlsb python-docx
  python3 scripts/extract_materials.py --source "/path/to/course folder" --out build/raw

What it does per file type:
  PDF   one record per page (slide). Text is read block by block and put in reading
        order with a recursive XY-cut (top-to-bottom, then column by column). The slide
        title is the largest text in the top third of the page. Tables are rebuilt as
        Markdown tables. Scanned pages without a text layer use scripts/transcriptions.json.
  DOCX  one record per section (split at headings and "Heading:" lines). Tables become
        Markdown tables.
  XLSX  one record per sheet. Each row is written as "label | value | formula → value".
        Formulas copied across a row are written once with all their values; repeated
        rows and long data blocks are summarised, so a 2,000-row price history becomes one line.
  XLSB  one record per sheet with cell values (binary workbooks do not keep formulas
        in a form that can be read here).
"""
import argparse
import datetime as dt
import hashlib
import json
import os
import re
import statistics
import sys
import warnings

warnings.filterwarnings("ignore")

try:
    import pymupdf  # PyMuPDF
except ImportError:  # older installs expose the module as fitz
    import fitz as pymupdf  # type: ignore

HERE = os.path.dirname(os.path.abspath(__file__))


# --------------------------------------------------------------------------- helpers

def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def clean_cell(value):
    if value is None:
        return ""
    s = str(value).replace(" ", " ").replace("\n", " ").strip()
    return re.sub(r"\s+", " ", s)


def markdown_table(rows):
    """Return a Markdown table for a list of rows, or None when it is not a usable table."""
    rows = [[clean_cell(c) for c in r] for r in rows if r]
    rows = [r for r in rows if any(r)]
    if len(rows) < 2:
        return None
    width = max(len(r) for r in rows)
    rows = [r + [""] * (width - len(r)) for r in rows]
    keep = [j for j in range(width) if any(r[j] for r in rows)]
    rows = [[r[j] for j in keep] for r in rows]
    if len(keep) < 2:
        return None
    cells = [c for r in rows for c in r]
    filled = [c for c in cells if c]
    if len(filled) / len(cells) < 0.5:
        return None
    if max(len(c) for c in filled) > 220 or sum(len(c) for c in filled) / len(filled) > 70:
        return None
    esc = lambda c: c.replace("|", "\\|")
    out = ["| " + " | ".join(esc(c) for c in rows[0]) + " |",
           "| " + " | ".join("---" for _ in rows[0]) + " |"]
    out += ["| " + " | ".join(esc(c) for c in r) + " |" for r in rows[1:]]
    return "\n".join(out)


# --------------------------------------------------------------------------- PDF

def weighted_median(pairs):
    """pairs: (value, weight)"""
    pairs = sorted(pairs)
    total = sum(w for _, w in pairs)
    if not total:
        return 0
    acc = 0
    for v, w in pairs:
        acc += w
        if acc >= total / 2:
            return v
    return pairs[-1][0]


def is_wordy(text):
    """True for heading-like text; false for formulas, numbers and symbol runs."""
    if "=" in text or re.fullmatch(r"[\d\s#/.,\-–:()%]+", text):
        return False
    letters = sum(1 for ch in text if ch.isalpha() and ord(ch) < 0x1D400)
    return letters >= 3 and letters / max(1, len(text.replace(" ", ""))) >= 0.6


def xycut(items, depth=0):
    """Recursive XY-cut: split at the widest horizontal gap first (reading down),
    otherwise at the widest vertical gap (reading across columns)."""
    if len(items) <= 1 or depth > 60:
        return items
    s = sorted(items, key=lambda b: b["bbox"][1])
    best = None
    edge = s[0]["bbox"][3]
    for k in range(1, len(s)):
        gap = s[k]["bbox"][1] - edge
        if gap > 1.5 and (best is None or gap > best[0]):
            best = (gap, k)
        edge = max(edge, s[k]["bbox"][3])
    if best:
        k = best[1]
        return xycut(s[:k], depth + 1) + xycut(s[k:], depth + 1)
    s = sorted(items, key=lambda b: b["bbox"][0])
    best = None
    edge = s[0]["bbox"][2]
    for k in range(1, len(s)):
        gap = s[k]["bbox"][0] - edge
        if gap > 3 and (best is None or gap > best[0]):
            best = (gap, k)
        edge = max(edge, s[k]["bbox"][2])
    if best:
        k = best[1]
        return xycut(s[:k], depth + 1) + xycut(s[k:], depth + 1)
    return sorted(items, key=lambda b: (round(b["bbox"][1]), b["bbox"][0]))


def inside(line_bbox, box, pad=1.5):
    cx = (line_bbox[0] + line_bbox[2]) / 2
    cy = (line_bbox[1] + line_bbox[3]) / 2
    return box[0] - pad <= cx <= box[2] + pad and box[1] - pad <= cy <= box[3] + pad


def pdf_page_record(page, n, use_tables=True):
    width, height = page.rect.width, page.rect.height
    data = page.get_text("dict")
    blocks = []
    for b in data["blocks"]:
        if b.get("type") != 0:
            continue
        lines = []
        for ln in b["lines"]:
            spans = [s for s in ln["spans"] if s["text"].strip()]
            if not spans:
                continue
            text = "".join(s["text"] for s in ln["spans"]).replace(" ", " ").strip()
            if not text:
                continue
            lines.append({
                "bbox": ln["bbox"],
                "text": text,
                "size": max(s["size"] for s in spans),
                "bold": any(s["flags"] & 16 for s in spans),
            })
        if lines:
            blocks.append({"bbox": b["bbox"], "lines": lines})

    # Tables -> Markdown; drop the loose lines that sit inside a recognised table.
    tables = []
    if use_tables and blocks:
        try:
            for t in page.find_tables().tables:
                md = markdown_table(t.extract())
                if md:
                    tables.append({"bbox": tuple(t.bbox), "md": md})
        except Exception:
            tables = []
    if tables:
        kept = []
        for b in blocks:
            lines = [ln for ln in b["lines"] if not any(inside(ln["bbox"], t["bbox"]) for t in tables)]
            if lines:
                x0 = min(ln["bbox"][0] for ln in lines); y0 = min(ln["bbox"][1] for ln in lines)
                x1 = max(ln["bbox"][2] for ln in lines); y1 = max(ln["bbox"][3] for ln in lines)
                kept.append({"bbox": (x0, y0, x1, y1), "lines": lines})
        blocks = kept

    all_lines = [ln for b in blocks for ln in b["lines"]]
    title = None
    subtitle = None
    # body text only: footers and source notes in the bottom band would pull the median down
    body_lines = [ln for ln in all_lines if ln["bbox"][1] < height * 0.875 and ln["size"] >= 9] or all_lines
    if all_lines:
        median = weighted_median([(ln["size"], max(1, len(ln["text"]))) for ln in body_lines])
        cands = [ln for ln in all_lines
                 if ln["bbox"][1] < height * 0.34 and len(ln["text"]) >= 3 and is_wordy(ln["text"])]
        if cands:
            top = max(c["size"] for c in cands)
            if top >= median * 1.15 or (len(all_lines) <= 4 and top >= median):
                picked = sorted([c for c in cands if abs(c["size"] - top) < 0.6], key=lambda c: c["bbox"][1])
                chosen = [picked[0]]
                for c in picked[1:]:
                    if c["bbox"][1] - chosen[-1]["bbox"][3] <= top * 0.9:
                        chosen.append(c)
                    else:
                        break
                title = " ".join(c["text"] for c in chosen).strip()
                for c in chosen:
                    c["is_title"] = True
                # The next-largest heading in the top third. build-docs.mjs uses it when the
                # title turns out to be a running header that repeats on most slides.
                rest = [c for c in cands if not c.get("is_title") and c["size"] >= median * 1.1
                        and len(c["text"].split()) <= 14]
                if rest:
                    second = max(c["size"] for c in rest)
                    sub = sorted([c for c in rest if abs(c["size"] - second) < 0.6], key=lambda c: c["bbox"][1])
                    subtitle = " ".join(c["text"] for c in sub[:2]).strip()

    # Lines in the top and bottom bands of the page: running section labels ("B. PORTFOLIO
    # THEORY"), course names, copyright lines and page numbers live here. build-docs.mjs uses
    # them to tell section labels and footers apart from repeated body text.
    marks = {"top": [], "bottom": []}
    if all_lines:
        median = weighted_median([(ln["size"], max(1, len(ln["text"]))) for ln in all_lines])
        for ln in all_lines:
            if ln.get("is_title"):
                continue
            if ln["bbox"][3] <= height * 0.075 and len(ln["text"].split()) <= 14:
                marks["top"].append(ln["text"])
            elif ln["bbox"][1] >= height * 0.875 and ln["size"] <= max(10.5, median * 0.85):
                marks["bottom"].append(ln["text"])

    items = []
    for b in blocks:
        lines = [ln for ln in b["lines"] if not ln.get("is_title")]
        if lines:
            items.append({"bbox": b["bbox"], "text": "\n".join(ln["text"] for ln in lines)})
    for t in tables:
        items.append({"bbox": t["bbox"], "text": t["md"]})
    ordered = xycut(items)
    body = "\n\n".join(it["text"] for it in ordered).strip()
    text = (title + "\n\n" + body).strip() if title else body
    record = {"n": n, "title": title, "text": text, "tables": len(tables)}
    if subtitle:
        record["subtitle"] = subtitle
    if marks["top"] or marks["bottom"]:
        record["marks"] = marks
    return record


def grid_table_page(page, n, title):
    """Statistical tables: rebuild rows from word positions (rows by y, columns by x)."""
    words = page.get_text("words")  # x0, y0, x1, y1, word, block, line, wordno
    rows = []
    for w in sorted(words, key=lambda w: (round(w[1] / 3), w[0])):
        y = (w[1] + w[3]) / 2
        if rows and abs(rows[-1]["y"] - y) <= 2.5:
            rows[-1]["words"].append(w)
        else:
            rows.append({"y": y, "words": [w]})
    lines = []
    pending = None  # (label tokens, number of stacked "t" headers)
    for r in rows:
        toks = [w[4] for w in sorted(r["words"], key=lambda w: w[0])]
        t_count = sum(1 for t in toks if t == "t")
        if t_count > 3:
            # column headers printed as a "t" above its quantile (t over .975): merge with the next row
            pending = ([t for t in toks if t != "t"], t_count)
            continue
        if pending and len(toks) == pending[1]:
            label = " ".join(pending[0]) or "quantile"
            toks = [label] + ["t" + t for t in toks]
            pending = None
        if len(toks) >= 4:
            lines.append(" | ".join(toks))
    head = title or "Table"
    return {"n": n, "title": head, "text": head + "\n\n" + "\n".join(lines), "tables": 1}


def extract_pdf(path, entry, transcriptions):
    doc = pymupdf.open(path)
    first = doc[0].rect
    unit = "slide" if first.width > first.height else "page"
    pages = []
    trans = {p["n"]: p for p in transcriptions.get(os.path.basename(path), [])}
    for i, page in enumerate(doc):
        n = i + 1
        if n in trans:
            t = trans[n]
            pages.append({"n": n, "title": t.get("title"), "text": t["text"], "transcribed": True})
            continue
        if entry.get("table"):
            pages.append(grid_table_page(page, n, entry["title"] + (f" (page {n})" if len(doc) > 1 else "")))
            continue
        pages.append(pdf_page_record(page, n))
    return unit, pages


# --------------------------------------------------------------------------- DOCX

def extract_docx(path):
    import docx
    from docx.table import Table
    from docx.text.paragraph import Paragraph

    d = docx.Document(path)
    parts = []  # (kind, text, is_heading)
    for child in d.element.body.iterchildren():
        tag = child.tag.rsplit("}", 1)[-1]
        if tag == "p":
            p = Paragraph(child, d)
            text = p.text.replace(" ", " ").strip()
            if not text:
                continue
            style = (p.style.name or "") if p.style is not None else ""
            words = len(text.split())
            heading = style.lower().startswith("heading") or style.lower() == "title" or (
                words <= 7 and text.endswith(":")) or (
                words <= 9 and p.runs and all((r.bold or False) for r in p.runs if r.text.strip()) and not text.endswith("."))
            parts.append(("p", text, heading))
        elif tag == "tbl":
            t = Table(child, d)
            rows = [[c.text for c in r.cells] for r in t.rows]
            md = markdown_table(rows)
            if md:
                parts.append(("t", md, False))

    sections = []
    for kind, text, heading in parts:
        if heading or not sections:
            sections.append({"title": text.rstrip(":") if heading else None, "lines": [] if heading else [text]})
            if heading:
                sections[-1]["lines"].append(text)
            continue
        sections[-1]["lines"].append(text)
    # merge tiny sections into the previous one (headings followed by a single table caption etc.)
    merged = []
    for s in sections:
        words = sum(len(x.split()) for x in s["lines"])
        if merged and words < 25 and not any(x.startswith("|") for x in s["lines"][1:]):
            merged[-1]["lines"].extend(s["lines"])
        else:
            merged.append(s)
    pages = []
    for i, s in enumerate(merged):
        pages.append({"n": i + 1, "title": s["title"], "text": "\n\n".join(s["lines"]), "tables": sum(1 for x in s["lines"] if x.startswith("|"))})
    return "section", pages


# --------------------------------------------------------------------------- Spreadsheets

REF = re.compile(r"(?<![A-Za-z_\d.])(\$?)([A-Z]{1,3})(\$?)(\d+)(?![\d(A-Za-z_])")


def col_index(letters):
    n = 0
    for ch in letters:
        n = n * 26 + (ord(ch) - 64)
    return n


def col_letters(n):
    s = ""
    while n:
        n, r = divmod(n - 1, 26)
        s = chr(65 + r) + s
    return s


def tidy_formula(f):
    prev = None
    while prev != f:
        prev = f
        f = re.sub(r"_xlfn\.SINGLE\(([^()]*)\)", r"\1", f)
    f = f.replace("_xlfn._xlws.", "").replace("_xlfn.", "").replace("_xlws.", "")
    return f


def formula_shape(f, row, col):
    def rep(m):
        c = col_index(m.group(2)); r = int(m.group(4))
        cs = f"C{c}" if m.group(1) else f"C[{c - col}]"
        rs = f"R{r}" if m.group(3) else f"R[{r - row}]"
        return rs + cs
    return REF.sub(rep, f)


def fmt_value(v, number_format=""):
    if v is None:
        return ""
    if isinstance(v, bool):
        return "TRUE" if v else "FALSE"
    if isinstance(v, (dt.datetime, dt.date)):
        return v.strftime("%Y-%m-%d") if (not isinstance(v, dt.datetime) or (v.hour, v.minute) == (0, 0)) else v.isoformat(sep=" ", timespec="minutes")
    if isinstance(v, (int, float)):
        if isinstance(v, float) and (v != v or v in (float("inf"), float("-inf"))):
            return str(v)
        if number_format and "%" in number_format:
            return f"{v * 100:.2f}%"
        if isinstance(v, int) or float(v).is_integer():
            iv = int(v)
            return f"{iv:,}" if abs(iv) >= 10000 else str(iv)
        a = abs(v)
        if a >= 1000:
            return f"{v:,.2f}"
        if a >= 1:
            return f"{v:.4g}" if a < 100 else f"{v:.2f}"
        return f"{v:.4g}"
    s = clean_cell(v)
    return s[:120] + ("…" if len(s) > 120 else "")


def is_error_value(v):
    return isinstance(v, str) and v.startswith("#") and v.endswith(("!", "?", "A")) and len(v) <= 8


def describe_cells(cells):
    """cells: list of dicts {col, kind, text, shape, value, fmt, coord}. Group runs."""
    out = []
    i = 0
    while i < len(cells):
        c = cells[i]
        if c["kind"] == "formula":
            j = i
            while (j + 1 < len(cells) and cells[j + 1]["kind"] == "formula"
                   and cells[j + 1]["shape"] == c["shape"] and cells[j + 1]["col"] == cells[j]["col"] + 1):
                j += 1
            vals = [fmt_value(x["value"], x["fmt"]) for x in cells[i:j + 1]]
            vals = [v if v != "" else "–" for v in vals]
            shown = vals if len(vals) <= 8 else vals[:6] + ["…"] + vals[-1:]
            rng = c["coord"] if j == i else f"{c['coord']}…{cells[j]['coord']}"
            out.append(f"{rng} ={c['text']} → {', '.join(shown)}")
            i = j + 1
        elif c["kind"] == "num":
            j = i
            while j + 1 < len(cells) and cells[j + 1]["kind"] == "num" and cells[j + 1]["col"] == cells[j]["col"] + 1:
                j += 1
            vals = [fmt_value(x["value"], x["fmt"]) for x in cells[i:j + 1]]
            shown = vals if len(vals) <= 10 else vals[:8] + ["…"] + vals[-1:]
            out.append(", ".join(shown))
            i = j + 1
        else:
            out.append(c["text"])
            i += 1
    return " | ".join(out)


def sheet_text(rows_iter, max_chars=6000):
    """rows_iter yields (row_number, [cell dicts]) for non-empty rows."""
    lines = []
    total = 0
    prev_sig = None
    run = None  # (start_row, end_row, count, sig, example)
    data_run = None

    def flush_runs():
        nonlocal run, data_run
        if run:
            start, end, count = run[0], run[1], run[2]
            if count > 1:
                lines.append(f"Rows {start}–{end}: {count - 1} more rows with the same formulas as row {start}.")
            run = None
        if data_run:
            start, end, count, cols, first, last, _raw = data_run
            if count >= 3:
                lines.append(f"Rows {start}–{end}: {count} rows of values in columns {cols} (first row: {first}; last row: {last}).")
            else:
                lines.extend(data_run[6])
            data_run = None

    for r, cells in rows_iter:
        labels = [c for c in cells if c["kind"] == "label"]
        sig = tuple((c["col"], c["kind"], c.get("shape") if c["kind"] == "formula" else (c["text"] if c["kind"] == "label" else "")) for c in cells)
        row_line = f"R{r}: " + describe_cells(cells)
        only_numbers = cells and not labels and all(c["kind"] == "num" for c in cells)
        if only_numbers and len(cells) >= 2:
            if run:
                flush_runs()
            cols = f"{col_letters(cells[0]['col'])}–{col_letters(cells[-1]['col'])}"
            short = describe_cells(cells)
            short = short[:140] + ("…" if len(short) > 140 else "")
            if data_run and data_run[3] == cols and r == data_run[1] + 1:
                data_run = (data_run[0], r, data_run[2] + 1, cols, data_run[4], short, data_run[6] + [row_line])
            else:
                flush_runs()
                data_run = (r, r, 1, cols, short, short, [row_line])
            continue
        if data_run:
            flush_runs()
        if not labels and run and sig_shape(sig) == sig_shape(run[3]) and r == run[1] + 1:
            run = (run[0], r, run[2] + 1, run[3])
            continue
        if run:
            flush_runs()
        if not labels and any(c["kind"] == "formula" for c in cells):
            run = (r, r, 1, sig)
        if total + len(row_line) > max_chars:
            lines.append("… (sheet continues; remaining rows not shown)")
            return "\n".join(lines), True
        lines.append(row_line)
        total += len(row_line) + 1
    flush_runs()
    return "\n".join(lines), False


def sig_shape(sig):
    return tuple((c, k, s) for c, k, s in sig)


def xlsx_rows(ws_f, ws_v, max_cols=40, max_rows=3000):
    max_r = min(ws_f.max_row or 0, max_rows)
    max_c = min(ws_f.max_column or 0, max_cols)
    for r in range(1, max_r + 1):
        cells = []
        for c in range(1, max_c + 1):
            cf = ws_f.cell(r, c)
            v = cf.value
            if v is None:
                continue
            if isinstance(v, str) and v.startswith("="):
                f = tidy_formula(v[1:])
                val = ws_v.cell(r, c).value
                cells.append({"col": c, "kind": "formula", "text": f[:140], "shape": formula_shape(f, r, c),
                              "value": val, "fmt": cf.number_format or "", "coord": cf.coordinate})
            elif isinstance(v, str):
                t = clean_cell(v)
                if t:
                    cells.append({"col": c, "kind": "label", "text": t[:160], "coord": cf.coordinate})
            else:
                if hasattr(v, "text"):  # ArrayFormula and similar objects
                    t = getattr(v, "text", "")
                    if t:
                        f = tidy_formula(str(t).lstrip("="))
                        cells.append({"col": c, "kind": "formula", "text": f[:140], "shape": formula_shape(f, r, c),
                                      "value": ws_v.cell(r, c).value, "fmt": cf.number_format or "", "coord": cf.coordinate})
                    continue
                cells.append({"col": c, "kind": "num", "value": v, "fmt": cf.number_format or "", "coord": cf.coordinate})
        if cells:
            yield r, cells
    if (ws_f.max_row or 0) > max_rows:
        yield max_rows + 1, [{"col": 1, "kind": "label", "text": f"(further {ws_f.max_row - max_rows:,} rows not read)", "coord": "A"}]


def extract_xlsx(path, budget=36000):
    import openpyxl
    wb_f = openpyxl.load_workbook(path, data_only=False)
    wb_v = openpyxl.load_workbook(path, data_only=True)
    sheets = wb_f.worksheets
    per_sheet = max(1800, min(7000, budget // max(1, len(sheets))))
    pages = []
    for i, ws in enumerate(sheets):
        wsv = wb_v[ws.title]
        body, cut = sheet_text(xlsx_rows(ws, wsv), max_chars=per_sheet)
        hidden = ws.sheet_state != "visible"
        head = f"Sheet: {ws.title}" + (" (hidden sheet)" if hidden else "")
        dims = f"Used range: {ws.dimensions}"
        text = head + "\n" + dims + ("\n\n" + body if body else "\n\n(empty sheet)")
        pages.append({"n": i + 1, "title": ws.title, "text": text, "hidden": hidden})
    return "sheet", pages


def extract_xlsb(path, budget=36000):
    import pyxlsb
    pages = []
    with pyxlsb.open_workbook(path) as wb:
        names = wb.sheets
        per_sheet = max(1800, min(7000, budget // max(1, len(names))))
        for i, name in enumerate(names):
            rows = []
            with wb.get_sheet(name) as sh:
                for row in sh.rows():
                    cells = []
                    for cell in row:
                        if cell.v is None or cell.c >= 40:
                            continue
                        coord = f"{col_letters(cell.c + 1)}{cell.r + 1}"
                        if isinstance(cell.v, str):
                            t = clean_cell(cell.v)
                            if t:
                                cells.append({"col": cell.c + 1, "kind": "label", "text": t[:160], "coord": coord})
                        else:
                            cells.append({"col": cell.c + 1, "kind": "num", "value": cell.v, "fmt": "", "coord": coord})
                    if cells:
                        rows.append((row[0].r + 1 if row else 0, cells))
                    if len(rows) > 3000:
                        break
            body, _ = sheet_text(iter(rows), max_chars=per_sheet)
            text = f"Sheet: {name}\n\n" + (body or "(empty sheet)")
            pages.append({"n": i + 1, "title": name, "text": text})
    return "sheet", pages


# --------------------------------------------------------------------------- main

def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--source", required=True, help="folder that contains the module folders")
    ap.add_argument("--out", default=os.path.join(HERE, "..", "build", "raw"))
    ap.add_argument("--only", nargs="*", help="document ids to extract (default: all)")
    args = ap.parse_args()

    manifest = json.load(open(os.path.join(HERE, "materials.json"), encoding="utf-8"))
    transcriptions = json.load(open(os.path.join(HERE, "transcriptions.json"), encoding="utf-8"))
    modules = {m["id"]: m for m in manifest["modules"]}
    os.makedirs(args.out, exist_ok=True)

    missing = []
    for entry in manifest["documents"]:
        if args.only and entry["id"] not in args.only:
            continue
        folder = modules[entry["module"]]["folder"]
        path = os.path.join(args.source, folder, entry["file"])
        if not os.path.exists(path):
            missing.append(path)
            continue
        ext = os.path.splitext(path)[1].lower()
        if ext == ".pdf":
            unit, pages = extract_pdf(path, entry, transcriptions)
        elif ext == ".docx":
            unit, pages = extract_docx(path)
        elif ext == ".xlsx":
            unit, pages = extract_xlsx(path)
        elif ext == ".xlsb":
            unit, pages = extract_xlsb(path)
        else:
            print(f"skip (unsupported type): {path}", file=sys.stderr)
            continue
        record = {
            "id": entry["id"],
            "unit": unit,
            "source": {
                "file": entry["file"],
                "folder": folder,
                "type": ext.lstrip("."),
                "bytes": os.path.getsize(path),
                "sha256": sha256_file(path),
                "units": len(pages),
            },
            "pages": pages,
        }
        with open(os.path.join(args.out, entry["id"] + ".json"), "w", encoding="utf-8") as f:
            json.dump(record, f, ensure_ascii=False, indent=1)
        words = sum(len(p["text"].split()) for p in pages)
        print(f"{entry['id']:44s} {unit:7s} {len(pages):4d} units {words:7d} words")
    if missing:
        print("\nMissing files:", *missing, sep="\n  ", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
