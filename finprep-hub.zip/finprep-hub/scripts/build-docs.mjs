#!/usr/bin/env node
// Step 2 of building the hub's built-in knowledge (step 1 is scripts/extract_materials.py).
//
//   node scripts/build-docs.mjs --raw build/raw --out data/docs
//
// For every document in scripts/materials.json it reads build/raw/<id>.json, cleans the pages,
// cuts them into chunks with public/js/shared/textkit.js (the same code the live site uses for
// uploads), adds keywords and an outline, and writes data/docs/<id>.json.
// Documents that students added through the site (origin "added") are left untouched.

import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync, readdirSync, existsSync, mkdirSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { cleanPages, chunkDocument, tokenize, keywords, countWords, TEXTKIT_VERSION } from '../public/js/shared/textkit.js';

const here = dirname(fileURLToPath(import.meta.url));
const root = join(here, '..');

function arg(name, fallback) {
  const i = process.argv.indexOf(name);
  return i > 0 ? process.argv[i + 1] : fallback;
}

const rawDir = arg('--raw', join(root, 'build', 'raw'));
const outDir = arg('--out', join(root, 'data', 'docs'));
mkdirSync(outDir, { recursive: true });

const manifest = JSON.parse(readFileSync(join(here, 'materials.json'), 'utf8'));
const modules = Object.fromEntries(manifest.modules.map((m) => [m.id, m]));

function outline(pages) {
  const out = [];
  for (const p of pages) {
    if (!p.section) continue;
    const last = out[out.length - 1];
    if (last && last.title === p.section) last.to = p.n;
    else out.push({ title: p.section, from: p.n, to: p.n });
  }
  // keep sections that span more than one unit (or all of them when there are few);
  // a label that comes back for a single slide later (e.g. a closing agenda) is dropped
  const seen = new Set();
  const merged = out.filter((s, i, a) => {
    const again = seen.has(s.title);
    seen.add(s.title);
    if (again && s.to === s.from) return false;
    return s.to > s.from || a.length <= 12;
  });
  return merged.slice(0, 40);
}

const built = [];
for (const entry of manifest.documents) {
  const rawPath = join(rawDir, `${entry.id}.json`);
  if (!existsSync(rawPath)) {
    console.error(`missing raw extraction for ${entry.id} (run scripts/extract_materials.py first)`);
    process.exitCode = 1;
    continue;
  }
  const raw = JSON.parse(readFileSync(rawPath, 'utf8'));
  const { pages, report } = cleanPages(raw.pages, { unit: raw.unit });
  const chunks = chunkDocument(pages, { unit: raw.unit });
  const text = pages.map((p) => `${p.title || ''}\n${p.text}`).join('\n');
  built.push({ entry, raw, pages, chunks, report, hash: 'sha256:' + createHash('sha256').update(text.replace(/\s+/g, ' ').trim()).digest('hex') });
}

// corpus document frequencies over chunks, for keywords
const df = new Map();
let totalChunks = 0;
for (const b of built) {
  for (const c of b.chunks) {
    totalChunks++;
    for (const t of new Set(tokenize(c.text))) df.set(t, (df.get(t) || 0) + 1);
  }
}

let totals = { docs: 0, pages: 0, chunks: 0, words: 0 };
for (const b of built) {
  const { entry, raw, pages, chunks, report } = b;
  const words = pages.reduce((s, p) => s + p.words, 0);
  const doc = {
    schema: 1,
    id: entry.id,
    title: entry.title,
    module: entry.module,
    moduleTitle: modules[entry.module].title,
    kind: entry.kind,
    origin: 'course',
    unit: raw.unit,
    ...(entry.note ? { note: entry.note } : {}),
    ...(entry.transcribed ? { transcribed: true } : {}),
    source: raw.source,
    stats: { pages: pages.length, words, chunks: chunks.length },
    outline: outline(pages),
    keywords: keywords(chunks.map((c) => c.text).join('\n'), df, totalChunks, 10),
    hash: b.hash,
    processing: {
      textkit: TEXTKIT_VERSION,
      repairedMathLetters: report.doubledMath,
      runningHeader: report.runningHeader,
      removedRepeatedLines: report.removed.slice(0, 12),
      sectionLabels: report.sectionLabels.length,
      pageNumbersRemoved: report.pageNumbers,
      emptyPages: report.empty,
    },
    pages,
    chunks: chunks.map((c) => ({
      id: `${entry.id}#${String(c.n).padStart(3, '0')}`,
      n: c.n,
      pages: c.pages,
      section: c.section || null,
      title: c.title || null,
      kind: c.kind,
      words: c.words,
      ...(c.overlap ? { overlap: c.overlap } : {}),
      keywords: keywords(c.text, df, totalChunks, 6),
      text: c.text,
    })),
  };
  writeFileSync(join(outDir, `${entry.id}.json`), JSON.stringify(doc, null, 1) + '\n');
  totals.docs++; totals.pages += pages.length; totals.chunks += chunks.length; totals.words += words;
  const avg = chunks.length ? Math.round(chunks.reduce((s, c) => s + c.words, 0) / chunks.length) : 0;
  console.log(`${entry.id.padEnd(44)} ${String(pages.length).padStart(4)} ${raw.unit.padEnd(7)} ${String(chunks.length).padStart(4)} chunks  avg ${String(avg).padStart(3)} words`);
}

// module list for the site (the folder names of the course plus a bucket for other topics)
const modulesOut = [...manifest.modules.map((m) => ({ id: m.id, title: m.title })), { id: 'other', title: 'Other finance topics' }];
writeFileSync(join(outDir, '..', 'modules.json'), JSON.stringify(modulesOut, null, 1) + '\n');

const stale = readdirSync(outDir).filter((f) => f.endsWith('.json') && !built.some((b) => `${b.entry.id}.json` === f));
for (const f of stale) {
  const d = JSON.parse(readFileSync(join(outDir, f), 'utf8'));
  if (d.origin !== 'added') console.warn(`note: ${f} is not in materials.json (left in place)`);
}
console.log(`\n${totals.docs} documents, ${totals.pages} pages/sheets, ${totals.chunks} chunks, ${totals.words.toLocaleString('en')} words`);
void countWords;
