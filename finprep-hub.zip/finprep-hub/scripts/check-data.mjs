#!/usr/bin/env node
// Checks every file in data/docs before a deploy: valid JSON, required fields, unique ids,
// chunk ids that belong to their document, page references inside the document, sizes.
//   node scripts/check-data.mjs

import { readFileSync, readdirSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const dir = join(dirname(fileURLToPath(import.meta.url)), '..', 'data', 'docs');
const problems = [];
const ids = new Set();
let chunks = 0;
let bytes = 0;
for (const f of readdirSync(dir).filter((x) => x.endsWith('.json')).sort()) {
  const raw = readFileSync(join(dir, f), 'utf8');
  bytes += raw.length;
  let d;
  try { d = JSON.parse(raw); } catch (e) { problems.push(`${f}: not valid JSON (${e.message})`); continue; }
  const where = `${f}`;
  for (const k of ['id', 'title', 'module', 'kind', 'origin', 'unit', 'pages', 'chunks']) if (d[k] == null) problems.push(`${where}: missing "${k}"`);
  if (`${d.id}.json` !== f) problems.push(`${where}: id "${d.id}" does not match the file name`);
  if (ids.has(d.id)) problems.push(`${where}: duplicate id`);
  ids.add(d.id);
  const pageNos = new Set((d.pages || []).map((p) => p.n));
  for (const c of d.chunks || []) {
    chunks++;
    if (!String(c.id).startsWith(`${d.id}#`)) problems.push(`${where}: chunk ${c.id} does not belong to the document`);
    if (!c.text || !c.text.trim()) problems.push(`${where}: chunk ${c.id} is empty`);
    if (!Array.isArray(c.pages) || !pageNos.has(c.pages[0]) || !pageNos.has(c.pages[1])) problems.push(`${where}: chunk ${c.id} points to pages that do not exist`);
  }
  if (raw.length > 3_000_000) problems.push(`${where}: larger than 3 MB`);
}
console.log(`${ids.size} documents, ${chunks} chunks, ${(bytes / 1e6).toFixed(1)} MB`);
if (problems.length) {
  console.error(`\n${problems.length} problem(s):\n  ${problems.join('\n  ')}`);
  process.exit(1);
}
console.log('data/docs is fine.');
